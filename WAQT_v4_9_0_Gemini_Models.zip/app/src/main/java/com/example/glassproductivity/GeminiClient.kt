package com.example.glassproductivity

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/** Minimal Gemini REST client (generateContent). Callback always runs on the main thread. */
object GeminiClient {
    const val DEFAULT_MODEL = "gemini-flash-latest"

    fun generate(
        apiKey: String,
        model: String,
        systemPrompt: String,
        history: List<Pair<String, String>>, // role ("user"/"model") to text
        callback: (Result<String>) -> Unit
    ) {
        val main = Handler(Looper.getMainLooper())
        thread(name = "waqt-gemini") {
            val primary = model.trim().ifBlank { DEFAULT_MODEL }
            // If the main model is busy (503/500/429), retry shortly, then fall back to a lighter model.
            val attempts = listOf(primary, primary, FALLBACK_MODEL, FALLBACK_MODEL).distinctBy { it }.let {
                if (it.size == 1) listOf(it[0], it[0], FALLBACK_MODEL) else listOf(primary, primary, FALLBACK_MODEL, FALLBACK_MODEL)
            }
            var result: Result<String> = Result.failure(Exception("no attempt"))
            for ((i, m) in attempts.withIndex()) {
                result = callOnce(apiKey, m, systemPrompt, history)
                val err = result.exceptionOrNull()?.message ?: ""
                val retryable = err.startsWith("HTTP 503") || err.startsWith("HTTP 500") || err.startsWith("HTTP 429") || err.startsWith("HTTP 504")
                if (result.isSuccess || !retryable || i == attempts.size - 1) break
                try { Thread.sleep(1500L + i * 1000L) } catch (_: InterruptedException) {}
            }
            main.post { callback(result) }
        }
    }

    const val FALLBACK_MODEL = "gemini-flash-lite-latest"

    private fun callOnce(apiKey: String, model: String, systemPrompt: String, history: List<Pair<String, String>>): Result<String> {
        return try {
            val contents = JSONArray()
            history.forEach { (role, text) ->
                contents.put(
                    JSONObject()
                        .put("role", role)
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))
                )
            }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.7))

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 45000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", apiKey.trim())
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try { JSONObject(text).getJSONObject("error").optString("message") } catch (_: Exception) { text.take(200) }
                Result.failure(Exception("HTTP $code: $msg"))
            } else {
                val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                val sb = StringBuilder()
                for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                Result.success(sb.toString())
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Lists models that support generateContent. Returns pairs of (modelId, displayName). */
    fun listModels(apiKey: String, callback: (Result<List<Pair<String, String>>>) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        thread(name = "waqt-gemini-models") {
            val result: Result<List<Pair<String, String>>> = try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 15000
                    readTimeout = 20000
                    setRequestProperty("x-goog-api-key", apiKey.trim())
                }
                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (code !in 200..299) {
                    Result.failure(Exception("HTTP $code"))
                } else {
                    val arr = JSONObject(text).optJSONArray("models") ?: JSONArray()
                    val skip = listOf("image", "tts", "embedding", "live", "robotics", "audio", "banana", "computer-use", "aqa", "imagen", "veo")
                    val out = mutableListOf<Pair<String, String>>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val id = o.optString("name").removePrefix("models/")
                        val methods = o.optJSONArray("supportedGenerationMethods")
                        var canGenerate = false
                        if (methods != null) for (j in 0 until methods.length()) if (methods.getString(j) == "generateContent") canGenerate = true
                        if (canGenerate && id.contains("gemini") && skip.none { id.contains(it) }) {
                            out.add(id to o.optString("displayName", id))
                        }
                    }
                    Result.success(out.sortedBy { it.first })
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
            main.post { callback(result) }
        }
    }
}
