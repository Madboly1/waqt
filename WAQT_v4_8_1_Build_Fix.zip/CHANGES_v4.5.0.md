# v4.5.0 — Sound engine + timer fixes
- NEW SoundEngine.kt: 14 distinct synthesized sounds (tick-tock, countdown, wind+crickets, classroom, wilderness, stream, beach, rain, cafe, fire, library, wind, night frogs, brown noise). Previously all of them were the same brown noise.
- FIX: tick-tock toggle only saved a setting and never played anything. It now ticks/tocks while a focus session runs (not during breaks) and stops on pause/finish.
- FIX: break mode could never start (isBreakSession was never set). Now a finished focus session starts a break automatically (every 4th session = longer break), a finished break returns to focus, plus a manual "start a break / back to focus" button.
- NEW: completion chime when a session ends.
- FIX: volume slider now controls the synthesized sounds.
- Not compiled here (no Android SDK) - build via GitHub Actions and test on device.

# v4.6.0 — Focus dashboard
- Timer screen is now scrollable and has: sessions today, focus time, day streak, daily-goal progress bar (tap the card to change the goal), one-tap ambient sound chips, and a 7-day glass bar chart with a dashed goal line.

# v4.7.0
- Tasks: sorted by importance (done tasks sink), priority badge + priority filter, ✅ + strike-through on finished tasks, restart icon, add-task FAB outside the rail, quick reminder with chosen duration, stats (day/week/month/custom range), rank titles.
- Rail (all screens): distinct bright colors, swipe or tap to open/close, colored icons.
- Focus: slower calmer tick-tock (60 BPM), stereo 44.1 kHz ambient sounds, living hourglass (falling sand), stats + rank titles.
- Habits: stats icon + streak rank titles.
- Notes: user-defined categories only (rail icon 🏷, filter row, picker in the note editor).
- Fixes: weekday labels / streak across month boundaries (the app's day counter is year*366+dayOfYear), light/dark theme for glass cards, rail and buttons.

# v4.8.0
- NEW bottom tab bar (tap a tab) replaces the hold-and-drag radial wheel.
- NEW real Gemini assistant (GeminiClient.kt, INTERNET permission): reviews your day, picks top priorities, adds tasks/notes by itself, never discusses how to execute. Key entered via the key icon in the chat or in Settings. Model alias: gemini-flash-latest.
- NEW backup saved as a real .json file to device or Google Drive (system file picker); restore already supported.
- Google account sign-in is NOT included (requires OAuth setup in Google Cloud).
