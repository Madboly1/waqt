package com.example.glassproductivity

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/** Minimal Gemini REST client (generateContent). Callback always runs on the main thread. */
object GeminiClient {
    const val DEFAULT_MODEL = "gemini-flash-latest"

    fun generate(
        apiKey: String,
        model: String,
        systemPrompt: String,
        history: List<Pair<String, String>>, // role ("user"/"model") to text
        callback: (Result<String>) -> Unit
    ) {
        val main = Handler(Looper.getMainLooper())
        thread(name = "waqt-gemini") {
            val result: Result<String> = try {
                val contents = JSONArray()
                history.forEach { (role, text) ->
                    contents.put(
                        JSONObject()
                            .put("role", role)
                            .put("parts", JSONArray().put(JSONObject().put("text", text)))
                    )
                }
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
                    .put("contents", contents)
                    .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.7))

                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim().ifBlank { DEFAULT_MODEL }}:generateContent")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("x-goog-api-key", apiKey.trim())
                }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (code !in 200..299) {
                    val msg = try { JSONObject(text).getJSONObject("error").optString("message") } catch (_: Exception) { text.take(200) }
                    Result.failure(Exception("HTTP $code: $msg"))
                } else {
                    val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts")
                    val sb = StringBuilder()
                    for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                    Result.success(sb.toString())
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
            main.post { callback(result) }
        }
    }
}
