# WAQT 5.9.0 — Full Chalkboard Revamp

## Visual direction
- Removed the Windows 95 desktop shell from the main app layout: no Start button, Explorer window frame, blue title bar, or Windows taskbar.
- Rebuilt the app shell as a full-screen chalkboard workspace surrounded by a warm wooden frame.
- Replaced the desktop shortcut column with a compact chalk-style navigation rail for Tasks, Habits, Focus, and Notes.
- Added a chalkboard header and a restrained footer clock; the board is now the app surface rather than a window inside a fake desktop.

## App-wide styling
- Changed the shared palette to charcoal slate, off-white chalk, muted chalk gray, yellow chalk, and soft green chalk.
- Updated shared cards, buttons, dialog chrome, list rows, and surfaces so the old gray/blue Windows look is no longer used as the visual system.
- Updated the focus clock face and details to a dark slate dial with chalk-colored markings.
- Kept existing task, habit, focus, note, reminder, timer, and data logic intact; this is a UI reskin, not a data-model rewrite.

## Build status
- Android compilation was not run in this environment because the archive has no Gradle wrapper and no system Gradle executable is installed.
- Please run the existing GitHub Actions Android build before publishing the APK.
