# WAQT 5.4.2 — Floating Classic Explorer

## UI changes
- The main WAQT app window is now a centered, non-fullscreen classic desktop window.
- The teal Windows 95-style desktop remains visible around the window.
- The Explorer task list continues to show each task as a named folder.
- Opening a task folder shows a document-style task header while reusing the existing task card and its actions.
- The window height adapts to screen size and is constrained to a practical mobile range.

## Preserved behavior
- Task repository, alarms, filters, search, task creation/editing, completion, focus linking, and task-card actions are unchanged.

## Build
- Source-only update. Run the Android Gradle build / GitHub Actions to validate compilation and device layout.
