# WAQT 5.8.0 — Chalkboard Tasks UI

- Replaced the Tasks Explorer list styling with a dark chalkboard surface.
- Replaced emoji folder glyphs with a custom Canvas-drawn chalk folder icon.
- Updated task names, completion labels, filters, search field, separators, and list footer to chalkboard colors and typography.
- Kept task filtering, search submission, sorting, task opening, add-task action, and existing task detail/card behavior intact.
- Scope: the task-list screen only. The rest of the app's Windows-inspired desktop shell and other tabs are intentionally unchanged.

Build note: Gradle compilation was not run because this source archive does not include `gradlew` / Gradle wrapper scripts in the project root.
