# WAQT 6.0.0 — Liquid Glass Revamp

- Replaced the Chalkboard/wood frame identity with a deep midnight blue Liquid Glass visual system.
- Rebuilt the app's outer workspace, header, navigation surfaces and tab content host with translucent gradient glass surfaces, cool luminous borders and rounded geometry.
- Recolored the shared app palette and common screen/dialog surfaces to remove chalk-white, charcoal-board and wood tones.
- Reworked shared dialog/card drawable helpers so existing settings, modal and floating surfaces inherit the Liquid Glass style.
- Preserved existing task, habit, focus, notes, AI assistant and storage/business logic; this is a visual/theme pass.

Build note: Android build was not run in this environment. Verify with the repository's GitHub Actions workflow.
