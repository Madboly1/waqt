# WAQT UI Refresh — Petroleum & Orange

This update refreshes the existing Android project rather than replacing its app logic.

## Changes included
- Unified the UI palette around dark petroleum, teal accents, warm orange actions, warm white text, and calmer status colors.
- Updated the app mark and launcher background to match the new palette.
- Applied the app theme to Android status/navigation bars.
- Replaced the single-card task carousel presentation with a scrollable list of task cards.
- Replaced the single-card habit carousel presentation with a scrollable list of habit cards.
- Kept the existing radial tab selector, floating chat bubble, task/habit actions, Pomodoro behavior, notes, and alarm infrastructure.
- Changed side-dock anchoring to the physical left edge for the Arabic RTL layout.
- Reworked Settings into a more organized panel with appearance/language controls, focus and break duration settings, tick-tock toggle, alarm ringtone picker, local audio picker, backup export, and overlay permission status/action.

## Build
The GitHub Actions workflow in `.github/workflows/build-apk.yml` uses Gradle 8.7 and Java 17 to run `gradle assembleDebug`.

This environment did not have Gradle installed, so an APK build could not be run here. Please run the workflow or build locally and test on-device before distributing the APK.

## Notes
- The existing project logic and local data model were preserved as far as possible.
- The settings panel continues to use the project's existing preferences and backup/audio/permission mechanisms.
- Test task completion, alarm scheduling, habit schedules, Pomodoro pause/resume, custom audio selection, language switching, and dark/light mode on a real Android device.
