package com.example.glassproductivity

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.Dialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.RadialGradient
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.Ringtone
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private var isArabic: Boolean = true
    private var isDarkMode: Boolean = true
    private var currentTab: Int = 0 // 0: المهام, 1: العادات, 2: التركيز, 3: الملاحظات

    // ألوان البترولي والبرتقالي
    private val COLOR_BG_DARK = "#0B1417"
    private val COLOR_CARD_DARK = "#142A2E"
    private val COLOR_ELEVATED_DARK = "#1B383C"
    private val COLOR_ORANGE = "#FF8A3D"
    private val COLOR_ORANGE_LIGHT = "#FFAA6B"
    private val COLOR_TEAL = "#167D80"
    private val COLOR_TEAL_DEEP = "#35B6AD"
    private val COLOR_TEXT_PRIMARY = "#F5F5F0"
    private val COLOR_TEXT_MUTED = "#A5B4B4"

    private fun bgPrimaryColor(): Int = Color.parseColor(if (isDarkMode) COLOR_BG_DARK else "#F0F6F4")
    private fun bgCardColor(): Int = Color.parseColor(if (isDarkMode) COLOR_CARD_DARK else "#FFFFFF")
    private fun bgElevatedColor(): Int = Color.parseColor(if (isDarkMode) COLOR_ELEVATED_DARK else "#E0EBE8")
    private fun textPrimaryColor(): Int = Color.parseColor(if (isDarkMode) COLOR_TEXT_PRIMARY else "#0B1417")
    private fun textMutedColor(): Int = Color.parseColor(if (isDarkMode) COLOR_TEXT_MUTED else "#526C6C")
    private fun accentOrangeColor(): Int = Color.parseColor(COLOR_ORANGE)
    private fun accentTealColor(): Int = Color.parseColor(COLOR_TEAL)

    private var taskFilter: String = "all"
    private var taskSearchQuery: String = ""
    private var isTasksLeftDockOpen: Boolean = false

    private var habitSelectedCategory: String = "all"
    private var isHabitsLeftDockOpen: Boolean = false

    private var noteSelectedCategory: String = "all"
    private var noteSearchQuery: String = ""
    private var isNotesLeftDockOpen: Boolean = false

    private var currentTaskCarouselIndex: Int = 0
    private var currentHabitCarouselIndex: Int = 0
    private var currentNoteCarouselIndex: Int = 0

    private var isPomodoroLinkedToTask: Boolean = true
    private var selectedFocusTaskId: String? = null
    private var selectedPomodoroMinutes: Int = 25
    private var selectedBreakMinutes: Int = 5
    private var isBreakSession: Boolean = false
    private var pomodoroTotalMillis: Long = 25 * 60 * 1000L
    private var pomodoroRemainingMillis: Long = 25 * 60 * 1000L
    private var pomodoroStartWallClockMs: Long = 0L
    private var activeFocusSessionId: String = UUID.randomUUID().toString()
    private var isPomodoroRunning: Boolean = false
    private var inAppCountDownTimer: CountDownTimer? = null
    private var circularTimerView: CircularTimerRingView? = null
    private var isTickTockSoundActive: Boolean = false
    private var isPomodoroLeftDockOpen: Boolean = false

    private var isFlipClockModeActive: Boolean = false
    private var fullscreenClockType: String = "flip"

    private var ambientAudioTrack: AudioTrack? = null
    private var isAmbientPlaying: Boolean = false
    private var selectedAmbientIndex: Int = 0
    private var ambientVolume: Float = 0.7f
    private var customAudioUri: Uri? = null
    private var customAudioName: String? = null
    private var customAudioPlayer: MediaPlayer? = null
    private var isPickingAudioFromConsole: Boolean = false
    private var audioManager: AudioManager? = null
    private var previewRingtone: Ringtone? = null

    private lateinit var rootFrameLayout: FrameLayout
    private lateinit var mainContentContainer: LinearLayout
    private lateinit var headerBarLayout: LinearLayout
    private lateinit var tabContentHost: FrameLayout
    private lateinit var tvBrandTitle: TextView
    private lateinit var tvBrandSubtitle: TextView

    private lateinit var gtaRadialTriggerButton: FrameLayout
    private lateinit var gtaRadialOverlayView: GTARadialWheelView
    private lateinit var floatingAIChatBubble: FrameLayout

    private val ringtonePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            if (uri != null) {
                ReminderRepository.setAlarmRingtoneUri(this, uri)
                Toast.makeText(this, if (isArabic) "✓ تم حفظ نغمة المنبه بنجاح" else "✓ Ringtone saved", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val backupImportLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val backupText = try {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            } catch (_: Exception) { null }
            if (backupText.isNullOrBlank()) {
                Toast.makeText(this, if (isArabic) "تعذر قراءة ملف النسخة الاحتياطية" else "Could not read backup file", Toast.LENGTH_LONG).show()
            } else {
                AlertDialog.Builder(this)
                    .setTitle(if (isArabic) "استعادة النسخة الاحتياطية؟" else "Restore backup?")
                    .setMessage(if (isArabic) "سيتم استبدال المهام والعادات والملاحظات الحالية بالبيانات الموجودة في الملف." else "Current tasks, habits and notes will be replaced by the backup data.")
                    .setNegativeButton(if (isArabic) "إلغاء" else "Cancel", null)
                    .setPositiveButton(if (isArabic) "استعادة" else "Restore") { _, _ ->
                        val ok = ReminderRepository.importCloudBackupJson(this, backupText)
                        Toast.makeText(this, if (ok) {
                            if (isArabic) "تمت استعادة النسخة الاحتياطية" else "Backup restored"
                        } else {
                            if (isArabic) "الملف غير صالح أو غير مدعوم" else "Invalid or unsupported backup"
                        }, Toast.LENGTH_LONG).show()
                        if (ok) renderCurrentTab()
                    }.show()
            }
        }
    }

    private val localAudioPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            customAudioUri = uri
            customAudioName = getFileNameFromUri(uri)
            selectedAmbientIndex = -1
            getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE).edit()
                .putString("custom_audio_uri", uri.toString())
                .putString("custom_audio_name", customAudioName)
                .putInt(ReminderRepository.KEY_DEFAULT_SOUND_INDEX, -1)
                .apply()
            Toast.makeText(this, if (isArabic) "🎵 تم اختيار: $customAudioName" else "🎵 Audio loaded: $customAudioName", Toast.LENGTH_SHORT).show()
            if (isPickingAudioFromConsole) playCustomAudio()
            isPickingAudioFromConsole = false
            renderCurrentTab()
        } else {
            isPickingAudioFromConsole = false
        }
    }

    private val dataUpdateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            syncActiveFocusTimerFromStorage()
            renderCurrentTab()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        loadSavedPreferences()
        applySystemBarTheme()
        buildMainLayoutStructure()
        syncActiveFocusTimerFromStorage()
        renderCurrentTab()
    }

    private fun applySystemBarTheme() {
        window.statusBarColor = bgPrimaryColor()
        window.navigationBarColor = bgPrimaryColor()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (isDarkMode) 0 else (
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        )
    }

    private fun loadSavedPreferences() {
        val prefs = getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
        isArabic = prefs.getBoolean("is_arabic", true)
        isDarkMode = prefs.getBoolean(ReminderRepository.KEY_DARK_MODE, true)
        selectedPomodoroMinutes = prefs.getInt(ReminderRepository.KEY_DEFAULT_FOCUS_MINS, 25)
        selectedBreakMinutes = prefs.getInt(ReminderRepository.KEY_DEFAULT_BREAK_MINS, 5)
        selectedAmbientIndex = prefs.getInt(ReminderRepository.KEY_DEFAULT_SOUND_INDEX, 0)
        ambientVolume = (prefs.getInt(ReminderRepository.KEY_SOUND_VOLUME, 70) / 100f).coerceIn(0.05f, 1f)
        isTickTockSoundActive = prefs.getBoolean(ReminderRepository.KEY_TICK_TOCK_ENABLED, false)
        customAudioUri = prefs.getString("custom_audio_uri", null)?.let { runCatching { Uri.parse(it) }.getOrNull() }
        customAudioName = prefs.getString("custom_audio_name", null)

        pomodoroTotalMillis = selectedPomodoroMinutes * 60 * 1000L
        pomodoroRemainingMillis = pomodoroTotalMillis
        window.decorView.layoutDirection = if (isArabic) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(FloatingCardService.ACTION_DATA_UPDATED)
        ContextCompat.registerReceiver(this, dataUpdateReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onResume() {
        super.onResume()
        syncActiveFocusTimerFromStorage()
        renderCurrentTab()
    }

    override fun onPause() {
        super.onPause()
        if (isPomodoroRunning) {
            ReminderRepository.saveActiveFocusState(
                this,
                startEpochMs = pomodoroStartWallClockMs,
                totalDurationMs = pomodoroTotalMillis,
                remainingOnPauseMs = pomodoroRemainingMillis,
                isRunning = true,
                linkedTaskId = selectedFocusTaskId,
                isBreakMode = isBreakSession
            )
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(dataUpdateReceiver) } catch (_: Exception) {}
        inAppCountDownTimer?.cancel()
        stopAmbientSound()
        stopCustomAudio()
        previewRingtone?.stop()
    }

    private fun syncActiveFocusTimerFromStorage() {
        val state = ReminderRepository.getActiveFocusState(this)
        val wasRunning = state.optBoolean("isRunning", false)
        val totalMs = state.optLong("totalMs", selectedPomodoroMinutes * 60 * 1000L)
        val startMs = state.optLong("startMs", 0L)
        val savedTaskId = state.optString("taskId", "").takeIf { it.isNotBlank() }
        val wasBreak = state.optBoolean("isBreak", false)

        if (wasRunning && startMs > 0L) {
            val elapsed = System.currentTimeMillis() - startMs
            val remaining = totalMs - elapsed
            selectedFocusTaskId = savedTaskId
            isBreakSession = wasBreak
            pomodoroTotalMillis = totalMs

            if (remaining <= 0L) {
                inAppCountDownTimer?.cancel()
                isPomodoroRunning = false
                ReminderRepository.clearActiveFocusState(this)
                if (!isBreakSession) {
                    val mins = (totalMs / 60000L).toInt().coerceAtLeast(1)
                    ReminderRepository.recordCompletedFocusSession(
                        this,
                        sessionId = activeFocusSessionId,
                        taskId = selectedFocusTaskId,
                        actualMinutes = mins
                    )
                }
                pomodoroRemainingMillis = pomodoroTotalMillis
            } else {
                pomodoroRemainingMillis = remaining
                pomodoroStartWallClockMs = startMs
                if (!isPomodoroRunning) {
                    startWallClockCountDown(remaining)
                }
            }
        }
    }

    private fun buildMainLayoutStructure() {
        rootFrameLayout = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(bgPrimaryColor())
        }
        // Fixed ambient lighting layer: subtle petrol bloom with a restrained orange warmth.
        rootFrameLayout.addView(AtmosphereBackgroundView(this), FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))

        mainContentContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }

        headerBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setBackgroundColor(bgCardColor())
        }

        val logoIv = ImageView(this).apply {
            setImageResource(R.drawable.logo_waqt)
            val s = dp(34)
            layoutParams = LinearLayout.LayoutParams(s, s).apply { marginEnd = dp(10) }
        }
        headerBarLayout.addView(logoIv)

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        tvBrandTitle = TextView(this).apply {
            text = if (isArabic) "وَقْت" else "WAQT"
            setTextColor(textPrimaryColor())
            textSize = 21f
            setTypeface(typeface, Typeface.BOLD)
        }
        tvBrandSubtitle = TextView(this).apply {
            text = getTabSubtitleText()
            setTextColor(accentOrangeColor())
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
        }
        titleCol.addView(tvBrandTitle)
        titleCol.addView(tvBrandSubtitle)
        headerBarLayout.addView(titleCol)

        val btnLang = TextView(this).apply {
            text = if (isArabic) "EN" else "عربي"
            textSize = 12f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accentTealColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), COLOR_TEAL)
            val h = dp(36)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, h).apply { marginEnd = dp(8) }
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener { toggleLanguage() }
        }
        headerBarLayout.addView(btnLang)

        val btnSettings = TextView(this).apply {
            text = "⚙️"
            textSize = 18f
            gravity = Gravity.CENTER
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            val s = dp(36)
            layoutParams = LinearLayout.LayoutParams(s, s)
            setOnClickListener { showAccordionSettingsDialog() }
        }
        headerBarLayout.addView(btnSettings)

        mainContentContainer.addView(headerBarLayout)

        tabContentHost = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        mainContentContainer.addView(tabContentHost)

        rootFrameLayout.addView(mainContentContainer)

        // عجلة GTA V Radial Wheel
        gtaRadialOverlayView = GTARadialWheelView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            visibility = View.GONE
        }

        gtaRadialTriggerButton = FrameLayout(this).apply {
            val size = dp(62)
            layoutParams = FrameLayout.LayoutParams(size, size).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(16)
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                colors = intArrayOf(Color.parseColor("#24474B"), Color.parseColor("#10272B"))
                orientation = GradientDrawable.Orientation.TL_BR
                setStroke(dp(2), Color.parseColor("#FFFF8A3D"))
            }
            elevation = dp(18).toFloat()

            val tvIcon = TextView(context).apply {
                text = "⌃"
                textSize = 30f
                setTextColor(accentOrangeColor())
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            }
            addView(tvIcon)

            setOnTouchListener { _, event ->
                handleGTARadialTouchEvent(event)
                true
            }
        }
        rootFrameLayout.addView(gtaRadialOverlayView)
        rootFrameLayout.addView(gtaRadialTriggerButton)

        setupFloatingAIChatHeadBubble()
        setContentView(rootFrameLayout)
    }

    private fun getTabSubtitleText(): String {
        return when (currentTab) {
            0 -> if (isArabic) "🎯 المهام اليومية" else "🎯 Tasks"
            1 -> if (isArabic) "🌱 سلاسل العادات" else "🌱 Habits"
            2 -> if (isArabic) "🍅 ستوديو التركيز" else "🍅 Focus"
            3 -> if (isArabic) "📝 الملاحظات السريعة" else "📝 Notes"
            else -> ""
        }
    }

    private fun toggleLanguage() {
        isArabic = !isArabic
        getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE).edit().putBoolean("is_arabic", isArabic).apply()
        window.decorView.layoutDirection = if (isArabic) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        renderCurrentTab()
    }

    private fun renderCurrentTab() {
        tvBrandTitle.text = if (isArabic) "وَقْت" else "WAQT"
        tvBrandSubtitle.text = getTabSubtitleText()

        tabContentHost.removeAllViews()
        val view = when (currentTab) {
            0 -> buildTasksScreenView()
            1 -> buildHabitsScreenView()
            2 -> buildPomodoroScreenView()
            3 -> buildNotesScreenView()
            else -> buildTasksScreenView()
        }
        tabContentHost.addView(view)
    }

    private var radialTouchStartX = 0f
    private var radialTouchStartY = 0f
    private var selectedRadialSector = -1

    private fun handleGTARadialTouchEvent(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                radialTouchStartX = event.rawX
                radialTouchStartY = event.rawY
                selectedRadialSector = currentTab
                gtaRadialOverlayView.activeSector = selectedRadialSector
                gtaRadialOverlayView.visibility = View.VISIBLE
                triggerGentleHaptic()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - radialTouchStartX
                val dy = event.rawY - radialTouchStartY
                val dist = sqrt(dx * dx + dy * dy)
                if (dist > dp(36)) {
                    var angleDeg = Math.toDegrees(atan2(-dy.toDouble(), dx.toDouble())).toFloat()
                    if (angleDeg < 0) angleDeg += 360f

                    // قوس نصف دائري من اليسار إلى اليمين: ملاحظات، عادات، تركيز، مهام.
                    val arcAngle = angleDeg.coerceIn(0f, 180f)
                    val newSector = when (arcAngle) {
                        in 0f..45f -> 0       // يمين: المهام
                        in 45.001f..90f -> 2  // أعلى اليمين: التركيز
                        in 90.001f..135f -> 1 // أعلى اليسار: العادات
                        else -> 3             // يسار: الملاحظات
                    }
                    if (newSector != selectedRadialSector) {
                        selectedRadialSector = newSector
                        gtaRadialOverlayView.activeSector = selectedRadialSector
                        gtaRadialOverlayView.invalidate()
                        triggerGentleHaptic()
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                gtaRadialOverlayView.visibility = View.GONE
                if (selectedRadialSector != -1 && selectedRadialSector != currentTab) {
                    performLiquidWaveTransitionToTab(selectedRadialSector)
                }
            }
        }
    }

    private fun performLiquidWaveTransitionToTab(targetTab: Int) {
        currentTab = targetTab
        triggerGentleHaptic()

        tabContentHost.animate()
            .scaleX(0.96f)
            .scaleY(0.96f)
            .alpha(0.3f)
            .setDuration(120)
            .withEndAction {
                renderCurrentTab()
                tabContentHost.scaleX = 1.04f
                tabContentHost.scaleY = 1.04f
                tabContentHost.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .alpha(1f)
                    .setDuration(180)
                    .setInterpolator(AccelerateDecelerateInterpolator())
                    .start()
            }
            .start()
    }

    private fun setupFloatingAIChatHeadBubble() {
        floatingAIChatBubble = FrameLayout(this).apply {
            val size = dp(54)
            layoutParams = FrameLayout.LayoutParams(size, size).apply {
                gravity = Gravity.TOP or Gravity.START
                marginStart = dp(16)
                topMargin = dp(140)
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(220, 14, 131, 136))
                setStroke(dp(2), accentOrangeColor())
            }
            elevation = dp(16).toFloat()

            val tvIcon = TextView(context).apply {
                text = "✨"
                textSize = 22f
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            }
            addView(tvIcon)

            setupDraggableChatHeadTouch(this)
            setOnClickListener {
                triggerGentleHaptic()
                showAIChatCopilotModal()
            }
        }
        rootFrameLayout.addView(floatingAIChatBubble)
    }

    private fun setupDraggableChatHeadTouch(view: View) {
        var startX = 0f
        var startY = 0f
        var rawStartX = 0f
        var rawStartY = 0f
        var isDrag = false
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        view.setOnTouchListener { v, event ->
            val lp = v.layoutParams as FrameLayout.LayoutParams
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.marginStart.toFloat()
                    startY = lp.topMargin.toFloat()
                    rawStartX = event.rawX
                    rawStartY = event.rawY
                    isDrag = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - rawStartX
                    val dy = event.rawY - rawStartY
                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                        isDrag = true
                        lp.marginStart = (startX + dx).toInt().coerceIn(dp(6), resources.displayMetrics.widthPixels - dp(60))
                        lp.topMargin = (startY + dy).toInt().coerceIn(dp(60), resources.displayMetrics.heightPixels - dp(120))
                        v.layoutParams = lp
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isDrag) {
                        val screenW = resources.displayMetrics.widthPixels
                        val targetMargin = if (lp.marginStart + dp(27) < screenW / 2) dp(12) else screenW - dp(66)
                        lp.marginStart = targetMargin
                        v.layoutParams = lp
                    } else {
                        v.performClick()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun showAIChatCopilotModal() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = createPillDrawable(bgCardColor(), dp(22), COLOR_ORANGE)
            setPadding(dp(18), dp(16), dp(18), dp(18))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(10))
        }
        header.addView(TextView(this).apply {
            text = if (isArabic) "✨ مساعد وَقْت الذكي" else "✨ WAQT AI Planner"
            setTextColor(textPrimaryColor())
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        header.addView(TextView(this).apply {
            text = "✕"
            textSize = 18f
            setTextColor(textMutedColor())
            setPadding(dp(8), 0, dp(4), 0)
            setOnClickListener { dialog.dismiss() }
        })
        root.addView(header)

        val chatLogContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(260))
        }
        val chatScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            isFillViewport = true
        }

        val messagesBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        messagesBox.addView(createAIMessageBubble(
            if (isArabic) "أهلاً بك! أنا مساعد «وَقْت». اكتب لي أفكارك وسأقوم بترتيبها وتحويلها فوراً لمهام وعادات وملاحظات بضغطة زر."
            else "Hi! I am WAQT Copilot. Share your thoughts and I will turn them into tasks, habits, and notes."
        ))

        chatScroll.addView(messagesBox)
        chatLogContainer.addView(chatScroll)
        root.addView(chatLogContainer)

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }

        val etMsg = EditText(this).apply {
            hint = if (isArabic) "فضفض أو اكتب مهامك هنا..." else "Type ideas or tasks..."
            setHintTextColor(textMutedColor())
            setTextColor(textPrimaryColor())
            textSize = 13f
            background = createPillDrawable(bgElevatedColor(), dp(14), null)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(6) }
        }
        inputRow.addView(etMsg)

        val btnSend = TextView(this).apply {
            text = "🚀"
            textSize = 18f
            gravity = Gravity.CENTER
            background = createPillDrawable(accentOrangeColor(), dp(14), null)
            val s = dp(46)
            layoutParams = LinearLayout.LayoutParams(s, s)
            setOnClickListener {
                val userText = etMsg.text.toString().trim()
                if (userText.isNotBlank()) {
                    messagesBox.addView(createUserMessageBubble(userText))
                    etMsg.text.clear()
                    chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
                    processUserMessageWithLocalAI(userText, messagesBox, chatScroll)
                }
            }
        }
        inputRow.addView(btnSend)
        root.addView(inputRow)

        dialog.setContentView(root)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
    }

    private fun createAIMessageBubble(text: String): View {
        return TextView(this).apply {
            this.text = text
            setTextColor(textPrimaryColor())
            textSize = 13f
            background = createPillDrawable(bgElevatedColor(), dp(14), COLOR_TEAL_DEEP)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
    }

    private fun createUserMessageBubble(text: String): View {
        return LinearLayout(this).apply {
            gravity = Gravity.END
            val tv = TextView(this@MainActivity).apply {
                this.text = text
                setTextColor(Color.parseColor("#0B1417"))
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                background = createPillDrawable(accentOrangeColor(), dp(14), null)
                setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            addView(tv)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
    }

    private fun processUserMessageWithLocalAI(input: String, container: LinearLayout, scroll: ScrollView) {
        Handler(Looper.getMainLooper()).postDelayed({
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = createPillDrawable(bgElevatedColor(), dp(14), COLOR_ORANGE)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(8)
                }

                addView(TextView(this@MainActivity).apply {
                    text = if (isArabic) "💡 رتبت لك الخطة التالية:" else "💡 Action Plan:"
                    setTextColor(accentOrangeColor())
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                })

                val taskTitle = if (input.length > 30) input.substring(0, 30) + "..." else input
                addView(TextView(this@MainActivity).apply {
                    text = "• $taskTitle"
                    setTextColor(textPrimaryColor())
                    textSize = 14f
                    setPadding(0, dp(4), 0, dp(8))
                })

                val btnRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }

                val btnAddTask = TextView(this@MainActivity).apply {
                    text = if (isArabic) "+ إضافة للمهام 🎯" else "+ Add Task"
                    textSize = 11f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.parseColor("#0B1417"))
                    background = createPillDrawable(accentOrangeColor(), dp(10), null)
                    setPadding(dp(10), dp(6), dp(10), dp(6))
                    layoutParams = LinearLayout.LayoutParams(0, dp(34), 1f).apply { marginEnd = dp(6) }
                    setOnClickListener {
                        val newItem = ReminderItem(
                            id = UUID.randomUUID().toString(),
                            title = taskTitle,
                            isHabit = false,
                            hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY) + 1,
                            minute = 0,
                            priority = "high",
                            dueDateEpochDay = ReminderRepository.currentEpochDay()
                        )
                        ReminderRepository.addOrUpdateItem(this@MainActivity, newItem)
                        AlarmScheduler.scheduleNextOccurrence(this@MainActivity, newItem)
                        Toast.makeText(this@MainActivity, if (isArabic) "✓ أضيفت للمهام بنجاح!" else "Task added!", Toast.LENGTH_SHORT).show()
                        renderCurrentTab()
                    }
                }

                val btnAddNote = TextView(this@MainActivity).apply {
                    text = if (isArabic) "حفظ كملاحظة 📝" else "Save Note"
                    textSize = 11f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(textPrimaryColor())
                    background = createPillDrawable(bgCardColor(), dp(10), COLOR_TEAL)
                    setPadding(dp(10), dp(6), dp(10), dp(6))
                    layoutParams = LinearLayout.LayoutParams(0, dp(34), 1f)
                    setOnClickListener {
                        val note = NoteItem(
                            id = UUID.randomUUID().toString(),
                            title = if (isArabic) "فكرة ذكية" else "AI Thought",
                            content = input,
                            category = "ideas",
                            colorHex = "#142A2E"
                        )
                        ReminderRepository.addOrUpdateNote(this@MainActivity, note)
                        Toast.makeText(this@MainActivity, if (isArabic) "✓ حفظت في الملاحظات!" else "Note saved!", Toast.LENGTH_SHORT).show()
                        renderCurrentTab()
                    }
                }

                btnRow.addView(btnAddTask)
                btnRow.addView(btnAddNote)
                addView(btnRow)
            }
            container.addView(card)
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }, 300)
    }

    private fun buildTasksScreenView(): View {
        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            setPadding(dp(16), dp(14), dp(16), dp(84))
        }

        val allItems = ReminderRepository.getAllItems(this).filter { !it.isHabit }
        val todayEpoch = ReminderRepository.currentEpochDay()

        val filterRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(18))
        }

        val circles = listOf(
            "all" to (if (isArabic) "الكل" else "All"),
            "today" to (if (isArabic) "اليوم" else "Today"),
            "overdue" to (if (isArabic) "متأخرة" else "Late"),
            "done" to (if (isArabic) "مكتملة" else "Done")
        )

        circles.forEach { (key, label) ->
            val isSel = (taskFilter == key)
            val circleLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

                val circleView = TextView(this@MainActivity).apply {
                    text = label
                    textSize = 12f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    val s = dp(54)
                    layoutParams = LinearLayout.LayoutParams(s, s)
                    setTextColor(if (isSel) Color.parseColor("#0B1417") else textPrimaryColor())
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(if (isSel) (if (key == "overdue") Color.parseColor("#F16D68") else accentOrangeColor()) else bgCardColor())
                        setStroke(dp(1), Color.parseColor(if (key == "overdue") "#F16D68" else "#2635B6AD"))
                    }
                    elevation = if (isSel) dp(6).toFloat() else dp(2).toFloat()
                }
                addView(circleView)
                setOnClickListener {
                    triggerGentleHaptic()
                    taskFilter = key
                    currentTaskCarouselIndex = 0
                    renderCurrentTab()
                }
            }
            filterRow.addView(circleLayout)
        }
        content.addView(filterRow)

        val filteredList = allItems.filter { item ->
            val isLate = !item.isCompletedToday && (item.dueDateEpochDay < todayEpoch || (item.dueDateEpochDay == todayEpoch && isHourPassed(item.hour, item.minute)))
            when (taskFilter) {
                "today" -> !item.isCompletedToday && item.dueDateEpochDay <= todayEpoch
                "overdue" -> isLate
                "done" -> item.isCompletedToday
                else -> true
            }
        }.filter {
            taskSearchQuery.isBlank() || it.title.contains(taskSearchQuery, ignoreCase = true)
        }

        if (filteredList.isEmpty()) {
            content.addView(buildEmptyCardPlaceholder(
                if (isArabic) "مساحتك جاهزة لأول إنجاز" else "Ready for your first win",
                if (isArabic) "أضف مهمة جديدة من الشريط الجانبي، ورتّب يومك خطوة بخطوة." else "Add a task from the side rail and shape your day."
            ))
        } else {
            content.addView(buildStackedTasksCarousel(filteredList))
        }
        root.addView(content)

        val leftDock = buildTasksLeftSlideOutDock()
        root.addView(leftDock)
        return root
    }

    private fun isHourPassed(hour: Int, min: Int): Boolean {
        val now = Calendar.getInstance()
        val nowM = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        return (hour * 60 + min) < nowM
    }

    private fun buildStackedTasksCarousel(tasks: List<ReminderItem>): View {
        val total = tasks.size
        val activeIdx = currentTaskCarouselIndex.coerceIn(0, total - 1)
        val stackContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            clipChildren = false
            clipToPadding = false
            cameraDistance = dp(12000).toFloat()
        }

        val navCounter = TextView(this).apply {
            text = if (isArabic) "${activeIdx + 1} من $total" else "${activeIdx + 1} of $total"
            setTextColor(Color.parseColor("#D9F5F0"))
            textSize = 11f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(Color.parseColor("#CC142A2E"))
                setStroke(dp(1), Color.parseColor("#6650C9C0"))
            }
            elevation = dp(4).toFloat()
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            }
        }
        stackContainer.addView(navCounter)

        fun styleRearCard(card: View, side: Int) {
            setCardTreeEnabled(card, false)
            card.scaleX = 0.93f
            card.scaleY = 0.93f
            card.translationX = (side * dp(54)).toFloat()
            card.translationY = dp(34).toFloat()
            card.rotationY = side * -8f
            card.alpha = 0.62f
            card.elevation = dp(3).toFloat()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                card.setRenderEffect(RenderEffect.createBlurEffect(dp(2).toFloat(), dp(2).toFloat(), Shader.TileMode.CLAMP))
            }
        }

        if (activeIdx > 0) {
            val previous = buildSingleTaskCardView(tasks[activeIdx - 1], isForeground = false).apply {
                styleRearCard(this, -1)
            }
            stackContainer.addView(previous)
        }
        if (activeIdx + 1 < total) {
            val next = buildSingleTaskCardView(tasks[activeIdx + 1], isForeground = false).apply {
                styleRearCard(this, 1)
            }
            stackContainer.addView(next)
        }

        val frontCard = buildSingleTaskCardView(tasks[activeIdx], isForeground = true).apply {
            scaleX = 1f
            scaleY = 1f
            translationY = dp(14).toFloat()
            translationX = 0f
            rotationY = 0f
            alpha = 1f
            elevation = dp(22).toFloat()
        }
        setupCardSwipeNavigation(frontCard) { direction ->
            if (direction > 0 && currentTaskCarouselIndex < total - 1) {
                animateCarouselExit(frontCard, direction)
                currentTaskCarouselIndex++
                triggerGentleHaptic()
                stackContainer.postDelayed({ renderCurrentTab() }, 90)
            } else if (direction < 0 && currentTaskCarouselIndex > 0) {
                animateCarouselExit(frontCard, direction)
                currentTaskCarouselIndex--
                triggerGentleHaptic()
                stackContainer.postDelayed({ renderCurrentTab() }, 90)
            }
        }
        stackContainer.addView(frontCard)
        return stackContainer
    }

    private fun buildSingleTaskCardView(item: ReminderItem, isForeground: Boolean): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(bgElevatedColor(), bgCardColor(), Color.parseColor(if (isDarkMode) "#102226" else "#F7FBFA"))
            ).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.parseColor(if (isForeground && item.priority == "high") "#CCFF8A3D" else if (isForeground) "#9950C9C0" else "#5535B6AD"))
            }
            setPadding(dp(18), dp(16), dp(18), dp(16))
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                leftMargin = dp(22)
                rightMargin = dp(22)
                topMargin = dp(28)
            }
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
        }

        val btnDelete = TextView(this).apply {
            text = "✕"
            textSize = 16f
            setTextColor(Color.parseColor("#F16D68"))
            setTypeface(typeface, Typeface.BOLD)
            val s = dp(32)
            layoutParams = LinearLayout.LayoutParams(s, s)
            gravity = Gravity.CENTER
            background = createPillDrawable(bgElevatedColor(), dp(16), null)
            setOnClickListener {
                if (isForeground) {
                    ReminderRepository.deleteItem(this@MainActivity, item.id)
                    AlarmScheduler.cancelAlarm(this@MainActivity, item.id)
                    Toast.makeText(this@MainActivity, if (isArabic) "تم حذف المهمة" else "Task deleted", Toast.LENGTH_SHORT).show()
                    renderCurrentTab()
                }
            }
        }
        topRow.addView(btnDelete)

        val spacer = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(1), 1f) }
        topRow.addView(spacer)

        val dateStr = if (item.dueDateString.isNotBlank()) item.dueDateString else "اليوم"
        val tvDateBadge = TextView(this).apply {
            text = "📅 $dateStr"
            textSize = 12f
            setTextColor(textMutedColor())
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = createPillDrawable(bgElevatedColor(), dp(10), null)
        }
        topRow.addView(tvDateBadge)
        card.addView(topRow)

        val tvTitle = TextView(this).apply {
            text = item.title
            setTextColor(textPrimaryColor())
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(12), 0, dp(4))
        }
        card.addView(tvTitle)

        val pctRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(10))
        }

        val pBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = item.completionPercentage
            progressTintList = ColorStateList.valueOf(if (item.completionPercentage == 100) Color.parseColor("#42C98A") else accentOrangeColor())
            progressBackgroundTintList = ColorStateList.valueOf(bgElevatedColor())
            layoutParams = LinearLayout.LayoutParams(0, dp(8), 1f).apply { marginEnd = dp(8) }
        }
        pctRow.addView(pBar)

        val tvPctNum = TextView(this).apply {
            text = "${item.completionPercentage}%"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accentOrangeColor())
        }
        pctRow.addView(tvPctNum)
        card.addView(pctRow)

        val iconsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(4))
        }

        iconsRow.addView(createCardActionCircle("✏️", "Edit") {
            showAddOrEditTaskModal(item)
        })

        iconsRow.addView(createCardActionCircle("⏰", "Alarm") {
            TimePickerDialog(this, { _, h, m ->
                val updated = item.copy(hour = h, minute = m)
                ReminderRepository.addOrUpdateItem(this, updated)
                AlarmScheduler.scheduleNextOccurrence(this, updated)
                renderCurrentTab()
            }, item.hour, item.minute, false).show()
        })

        iconsRow.addView(createCardActionCircle("💤", "Snooze") {
            AlarmScheduler.scheduleSnooze(this, item, 10)
            Toast.makeText(this, if (isArabic) "تم التأجيل 10 دقائق" else "Snoozed 10m", Toast.LENGTH_SHORT).show()
        })

        iconsRow.addView(createCardActionCircle("🍅", "Focus") {
            selectedFocusTaskId = item.id
            isPomodoroLinkedToTask = true
            currentTab = 2
            renderCurrentTab()
        })

        iconsRow.addView(createCardActionCircle("％", "Progress") {
            showTaskPercentageDialog(item)
        })

        card.addView(iconsRow)
        return card
    }

    private fun createCardActionCircle(icon: String, contentDesc: String, onClick: () -> Unit): View {
        return TextView(this).apply {
            text = icon
            textSize = 15f
            gravity = Gravity.CENTER
            val s = dp(42)
            layoutParams = LinearLayout.LayoutParams(s, s).apply { marginStart = dp(6); marginEnd = dp(6) }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(bgElevatedColor())
                setStroke(dp(1), Color.parseColor("#3335B6AD"))
            }
            setOnClickListener {
                triggerGentleHaptic()
                onClick()
            }
        }
    }

    private fun showTaskPercentageDialog(item: ReminderItem) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = createPillDrawable(bgCardColor(), dp(20), COLOR_ORANGE)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        v.addView(TextView(this).apply {
            text = if (isArabic) "حدد نسبة إنجاز المهمة:" else "Set Completion Percentage:"
            setTextColor(textPrimaryColor())
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
        })

        val tvVal = TextView(this).apply {
            text = "${item.completionPercentage}%"
            textSize = 24f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accentOrangeColor())
            setPadding(0, dp(10), 0, dp(6))
        }
        v.addView(tvVal)

        var selectedPct = item.completionPercentage
        val seek = SeekBar(this).apply {
            max = 100
            progress = selectedPct
            progressTintList = ColorStateList.valueOf(accentOrangeColor())
            thumbTintList = ColorStateList.valueOf(accentOrangeColor())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, prog: Int, fromUser: Boolean) {
                    selectedPct = prog
                    tvVal.text = "$selectedPct%"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        v.addView(seek)

        val btnSave = Button(this).apply {
            text = if (isArabic) "حفظ النسبة" else "Save"
            isAllCaps = false
            setTextColor(Color.parseColor("#0B1417"))
            backgroundTintList = ColorStateList.valueOf(accentOrangeColor())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(12) }
            setOnClickListener {
                ReminderRepository.updateTaskPercentage(this@MainActivity, item.id, selectedPct)
                d.dismiss()
                renderCurrentTab()
            }
        }
        v.addView(btnSave)

        d.setContentView(v)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.85).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    private fun buildTasksLeftSlideOutDock(): View {
        val dockLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable().apply {
                cornerRadii = floatArrayOf(0f, 0f, dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), 0f, 0f)
                setColor(Color.argb(240, 14, 34, 45))
                setStroke(dp(1), Color.parseColor("#4DFF8A3D"))
            }
            setPadding(dp(8), dp(16), dp(8), dp(16))
            val w = if (isTasksLeftDockOpen) dp(60) else dp(22)
            layoutParams = FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER_VERTICAL or Gravity.LEFT
            }
            elevation = dp(16).toFloat()
        }

        if (!isTasksLeftDockOpen) {
            val tvHandle = TextView(this).apply {
                text = "▸"
                textSize = 16f
                setTextColor(accentOrangeColor())
                gravity = Gravity.CENTER
            }
            dockLayout.addView(tvHandle)
            dockLayout.setOnClickListener {
                isTasksLeftDockOpen = true
                renderCurrentTab()
            }
        } else {
            dockLayout.addView(createDockIcon("➕") {
                showAddOrEditTaskModal(null)
            })

            dockLayout.addView(createDockIcon("⚡") {
                createQuickPresetTask(15)
            })

            dockLayout.addView(createDockIcon("🔍") {
                showSearchTasksInputDialog()
            })

            val tvClose = TextView(this).apply {
                text = "◂"
                textSize = 16f
                setTextColor(textMutedColor())
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, 0)
                setOnClickListener {
                    isTasksLeftDockOpen = false
                    renderCurrentTab()
                }
            }
            dockLayout.addView(tvClose)
        }
        return dockLayout
    }

    private fun createDockIcon(icon: String, onClick: () -> Unit): View {
        return TextView(this).apply {
            text = icon
            textSize = 18f
            gravity = Gravity.CENTER
            val s = dp(42)
            layoutParams = LinearLayout.LayoutParams(s, s).apply { bottomMargin = dp(10) }
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setOnClickListener {
                triggerGentleHaptic()
                onClick()
            }
        }
    }

    private fun showSearchTasksInputDialog() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = createPillDrawable(bgCardColor(), dp(18), COLOR_TEAL)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val et = EditText(this).apply {
            hint = if (isArabic) "ابحث عن مهمة..." else "Search task..."
            setHintTextColor(textMutedColor())
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        v.addView(et)

        val btn = Button(this).apply {
            text = if (isArabic) "بحث" else "Search"
            isAllCaps = false
            setTextColor(Color.parseColor("#0B1417"))
            backgroundTintList = ColorStateList.valueOf(accentTealColor())
            setOnClickListener {
                taskSearchQuery = et.text.toString().trim()
                d.dismiss()
                renderCurrentTab()
            }
        }
        v.addView(btn)
        d.setContentView(v)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.85).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    private fun showAddOrEditTaskModal(existingItem: ReminderItem?) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val scroll = ScrollView(this).apply {
            background = createPillDrawable(bgCardColor(), dp(22), COLOR_ORANGE)
        }
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        v.addView(TextView(this).apply {
            text = if (existingItem == null) (if (isArabic) "➕ إضافة مهمة جديدة" else "➕ New Task") else (if (isArabic) "✏️ تعديل المهمة" else "✏️ Edit Task")
            setTextColor(textPrimaryColor())
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
        })

        val etTitle = EditText(this).apply {
            hint = if (isArabic) "اسم المهمة..." else "Task Title..."
            setText(existingItem?.title ?: "")
            setHintTextColor(textMutedColor())
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) }
        }
        v.addView(etTitle)

        var chosenEpochDay = existingItem?.dueDateEpochDay ?: ReminderRepository.currentEpochDay()
        var chosenDateString = existingItem?.dueDateString ?: SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        val btnPickDate = TextView(this).apply {
            text = "📅 " + (if (isArabic) "تاريخ المهمة: " else "Date: ") + chosenDateString
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), COLOR_TEAL)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(10) }
            setOnClickListener {
                val cal = Calendar.getInstance()
                DatePickerDialog(this@MainActivity, { _, year, month, day ->
                    val selCal = Calendar.getInstance().apply { set(year, month, day) }
                    chosenEpochDay = (year * 366L) + selCal.get(Calendar.DAY_OF_YEAR)
                    chosenDateString = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
                    text = "📅 " + (if (isArabic) "تاريخ المهمة: " else "Date: ") + chosenDateString
                }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
            }
        }
        v.addView(btnPickDate)

        var chosenHour = existingItem?.hour ?: 9
        var chosenMinute = existingItem?.minute ?: 0
        val btnPickTime = TextView(this).apply {
            val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, chosenHour); set(Calendar.MINUTE, chosenMinute) }
            text = "⏰ " + (if (isArabic) "وقت التنبيه: " else "Alarm: ") + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(c.time)
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), COLOR_ORANGE)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(8) }
            setOnClickListener {
                TimePickerDialog(this@MainActivity, { _, h, m ->
                    chosenHour = h
                    chosenMinute = m
                    val tCal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m) }
                    text = "⏰ " + (if (isArabic) "وقت التنبيه: " else "Alarm: ") + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(tCal.time)
                }, chosenHour, chosenMinute, false).show()
            }
        }
        v.addView(btnPickTime)

        val btnSave = Button(this).apply {
            text = if (isArabic) "حفظ وضبط المنبه" else "Save Task"
            isAllCaps = false
            setTextColor(Color.parseColor("#0B1417"))
            backgroundTintList = ColorStateList.valueOf(accentOrangeColor())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(16) }
            setOnClickListener {
                val t = etTitle.text.toString().trim()
                if (t.isNotBlank()) {
                    val item = (existingItem ?: ReminderItem(
                        id = UUID.randomUUID().toString(),
                        title = t,
                        isHabit = false,
                        hour = chosenHour,
                        minute = chosenMinute
                    )).copy(
                        title = t,
                        hour = chosenHour,
                        minute = chosenMinute,
                        dueDateEpochDay = chosenEpochDay,
                        dueDateString = chosenDateString
                    )
                    ReminderRepository.addOrUpdateItem(this@MainActivity, item)
                    AlarmScheduler.scheduleNextOccurrence(this@MainActivity, item)
                    d.dismiss()
                    renderCurrentTab()
                }
            }
        }
        v.addView(btnSave)

        scroll.addView(v)
        d.setContentView(scroll)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    private fun buildHabitsScreenView(): View {
        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            setPadding(dp(16), dp(14), dp(16), dp(84))
        }

        val categories = ReminderRepository.getAllHabitCategories(this)
        val catHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(10))
        }

        val catScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val catRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        categories.forEach { c ->
            val isSel = (habitSelectedCategory == c.id)
            val chip = TextView(this).apply {
                text = "${c.icon} ${c.name}"
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (isSel) Color.parseColor("#0B1417") else textPrimaryColor())
                background = createPillDrawable(if (isSel) accentOrangeColor() else bgCardColor(), dp(14), if (isSel) null else "#2635B6AD")
                setPadding(dp(14), dp(8), dp(14), dp(8))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)).apply { marginEnd = dp(6) }
                setOnClickListener {
                    triggerGentleHaptic()
                    habitSelectedCategory = c.id
                    currentHabitCarouselIndex = 0
                    renderCurrentTab()
                }
            }
            catRow.addView(chip)
        }
        catScroll.addView(catRow)
        catHeaderRow.addView(catScroll)

        val btnAddCat = TextView(this).apply {
            text = "➕"
            textSize = 14f
            gravity = Gravity.CENTER
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            val s = dp(38)
            layoutParams = LinearLayout.LayoutParams(s, s).apply { marginStart = dp(6) }
            setOnClickListener { showAddHabitCategoryDialog() }
        }
        catHeaderRow.addView(btnAddCat)
        content.addView(catHeaderRow)

        val habits = ReminderRepository.getAllItems(this).filter { it.isHabit }.filter {
            habitSelectedCategory == "all" || it.category == habitSelectedCategory
        }

        if (habits.isEmpty()) {
            content.addView(buildEmptyCardPlaceholder(
                if (isArabic) "ابدأ بعادة صغيرة" else "Start with one small habit",
                if (isArabic) "أضف عادة وحدد أيامها وتذكيرها، وتابع تقدمك بهدوء." else "Add a habit, choose its days and reminder, then track it gently."
            ))
        } else {
            content.addView(buildStackedHabitsCarousel(habits))
        }
        root.addView(content)

        root.addView(buildHabitsLeftSlideOutDock())
        return root
    }

    private fun showAddHabitCategoryDialog() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = createPillDrawable(bgCardColor(), dp(18), COLOR_ORANGE)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val et = EditText(this).apply {
            hint = if (isArabic) "اسم التصنيف الجديد (مثال: مالية)..." else "New category..."
            setHintTextColor(textMutedColor())
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        v.addView(et)
        val btn = Button(this).apply {
            text = if (isArabic) "+ إضافة التصنيف" else "+ Add"
            isAllCaps = false
            setTextColor(Color.parseColor("#0B1417"))
            backgroundTintList = ColorStateList.valueOf(accentOrangeColor())
            setOnClickListener {
                val name = et.text.toString().trim()
                if (name.isNotBlank()) {
                    ReminderRepository.addHabitCategory(this@MainActivity, HabitCategoryItem(UUID.randomUUID().toString(), name, "⭐"))
                    d.dismiss()
                    renderCurrentTab()
                }
            }
        }
        v.addView(btn)
        d.setContentView(v)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.85).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    private fun buildStackedHabitsCarousel(habits: List<ReminderItem>): View {
        val total = habits.size
        val activeIdx = currentHabitCarouselIndex.coerceIn(0, total - 1)
        val stackContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            clipChildren = false
            clipToPadding = false
            cameraDistance = dp(12000).toFloat()
        }
        val navCounter = TextView(this).apply {
            text = if (isArabic) "${activeIdx + 1} من $total" else "${activeIdx + 1} of $total"
            setTextColor(Color.parseColor("#D9F5F0"))
            textSize = 11f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(Color.parseColor("#CC142A2E"))
                setStroke(dp(1), Color.parseColor("#6650C9C0"))
            }
            elevation = dp(4).toFloat()
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            }
        }
        stackContainer.addView(navCounter)

        fun styleRearCard(card: View, side: Int) {
            setCardTreeEnabled(card, false)
            card.scaleX = 0.93f
            card.scaleY = 0.93f
            card.translationX = (side * dp(54)).toFloat()
            card.translationY = dp(34).toFloat()
            card.rotationY = side * -8f
            card.alpha = 0.62f
            card.elevation = dp(3).toFloat()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                card.setRenderEffect(RenderEffect.createBlurEffect(dp(2).toFloat(), dp(2).toFloat(), Shader.TileMode.CLAMP))
            }
        }
        if (activeIdx > 0) {
            stackContainer.addView(buildSingleHabitCardView(habits[activeIdx - 1], isForeground = false).apply { styleRearCard(this, -1) })
        }
        if (activeIdx + 1 < total) {
            stackContainer.addView(buildSingleHabitCardView(habits[activeIdx + 1], isForeground = false).apply { styleRearCard(this, 1) })
        }
        val frontCard = buildSingleHabitCardView(habits[activeIdx], isForeground = true).apply {
            scaleX = 1f
            scaleY = 1f
            translationY = dp(14).toFloat()
            translationX = 0f
            rotationY = 0f
            alpha = 1f
            elevation = dp(22).toFloat()
        }
        setupCardSwipeNavigation(frontCard) { direction ->
            if (direction > 0 && currentHabitCarouselIndex < total - 1) {
                animateCarouselExit(frontCard, direction)
                currentHabitCarouselIndex++
                triggerGentleHaptic()
                stackContainer.postDelayed({ renderCurrentTab() }, 90)
            } else if (direction < 0 && currentHabitCarouselIndex > 0) {
                animateCarouselExit(frontCard, direction)
                currentHabitCarouselIndex--
                triggerGentleHaptic()
                stackContainer.postDelayed({ renderCurrentTab() }, 90)
            }
        }
        stackContainer.addView(frontCard)
        return stackContainer
    }

    private fun setCardTreeEnabled(view: View, enabled: Boolean) {
        view.isEnabled = enabled
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) setCardTreeEnabled(view.getChildAt(i), enabled)
        }
    }

    private fun animateCarouselExit(card: View, direction: Int) {
        card.animate()
            .translationX((direction * -dp(70)).toFloat())
            .rotationY(direction * 7f)
            .alpha(0.25f)
            .setDuration(90L)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .start()
    }

    private fun buildSingleHabitCardView(habit: ReminderItem, isForeground: Boolean): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(bgElevatedColor(), bgCardColor(), Color.parseColor(if (isDarkMode) "#102226" else "#F7FBFA"))
            ).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.parseColor(if (isForeground && habit.isPaused) "#CCFF8A3D" else if (isForeground) "#9950C9C0" else "#5535B6AD"))
            }
            setPadding(dp(18), dp(16), dp(18), dp(16))
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                leftMargin = dp(22)
                rightMargin = dp(22)
                topMargin = dp(28)
            }
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
        }

        val btnDel = TextView(this).apply {
            text = "✕"
            textSize = 16f
            setTextColor(Color.parseColor("#F16D68"))
            setTypeface(typeface, Typeface.BOLD)
            val s = dp(32)
            layoutParams = LinearLayout.LayoutParams(s, s)
            gravity = Gravity.CENTER
            background = createPillDrawable(bgElevatedColor(), dp(16), null)
            setOnClickListener {
                if (isForeground) {
                    ReminderRepository.deleteItem(this@MainActivity, habit.id)
                    AlarmScheduler.cancelAlarm(this@MainActivity, habit.id)
                    renderCurrentTab()
                }
            }
        }
        topRow.addView(btnDel)

        val spacer = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(1), 1f) }
        topRow.addView(spacer)

        val tvStatus = TextView(this).apply {
            text = if (habit.isPaused) "⏸ متوقفة" else "🔥 ${habit.streakCount} أيام"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accentOrangeColor())
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = createPillDrawable(bgElevatedColor(), dp(10), null)
        }
        topRow.addView(tvStatus)
        card.addView(topRow)

        val tvTitle = TextView(this).apply {
            text = habit.title
            setTextColor(textPrimaryColor())
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(10), 0, dp(4))
        }
        card.addView(tvTitle)

        val progressText = "${habit.currentProgressToday} / ${habit.targetValue} ${habit.targetUnit}"
        card.addView(TextView(this).apply {
            text = "🎯 $progressText  •  ⏰ ${String.format(Locale.US, "%02d:%02d", habit.hour, habit.minute)}"
            setTextColor(textMutedColor())
            textSize = 13f
            setPadding(0, 0, 0, dp(10))
        })

        val iconsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(4))
        }

        iconsRow.addView(createCardActionCircle("🔥", "Streak") {
            Toast.makeText(this, if (isArabic) "🔥 سلسلة مستمرة: ${habit.streakCount} أيام!" else "Streak: ${habit.streakCount} days", Toast.LENGTH_SHORT).show()
        })

        iconsRow.addView(createCardActionCircle("🎯", "+1") {
            ReminderRepository.incrementHabitStep(this, habit.id)
            renderCurrentTab()
        })

        iconsRow.addView(createCardActionCircle("📅", "Schedule") {
            showEditHabitDaysDialog(habit)
        })

        iconsRow.addView(createCardActionCircle(if (habit.isPaused) "▶" else "❄️", "Freeze") {
            ReminderRepository.toggleHabitPause(this, habit.id)
            renderCurrentTab()
        })

        iconsRow.addView(createCardActionCircle("⏰", "Alarm") {
            TimePickerDialog(this, { _, h, m ->
                val u = habit.copy(hour = h, minute = m)
                ReminderRepository.addOrUpdateItem(this, u)
                AlarmScheduler.scheduleNextOccurrence(this, u)
                renderCurrentTab()
            }, habit.hour, habit.minute, false).show()
        })

        iconsRow.addView(createCardActionCircle("✏️", "Edit") {
            showAddOrEditHabitModal(habit)
        })

        card.addView(iconsRow)
        return card
    }

    private fun showEditHabitDaysDialog(habit: ReminderItem) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = createPillDrawable(bgCardColor(), dp(20), COLOR_ORANGE)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }

        v.addView(TextView(this).apply {
            text = if (isArabic) "حدد أيام تكرار العادة:" else "Select Active Days:"
            setTextColor(textPrimaryColor())
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 0, 0, dp(12))
        })

        val currentDays = habit.customDaysCsv.split(",").toMutableSet()
        val dayNames = if (isArabic) listOf("سبت", "حد", "اتنين", "تلات", "أربع", "خميس", "جمعة")
        else listOf("Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri")

        val daysRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        for (i in 1..7) {
            val dayId = i.toString()
            val isSelected = currentDays.contains(dayId)
            val dayChip = TextView(this).apply {
                text = dayNames[i - 1]
                textSize = 12f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (isSelected) Color.parseColor("#0B1417") else textPrimaryColor())
                background = createPillDrawable(if (isSelected) accentOrangeColor() else bgElevatedColor(), dp(12), null)
                val s = dp(40)
                layoutParams = LinearLayout.LayoutParams(0, s, 1f).apply { marginEnd = dp(4) }
                setOnClickListener {
                    if (currentDays.contains(dayId)) currentDays.remove(dayId) else currentDays.add(dayId)
                    val active = currentDays.contains(dayId)
                    setTextColor(if (active) Color.parseColor("#0B1417") else textPrimaryColor())
                    background = createPillDrawable(if (active) accentOrangeColor() else bgElevatedColor(), dp(12), null)
                }
            }
            daysRow.addView(dayChip)
        }
        v.addView(daysRow)

        val btnSave = Button(this).apply {
            text = if (isArabic) "حفظ الأيام" else "Save"
            isAllCaps = false
            setTextColor(Color.parseColor("#0B1417"))
            backgroundTintList = ColorStateList.valueOf(accentOrangeColor())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(16) }
            setOnClickListener {
                val csv = currentDays.sorted().joinToString(",")
                val u = habit.copy(customDaysCsv = csv)
                ReminderRepository.addOrUpdateItem(this@MainActivity, u)
                d.dismiss()
                renderCurrentTab()
            }
        }
        v.addView(btnSave)

        d.setContentView(v)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    private fun buildHabitsLeftSlideOutDock(): View {
        val dockLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable().apply {
                cornerRadii = floatArrayOf(0f, 0f, dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), 0f, 0f)
                setColor(Color.argb(240, 14, 34, 45))
                setStroke(dp(1), Color.parseColor("#4DFF8A3D"))
            }
            setPadding(dp(8), dp(16), dp(8), dp(16))
            val w = if (isHabitsLeftDockOpen) dp(60) else dp(22)
            layoutParams = FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER_VERTICAL or Gravity.LEFT
            }
            elevation = dp(16).toFloat()
        }

        if (!isHabitsLeftDockOpen) {
            val tvHandle = TextView(this).apply {
                text = "▸"
                textSize = 16f
                setTextColor(accentOrangeColor())
                gravity = Gravity.CENTER
            }
            dockLayout.addView(tvHandle)
            dockLayout.setOnClickListener {
                isHabitsLeftDockOpen = true
                renderCurrentTab()
            }
        } else {
            dockLayout.addView(createDockIcon("➕") {
                showAddOrEditHabitModal(null)
            })

            dockLayout.addView(createDockIcon("✨") {
                Toast.makeText(this, if (isArabic) "اختر تصنيفاً من الأعلى لإظهار العادات الجاهزة" else "Pick category above", Toast.LENGTH_SHORT).show()
            })

            dockLayout.addView(createDockIcon("🔍") {
                Toast.makeText(this, if (isArabic) "اختر تصنيفاً للفلترة" else "Filter by category", Toast.LENGTH_SHORT).show()
            })

            val tvClose = TextView(this).apply {
                text = "◂"
                textSize = 16f
                setTextColor(textMutedColor())
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, 0)
                setOnClickListener {
                    isHabitsLeftDockOpen = false
                    renderCurrentTab()
                }
            }
            dockLayout.addView(tvClose)
        }
        return dockLayout
    }

    private fun showAddOrEditHabitModal(existingHabit: ReminderItem?) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val scroll = ScrollView(this).apply {
            background = createPillDrawable(bgCardColor(), dp(22), COLOR_ORANGE)
        }
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        v.addView(TextView(this).apply {
            text = if (existingHabit == null) (if (isArabic) "🌱 إضافة عادة جديدة" else "🌱 New Habit") else (if (isArabic) "✏️ تعديل العادة" else "✏️ Edit Habit")
            setTextColor(textPrimaryColor())
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
        })

        val etTitle = EditText(this).apply {
            hint = if (isArabic) "اسم العادة (مثال: قراءة 15 صفحة)..." else "Habit Name..."
            setText(existingHabit?.title ?: "")
            setHintTextColor(textMutedColor())
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) }
        }
        v.addView(etTitle)

        v.addView(TextView(this).apply {
            text = if (isArabic) "اختر أيام التكرار الأسبوعية:" else "Select Active Days:"
            setTextColor(accentTealColor())
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(12), 0, dp(6))
        })

        val selectedDaysSet = (existingHabit?.customDaysCsv?.split(",")?.toMutableSet() ?: mutableSetOf("1", "2", "3", "4", "5", "6", "7"))
        val dayNames = if (isArabic) listOf("سبت", "حد", "اتنين", "تلات", "أربع", "خميس", "جمعة")
        else listOf("Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri")

        val daysRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        for (i in 1..7) {
            val dId = i.toString()
            val isSel = selectedDaysSet.contains(dId)
            val dChip = TextView(this).apply {
                text = dayNames[i - 1]
                textSize = 11f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (isSel) Color.parseColor("#0B1417") else textPrimaryColor())
                background = createPillDrawable(if (isSel) accentOrangeColor() else bgElevatedColor(), dp(12), null)
                val s = dp(38)
                layoutParams = LinearLayout.LayoutParams(0, s, 1f).apply { marginEnd = dp(4) }
                setOnClickListener {
                    if (selectedDaysSet.contains(dId)) selectedDaysSet.remove(dId) else selectedDaysSet.add(dId)
                    val active = selectedDaysSet.contains(dId)
                    setTextColor(if (active) Color.parseColor("#0B1417") else textPrimaryColor())
                    background = createPillDrawable(if (active) accentOrangeColor() else bgElevatedColor(), dp(12), null)
                }
            }
            daysRow.addView(dChip)
        }
        v.addView(daysRow)

        var habitHour = existingHabit?.hour ?: 9
        var habitMinute = existingHabit?.minute ?: 0
        val btnPickTime = TextView(this).apply {
            val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, habitHour); set(Calendar.MINUTE, habitMinute) }
            text = "⏰ " + (if (isArabic) "وقت التذكير: " else "Time: ") + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(c.time)
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), COLOR_ORANGE)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(12) }
            setOnClickListener {
                TimePickerDialog(this@MainActivity, { _, h, m ->
                    habitHour = h
                    habitMinute = m
                    val tCal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m) }
                    text = "⏰ " + (if (isArabic) "وقت التذكير: " else "Time: ") + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(tCal.time)
                }, habitHour, habitMinute, false).show()
            }
        }
        v.addView(btnPickTime)

        val btnSave = Button(this).apply {
            text = if (isArabic) "حفظ العادة وربطها بالمهام" else "Save Habit"
            isAllCaps = false
            setTextColor(Color.parseColor("#0B1417"))
            backgroundTintList = ColorStateList.valueOf(accentOrangeColor())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(16) }
            setOnClickListener {
                val t = etTitle.text.toString().trim()
                if (t.isNotBlank()) {
                    val habit = (existingHabit ?: ReminderItem(
                        id = UUID.randomUUID().toString(),
                        title = t,
                        isHabit = true,
                        hour = habitHour,
                        minute = habitMinute
                    )).copy(
                        title = t,
                        hour = habitHour,
                        minute = habitMinute,
                        customDaysCsv = selectedDaysSet.sorted().joinToString(","),
                        category = habitSelectedCategory.takeIf { it != "all" } ?: "general"
                    )
                    ReminderRepository.addOrUpdateItem(this@MainActivity, habit)
                    AlarmScheduler.scheduleNextOccurrence(this@MainActivity, habit)
                    d.dismiss()
                    renderCurrentTab()
                }
            }
        }
        v.addView(btnSave)

        scroll.addView(v)
        d.setContentView(scroll)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    private fun buildNotesScreenView(): View {
        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            setPadding(dp(16), dp(14), dp(16), dp(84))
        }

        val notes = ReminderRepository.getAllNotes(this).filter {
            noteSelectedCategory == "all" || it.category == noteSelectedCategory
        }.filter {
            noteSearchQuery.isBlank() || it.title.contains(noteSearchQuery, ignoreCase = true) || it.content.contains(noteSearchQuery, ignoreCase = true)
        }

        if (notes.isEmpty()) {
            content.addView(buildEmptyCardPlaceholder(
                if (isArabic) "لا توجد ملاحظات مسجلة" else "No notes found",
                if (isArabic) "اسحب الشريط الجانبي الأيسر لإضافة ملاحظة جديدة أو تفعيل الملاحظة العائمة فوق التطبيقات."
                else "Slide from left to add note."
            ))
        } else {
            content.addView(buildStackedNotesCarousel(notes))
        }
        root.addView(content)

        root.addView(buildNotesLeftSlideOutDock())
        return root
    }

    private fun buildStackedNotesCarousel(notes: List<NoteItem>): View {
        val total = notes.size
        val activeIdx = currentNoteCarouselIndex.coerceIn(0, total - 1)
        val stackContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            clipChildren = false
            clipToPadding = false
            cameraDistance = dp(12000).toFloat()
        }
        stackContainer.addView(TextView(this).apply {
            text = if (isArabic) "${activeIdx + 1} من $total" else "${activeIdx + 1} of $total"
            setTextColor(Color.parseColor("#D9F5F0"))
            textSize = 11f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(Color.parseColor("#CC142A2E"))
                setStroke(dp(1), Color.parseColor("#6650C9C0"))
            }
            elevation = dp(4).toFloat()
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            }
        })
        fun styleRearCard(card: View, side: Int) {
            setCardTreeEnabled(card, false)
            card.scaleX = 0.93f
            card.scaleY = 0.93f
            card.translationX = (side * dp(54)).toFloat()
            card.translationY = dp(34).toFloat()
            card.rotationY = side * -8f
            card.alpha = 0.62f
            card.elevation = dp(3).toFloat()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                card.setRenderEffect(RenderEffect.createBlurEffect(dp(2).toFloat(), dp(2).toFloat(), Shader.TileMode.CLAMP))
            }
        }
        if (activeIdx > 0) stackContainer.addView(buildSingleNoteCardView(notes[activeIdx - 1], false).apply { styleRearCard(this, -1) })
        if (activeIdx + 1 < total) stackContainer.addView(buildSingleNoteCardView(notes[activeIdx + 1], false).apply { styleRearCard(this, 1) })
        val frontCard = buildSingleNoteCardView(notes[activeIdx], true).apply {
            scaleX = 1f; scaleY = 1f; translationY = dp(14).toFloat(); translationX = 0f
            rotationY = 0f; alpha = 1f; elevation = dp(22).toFloat()
        }
        setupCardSwipeNavigation(frontCard) { direction ->
            if (direction > 0 && currentNoteCarouselIndex < total - 1) {
                animateCarouselExit(frontCard, direction)
                currentNoteCarouselIndex++
                triggerGentleHaptic()
                stackContainer.postDelayed({ renderCurrentTab() }, 90)
            } else if (direction < 0 && currentNoteCarouselIndex > 0) {
                animateCarouselExit(frontCard, direction)
                currentNoteCarouselIndex--
                triggerGentleHaptic()
                stackContainer.postDelayed({ renderCurrentTab() }, 90)
            }
        }
        stackContainer.addView(frontCard)
        return stackContainer
    }

    private fun buildSingleNoteCardView(note: NoteItem, isForeground: Boolean): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor(note.colorHex))
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.parseColor(if (isForeground) "#9950C9C0" else "#5535B6AD"))
            }
            setPadding(dp(18), dp(16), dp(18), dp(16))
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                leftMargin = dp(22)
                rightMargin = dp(22)
                topMargin = dp(28)
            }
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val btnDel = TextView(this).apply {
            text = "✕"
            textSize = 16f
            setTextColor(Color.parseColor("#F16D68"))
            setTypeface(typeface, Typeface.BOLD)
            val s = dp(32)
            layoutParams = LinearLayout.LayoutParams(s, s)
            gravity = Gravity.CENTER
            background = createPillDrawable(bgElevatedColor(), dp(16), null)
            setOnClickListener {
                if (isForeground) {
                    ReminderRepository.deleteNote(this@MainActivity, note.id)
                    renderCurrentTab()
                }
            }
        }
        topRow.addView(btnDel)

        val spacer = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(1), 1f) }
        topRow.addView(spacer)

        val tvCategoryBadge = TextView(this).apply {
            text = "📌 ${note.category}"
            textSize = 12f
            setTextColor(accentOrangeColor())
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = createPillDrawable(bgElevatedColor(), dp(10), null)
        }
        topRow.addView(tvCategoryBadge)
        card.addView(topRow)

        val tvTitle = TextView(this).apply {
            text = note.title
            setTextColor(textPrimaryColor())
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(12), 0, dp(6))
        }
        card.addView(tvTitle)

        val tvContent = TextView(this).apply {
            text = note.content
            setTextColor(textMutedColor())
            textSize = 14f
            maxLines = 6
            setLineSpacing(dp(4).toFloat(), 1f)
        }
        card.addView(tvContent)

        val actionsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, dp(12), 0, 0)
        }

        actionsRow.addView(createCardActionCircle("✏️", "Edit") {
            showAddOrEditNoteModal(note)
        })

        actionsRow.addView(createCardActionCircle("🪟", "Float") {
            launchFloatingQuickNoteOverlay()
        })

        card.addView(actionsRow)
        return card
    }

    private fun buildNotesLeftSlideOutDock(): View {
        val dockLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable().apply {
                cornerRadii = floatArrayOf(0f, 0f, dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), 0f, 0f)
                setColor(Color.argb(240, 14, 34, 45))
                setStroke(dp(1), Color.parseColor(if (isForeground) "#9950C9C0" else "#5535B6AD"))
            }
            setPadding(dp(8), dp(16), dp(8), dp(16))
            val w = if (isNotesLeftDockOpen) dp(60) else dp(22)
            layoutParams = FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER_VERTICAL or Gravity.LEFT
            }
            elevation = dp(16).toFloat()
        }

        if (!isNotesLeftDockOpen) {
            val tvHandle = TextView(this).apply {
                text = "▸"
                textSize = 16f
                setTextColor(accentTealColor())
                gravity = Gravity.CENTER
            }
            dockLayout.addView(tvHandle)
            dockLayout.setOnClickListener {
                isNotesLeftDockOpen = true
                renderCurrentTab()
            }
        } else {
            dockLayout.addView(createDockIcon("🔍") {
                showSearchNotesDialog()
            })

            dockLayout.addView(createDockIcon("➕") {
                showAddOrEditNoteModal(null)
            })

            dockLayout.addView(createDockIcon("🪟") {
                launchFloatingQuickNoteOverlay()
            })

            val divider = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(1)).apply {
                    topMargin = dp(6)
                    bottomMargin = dp(10)
                }
                setBackgroundColor(Color.parseColor("#4DA5B4B4"))
            }
            dockLayout.addView(divider)

            listOf("💡", "💼", "📌", "📚").forEach { icon ->
                dockLayout.addView(createDockIcon(icon) {
                    Toast.makeText(this@MainActivity, "تصنيف الملاحظات $icon", Toast.LENGTH_SHORT).show()
                })
            }

            val tvClose = TextView(this).apply {
                text = "◂"
                textSize = 16f
                setTextColor(textMutedColor())
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, 0)
                setOnClickListener {
                    isNotesLeftDockOpen = false
                    renderCurrentTab()
                }
            }
            dockLayout.addView(tvClose)
        }
        return dockLayout
    }

    private fun showSearchNotesDialog() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = createPillDrawable(bgCardColor(), dp(18), COLOR_TEAL)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val et = EditText(this).apply {
            hint = if (isArabic) "ابحث في الملاحظات..." else "Search notes..."
            setHintTextColor(textMutedColor())
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        v.addView(et)
        val btn = Button(this).apply {
            text = if (isArabic) "بحث" else "Search"
            isAllCaps = false
            setTextColor(Color.parseColor("#0B1417"))
            backgroundTintList = ColorStateList.valueOf(accentTealColor())
            setOnClickListener {
                noteSearchQuery = et.text.toString().trim()
                d.dismiss()
                renderCurrentTab()
            }
        }
        v.addView(btn)
        d.setContentView(v)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.85).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    private fun showAddOrEditNoteModal(existingNote: NoteItem?) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = createPillDrawable(bgCardColor(), dp(22), COLOR_TEAL)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        v.addView(TextView(this).apply {
            text = if (existingNote == null) (if (isArabic) "📝 ملاحظة جديدة" else "📝 New Note") else (if (isArabic) "✏️ تعديل الملاحظة" else "✏️ Edit Note")
            setTextColor(textPrimaryColor())
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
        })

        val etTitle = EditText(this).apply {
            hint = if (isArabic) "عنوان الملاحظة..." else "Title..."
            setText(existingNote?.title ?: "")
            setHintTextColor(textMutedColor())
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) }
        }
        v.addView(etTitle)

        val etContent = EditText(this).apply {
            hint = if (isArabic) "اكتب محتوى الملاحظة..." else "Content..."
            setText(existingNote?.content ?: "")
            setHintTextColor(textMutedColor())
            setTextColor(textPrimaryColor())
            minLines = 4
            gravity = Gravity.TOP or Gravity.START
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) }
        }
        v.addView(etContent)

        val btnSave = Button(this).apply {
            text = if (isArabic) "حفظ الملاحظة" else "Save Note"
            isAllCaps = false
            setTextColor(Color.parseColor("#0B1417"))
            backgroundTintList = ColorStateList.valueOf(accentTealColor())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(16) }
            setOnClickListener {
                val t = etTitle.text.toString().trim()
                val c = etContent.text.toString().trim()
                if (t.isNotBlank() || c.isNotBlank()) {
                    val note = (existingNote ?: NoteItem(
                        id = UUID.randomUUID().toString(),
                        title = t.ifBlank { "ملاحظة" },
                        content = c
                    )).copy(
                        title = t.ifBlank { "ملاحظة" },
                        content = c
                    )
                    ReminderRepository.addOrUpdateNote(this@MainActivity, note)
                    d.dismiss()
                    renderCurrentTab()
                }
            }
        }
        v.addView(btnSave)

        d.setContentView(v)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    private fun launchFloatingQuickNoteOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        val intent = Intent(this, FloatingCardService::class.java).apply {
            action = FloatingCardService.ACTION_OPEN_FLOATING_NOTE
            putExtra(FloatingCardService.EXTRA_IS_FLOATING_NOTE, true)
            putExtra(FloatingCardService.EXTRA_IS_ARABIC, isArabic)
        }
        ContextCompat.startForegroundService(this, intent)
        Toast.makeText(this, if (isArabic) "📝 ظهرت الملاحظة العائمة فوق التطبيقات!" else "Floating note active!", Toast.LENGTH_SHORT).show()
    }

    private fun buildPomodoroScreenView(): View {
        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        if (isFlipClockModeActive) {
            return buildFullscreenClockView()
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            setPadding(dp(16), dp(12), dp(16), dp(84))
        }

        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(14))
        }

        val btnTaskLinked = TextView(this).apply {
            text = if (isArabic) "🎯 بومودورو بمهمة" else "🎯 Linked to Task"
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (isPomodoroLinkedToTask) Color.parseColor("#0B1417") else textPrimaryColor())
            background = createPillDrawable(if (isPomodoroLinkedToTask) accentOrangeColor() else bgCardColor(), dp(14), null)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(8) }
            setOnClickListener {
                triggerGentleHaptic()
                isPomodoroLinkedToTask = true
                showTaskPickerSortedByTime()
            }
        }
        modeRow.addView(btnTaskLinked)

        val btnFree = TextView(this).apply {
            text = if (isArabic) "🍅 بومودورو حر" else "🍅 Free Session"
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (!isPomodoroLinkedToTask) Color.parseColor("#0B1417") else textPrimaryColor())
            background = createPillDrawable(if (!isPomodoroLinkedToTask) accentOrangeColor() else bgCardColor(), dp(14), null)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            setOnClickListener {
                triggerGentleHaptic()
                isPomodoroLinkedToTask = false
                selectedFocusTaskId = null
                renderCurrentTab()
            }
        }
        modeRow.addView(btnFree)
        content.addView(modeRow)

        if (isPomodoroLinkedToTask && selectedFocusTaskId != null) {
            val task = ReminderRepository.getItemById(this, selectedFocusTaskId ?: "")
            content.addView(TextView(this).apply {
                text = "🎯 المهمة المختارة: ${task?.title ?: ""}"
                setTextColor(accentTealColor())
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, 0, 0, dp(8))
            })
        }

        val ringView = CircularTimerRingView(this).apply {
            val s = dp(230)
            layoutParams = LinearLayout.LayoutParams(s, s).apply {
                topMargin = dp(6)
                bottomMargin = dp(14)
            }
            updateTimerDisplay(pomodoroRemainingMillis, pomodoroTotalMillis)
            setOnClickListener {
                if (!isPomodoroRunning) {
                    showSetTimeInsideDialDialog()
                }
            }
        }
        circularTimerView = ringView
        content.addView(ringView)

        val controlsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(14))
        }

        val btnStart = TextView(this).apply {
            text = if (isPomodoroRunning) (if (isArabic) "⏸ إيقاف مؤقت" else "⏸ Pause") else (if (isArabic) "▶ بدء التركيز" else "▶ Start")
            textSize = 15f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#0B1417"))
            background = createPillDrawable(accentOrangeColor(), dp(22), null)
            layoutParams = LinearLayout.LayoutParams(dp(148), dp(48)).apply { marginEnd = dp(10) }
            setOnClickListener {
                triggerGentleHaptic()
                toggleInAppPomodoro()
            }
        }
        controlsRow.addView(btnStart)

        val btnTickTock = TextView(this).apply {
            text = if (isTickTockSoundActive) "⏱️ تيك-تاك ✓" else "⏱️ تيك-تاك"
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (isTickTockSoundActive) Color.parseColor("#0B1417") else textPrimaryColor())
            background = createPillDrawable(if (isTickTockSoundActive) accentTealColor() else bgElevatedColor(), dp(22), null)
            layoutParams = LinearLayout.LayoutParams(dp(120), dp(48))
            setOnClickListener {
                triggerGentleHaptic()
                isTickTockSoundActive = !isTickTockSoundActive
                getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE).edit().putBoolean(ReminderRepository.KEY_TICK_TOCK_ENABLED, isTickTockSoundActive).apply()
                renderCurrentTab()
            }
        }
        controlsRow.addView(btnTickTock)
        content.addView(controlsRow)

        val todayMins = ReminderRepository.getTodayFocusMinutes(this)
        content.addView(TextView(this).apply {
            text = if (isArabic) "🔥 إجمالي تركيز اليوم: $todayMins دقيقة" else "🔥 Today's Focus: $todayMins mins"
            setTextColor(textMutedColor())
            textSize = 13f
        })

        root.addView(content)
        root.addView(buildPomodoroLeftSlideOutDock())
        return root
    }

    private fun showTaskPickerSortedByTime() {
        val tasks = ReminderRepository.getAllItems(this).filter { !it.isHabit && !it.isCompletedToday }
            .sortedWith(compareBy({ it.hour }, { it.minute }))

        val names = tasks.map { "⏰ ${String.format(Locale.US, "%02d:%02d", it.hour, it.minute)} • ${it.title}" }

        AlertDialog.Builder(this)
            .setTitle(if (isArabic) "اختر المهمة الأقرب لوقتك:" else "Select Task by Due Time:")
            .setItems(names.toTypedArray()) { _, which ->
                selectedFocusTaskId = tasks[which].id
                renderCurrentTab()
            }
            .show()
    }

    private fun showSetTimeInsideDialDialog() {
        val options = arrayOf("15 دقيقة", "25 دقيقة", "45 دقيقة", "50 دقيقة", "60 دقيقة", "تحديد مخصص...")
        AlertDialog.Builder(this)
            .setTitle(if (isArabic) "تحديد وقت الجلسة من قلب الساعة:" else "Set Duration:")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> setPomodoroDuration(15)
                    1 -> setPomodoroDuration(25)
                    2 -> setPomodoroDuration(45)
                    3 -> setPomodoroDuration(50)
                    4 -> setPomodoroDuration(60)
                    5 -> showCustomMinutesDialog()
                }
            }
            .show()
    }

    private fun buildPomodoroLeftSlideOutDock(): View {
        val dockLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable().apply {
                cornerRadii = floatArrayOf(0f, 0f, dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), 0f, 0f)
                setColor(Color.argb(240, 14, 34, 45))
                setStroke(dp(1), Color.parseColor("#4DFF8A3D"))
            }
            setPadding(dp(8), dp(16), dp(8), dp(16))
            val w = if (isPomodoroLeftDockOpen) dp(60) else dp(22)
            layoutParams = FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER_VERTICAL or Gravity.LEFT
            }
            elevation = dp(16).toFloat()
        }

        if (!isPomodoroLeftDockOpen) {
            val tvHandle = TextView(this).apply {
                text = "▸"
                textSize = 16f
                setTextColor(accentOrangeColor())
                gravity = Gravity.CENTER
            }
            dockLayout.addView(tvHandle)
            dockLayout.setOnClickListener {
                isPomodoroLeftDockOpen = true
                renderCurrentTab()
            }
        } else {
            dockLayout.addView(createDockIcon("🎧") {
                showWhiteNoiseConsoleModal()
            })

            dockLayout.addView(createDockIcon("⛶") {
                isFlipClockModeActive = true
                renderCurrentTab()
            })

            dockLayout.addView(createDockIcon("🪟") {
                launchFloatingFocusWindow(null)
            })

            val tvClose = TextView(this).apply {
                text = "◂"
                textSize = 16f
                setTextColor(textMutedColor())
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, 0)
                setOnClickListener {
                    isPomodoroLeftDockOpen = false
                    renderCurrentTab()
                }
            }
            dockLayout.addView(tvClose)
        }
        return dockLayout
    }

    private fun showWhiteNoiseConsoleModal() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val scroll = ScrollView(this).apply {
            background = createPillDrawable(bgCardColor(), dp(24), COLOR_TEAL)
        }
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        headerRow.addView(TextView(this).apply {
            text = if (isArabic) "ضوضاء بيضاء" else "White Noise"
            setTextColor(textPrimaryColor())
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        headerRow.addView(TextView(this).apply {
            text = "✕"
            textSize = 18f
            setTextColor(textMutedColor())
            setOnClickListener { d.dismiss() }
        })
        v.addView(headerRow)

        val volCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, dp(14))
        }
        volCol.addView(TextView(this).apply {
            text = if (isArabic) "مستوي الصوت" else "Volume Level"
            setTextColor(textPrimaryColor())
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
        })
        val sb = SeekBar(this).apply {
            max = 100
            progress = (ambientVolume * 100).toInt()
            progressTintList = ColorStateList.valueOf(Color.parseColor("#F16D68"))
            thumbTintList = ColorStateList.valueOf(Color.parseColor("#F16D68"))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, prog: Int, fromUser: Boolean) {
                    ambientVolume = (prog / 100f).coerceIn(0.05f, 1f)
                    ambientAudioTrack?.setVolume(ambientVolume)
                    customAudioPlayer?.setVolume(ambientVolume, ambientVolume)
                    getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE).edit()
                        .putInt(ReminderRepository.KEY_SOUND_VOLUME, (ambientVolume * 100).toInt()).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        volCol.addView(sb)
        v.addView(volCol)

        val btnAddLocal = Button(this).apply {
            text = if (customAudioName != null) "🎵 $customAudioName" else (if (isArabic) "📁 اختيار ملف صوتي أو موسيقى من جهازي" else "📁 Pick Audio/MP3 from Device")
            isAllCaps = false
            textSize = 13f
            setTextColor(Color.parseColor("#0B1417"))
            backgroundTintList = ColorStateList.valueOf(accentOrangeColor())
            setOnClickListener {
                isPickingAudioFromConsole = true
                localAudioPickerLauncher.launch(arrayOf("audio/*"))
                d.dismiss()
            }
        }
        v.addView(btnAddLocal)

        val soundTitles = listOf(
            "لا شيء", "صوت التيك-تاك", "العد التنازلي", "الرياح مع الجراد", "فصل دراسي",
            "البرية", "تيار", "شاطئ البحر", "مطر", "مقهى",
            "نار مشتعلة", "مكتبة", "رياح", "ضفادع ليلاً", "ضوضاء بنية"
        )

        soundTitles.forEachIndexed { idx, name ->
            val isSel = (selectedAmbientIndex == idx)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(10), 0, dp(10))

                val tvRadio = TextView(this@MainActivity).apply {
                    text = if (isSel) "🔘" else "⚪"
                    textSize = 16f
                    setPadding(0, 0, dp(12), 0)
                }
                val tvName = TextView(this@MainActivity).apply {
                    text = name
                    textSize = 15f
                    setTextColor(if (isSel) accentOrangeColor() else textPrimaryColor())
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                addView(tvRadio)
                addView(tvName)

                setOnClickListener {
                    selectedAmbientIndex = idx
                    getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE).edit()
                        .putInt(ReminderRepository.KEY_DEFAULT_SOUND_INDEX, idx).apply()
                    if (idx == 0) {
                        stopAmbientSound()
                        stopCustomAudio()
                    } else startRichAmbientSound(idx)
                    d.dismiss()
                    renderCurrentTab()
                }
            }
            v.addView(row)
        }

        scroll.addView(v)
        d.setContentView(scroll)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), (resources.displayMetrics.heightPixels * 0.85).toInt())
        d.show()
    }

    private fun buildFullscreenClockView(): View {
        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(Color.BLACK)
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(10))
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        val btnSwitchType = TextView(this).apply {
            text = if (fullscreenClockType == "flip") "⏳ ساعة رملية" else "⏲️ ساعة فليب"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = createPillDrawable(Color.parseColor("#1B383C"), dp(12), null)
            setOnClickListener {
                fullscreenClockType = if (fullscreenClockType == "flip") "hourglass" else "flip"
                renderCurrentTab()
            }
        }
        topBar.addView(btnSwitchType)

        val spacer = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(1), 1f) }
        topBar.addView(spacer)

        val btnClose = TextView(this).apply {
            text = "✕"
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener {
                isFlipClockModeActive = false
                renderCurrentTab()
            }
        }
        topBar.addView(btnClose)
        root.addView(topBar)

        val centerBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }

        val totalSec = (pomodoroRemainingMillis / 1000L).coerceAtLeast(0L)
        val mStr = String.format(Locale.US, "%02d", totalSec / 60L)
        val sStr = String.format(Locale.US, "%02d", totalSec % 60L)

        if (fullscreenClockType == "flip") {
            val rowTopDigits = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            rowTopDigits.addView(createFlipDigitCard(mStr[0]))
            rowTopDigits.addView(createFlipDigitCard(mStr[1]))
            centerBox.addView(rowTopDigits)

            val rowBottomDigits = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(14), 0, 0) }
            rowBottomDigits.addView(createFlipDigitCard(sStr[0]))
            rowBottomDigits.addView(createFlipDigitCard(sStr[1]))
            centerBox.addView(rowBottomDigits)
        } else {
            centerBox.addView(HourglassAnimatedView(this).apply {
                val s = dp(240)
                layoutParams = LinearLayout.LayoutParams(s, s)
                progressFraction = if (pomodoroTotalMillis > 0) (pomodoroRemainingMillis.toFloat() / pomodoroTotalMillis.toFloat()) else 0f
            })
            centerBox.addView(TextView(this).apply {
                text = "$mStr:$sStr"
                textSize = 34f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(16), 0, 0)
            })
        }

        val btnPlayPause = TextView(this).apply {
            text = if (isPomodoroRunning) "⏸" else "▶"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1B383C"))
            }
            val s = dp(64)
            layoutParams = FrameLayout.LayoutParams(s, s).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(40)
            }
            setOnClickListener {
                triggerGentleHaptic()
                toggleInAppPomodoro()
                renderCurrentTab()
            }
        }
        root.addView(centerBox)
        root.addView(btnPlayPause)
        return root
    }

    private fun createFlipDigitCard(ch: Char): View {
        return FrameLayout(this).apply {
            val w = dp(140)
            val h = dp(160)
            layoutParams = LinearLayout.LayoutParams(w, h).apply { marginStart = dp(6); marginEnd = dp(6) }
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#121820"))
                cornerRadius = dp(16).toFloat()
            }

            val tv = TextView(context).apply {
                text = ch.toString()
                textSize = 88f
                setTextColor(Color.parseColor("#D0D7DE"))
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            }
            addView(tv)

            val divider = View(context).apply {
                layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(2), Gravity.CENTER)
                setBackgroundColor(Color.BLACK)
            }
            addView(divider)
        }
    }

    private fun showAccordionSettingsDialog() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            background = GradientDrawable().apply {
                setColor(bgPrimaryColor())
                cornerRadius = dp(26).toFloat()
                setStroke(dp(1), Color.parseColor("#5535B6AD"))
            }
            clipToOutline = true
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(22))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        val titleColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleColumn.addView(TextView(this).apply {
            text = if (isArabic) "إعدادات وَقْت" else "WAQT Settings"
            setTextColor(textPrimaryColor())
            textSize = 23f
            setTypeface(typeface, Typeface.BOLD)
        })
        titleColumn.addView(TextView(this).apply {
            text = if (isArabic) "خلّي تجربتك مناسبة ليك." else "Make your experience yours."
            setTextColor(textMutedColor())
            textSize = 13f
            setPadding(0, dp(3), 0, 0)
        })
        header.addView(titleColumn)
        header.addView(TextView(this).apply {
            text = "✕"
            textSize = 19f
            gravity = Gravity.CENTER
            setTextColor(textMutedColor())
            background = createPillDrawable(bgElevatedColor(), dp(14), null)
            layoutParams = LinearLayout.LayoutParams(dp(38), dp(38))
            setOnClickListener { d.dismiss() }
        })
        body.addView(header)

        val brandLine = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(accentTealColor(), accentOrangeColor())
            ).apply { cornerRadius = dp(3).toFloat() }
            layoutParams = LinearLayout.LayoutParams(dp(74), dp(4)).apply {
                topMargin = dp(4)
                bottomMargin = dp(16)
            }
        }
        body.addView(brandLine)

        // Quick appearance card
        val appearanceCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(bgCardColor())
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.parseColor("#3335B6AD"))
            }
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(12) }
        }
        appearanceCard.addView(TextView(this).apply {
            text = if (isArabic) "المظهر" else "Appearance"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textPrimaryColor())
        })
        val appearanceActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        appearanceActions.addView(TextView(this).apply {
            text = if (isDarkMode) (if (isArabic) "🌙 الوضع الداكن" else "🌙 Dark mode")
                   else (if (isArabic) "☀️ الوضع الفاتح" else "☀️ Light mode")
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(14), "#5535B6AD")
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
            setOnClickListener {
                isDarkMode = !isDarkMode
                getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE).edit()
                    .putBoolean(ReminderRepository.KEY_DARK_MODE, isDarkMode).apply()
                d.dismiss()
                recreate()
            }
        })
        appearanceActions.addView(TextView(this).apply {
            text = if (isArabic) "🌐 اللغة" else "🌐 Language"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(accentOrangeColor())
            background = createPillDrawable(bgElevatedColor(), dp(14), "#55FF8A3D")
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnClickListener {
                d.dismiss()
                toggleLanguage()
            }
        })
        appearanceCard.addView(appearanceActions)
        body.addView(appearanceCard)

        body.addView(createAccordionSection(if (isArabic) "🍅 التركيز والاستراحة" else "🍅 Focus & Breaks") { container ->
            fun addDurationRow(label: String, value: Int, onChoose: () -> Unit) {
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = createPillDrawable(bgCardColor(), dp(12), null)
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(8) }
                }
                row.addView(TextView(this@MainActivity).apply {
                    text = label
                    textSize = 14f
                    setTextColor(textPrimaryColor())
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
                row.addView(TextView(this@MainActivity).apply {
                    text = "$value ${if (isArabic) "دقيقة" else "min"}  ›"
                    textSize = 14f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(accentOrangeColor())
                })
                row.setOnClickListener { onChoose() }
                container.addView(row)
            }

            addDurationRow(if (isArabic) "مدة التركيز الافتراضية" else "Default focus duration", selectedPomodoroMinutes) {
                showDurationSettingDialog(
                    if (isArabic) "مدة التركيز بالدقائق" else "Focus duration (minutes)",
                    selectedPomodoroMinutes, true, d
                )
            }
            addDurationRow(if (isArabic) "مدة الراحة الافتراضية" else "Default break duration", selectedBreakMinutes) {
                showDurationSettingDialog(
                    if (isArabic) "مدة الراحة بالدقائق" else "Break duration (minutes)",
                    selectedBreakMinutes, false, d
                )
            }

            val tickRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(2), dp(4), dp(2), dp(4))
            }
            tickRow.addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "صوت تيك-تاك أثناء التركيز" else "Tick-tock sound during focus"
                textSize = 14f
                setTextColor(textPrimaryColor())
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            val tickSwitch = Switch(this@MainActivity).apply {
                isChecked = isTickTockSoundActive
                buttonTintList = ColorStateList.valueOf(accentOrangeColor())
                setOnCheckedChangeListener { _, checked ->
                    isTickTockSoundActive = checked
                    getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE).edit()
                        .putBoolean(ReminderRepository.KEY_TICK_TOCK_ENABLED, checked).apply()
                }
            }
            tickRow.addView(tickSwitch)
            container.addView(tickRow)
        })

        body.addView(createAccordionSection(if (isArabic) "🔔 التنبيهات والصوت" else "🔔 Alarms & Audio") { container ->
            val ringtoneButton = createSettingsActionButton(
                if (isArabic) "اختيار نغمة المنبه" else "Choose alarm ringtone",
                "♫"
            ) {
                val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                }
                ringtonePickerLauncher.launch(intent)
            }
            container.addView(ringtoneButton)

            val customAudioButton = createSettingsActionButton(
                if (isArabic) "اختيار صوت أو موسيقى من الجهاز" else "Choose audio from device",
                "♫"
            ) {
                localAudioPickerLauncher.launch(arrayOf("audio/*"))
            }
            container.addView(customAudioButton)
            container.addView(TextView(this@MainActivity).apply {
                text = customAudioName?.let {
                    if (isArabic) "المحدد حاليًا: $it" else "Selected: $it"
                } ?: if (isArabic) "يمكنك اختيار ملف صوتي من جهازك من قائمة أصوات التركيز." else "Choose a local audio file for focus sessions."
                setTextColor(textMutedColor())
                textSize = 12f
                setPadding(0, dp(7), 0, 0)
            })
            container.addView(createSettingsActionButton(
                if (isArabic) "▶ معاينة / إيقاف الصوت المختار" else "▶ Preview / stop selected audio",
                "♫"
            ) {
                if (customAudioPlayer?.isPlaying == true) {
                    stopCustomAudio()
                } else {
                    if (customAudioUri == null) {
                        Toast.makeText(this@MainActivity, if (isArabic) "اختار ملف صوتي الأول" else "Choose an audio file first", Toast.LENGTH_SHORT).show()
                    } else playCustomAudio()
                }
            })
        })

        body.addView(createAccordionSection(if (isArabic) "💾 بياناتك والنسخ الاحتياطي" else "💾 Your Data & Backup") { container ->
            container.addView(createSettingsActionButton(
                if (isArabic) "تصدير نسخة احتياطية" else "Export backup",
                "↗"
            ) {
                val json = ReminderRepository.exportCloudBackupJson(this@MainActivity)
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, json)
                }
                startActivity(Intent.createChooser(shareIntent, if (isArabic) "نسخة وقت الاحتياطية" else "WAQT Backup"))
            })
            container.addView(createSettingsActionButton(
                if (isArabic) "استعادة نسخة احتياطية من ملف" else "Restore backup from file",
                "↙"
            ) {
                backupImportLauncher.launch(arrayOf("application/json", "text/*", "application/octet-stream"))
            })
            container.addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "احتفظ بالنسخة في مكان آمن لاستعادة بياناتك لاحقًا." else "Keep the backup somewhere safe so you can restore your data later."
                setTextColor(textMutedColor())
                textSize = 12f
                setPadding(0, dp(6), 0, 0)
            })
        })

        body.addView(createAccordionSection(if (isArabic) "🛡️ صلاحيات التطبيق" else "🛡️ App Permissions") { container ->
            val overlayEnabled = Settings.canDrawOverlays(this@MainActivity)
            container.addView(createSettingsActionButton(
                if (overlayEnabled) {
                    if (isArabic) "✓ النافذة العائمة مفعلة" else "✓ Floating window enabled"
                } else {
                    if (isArabic) "تفعيل النافذة العائمة" else "Enable floating window"
                },
                "▣"
            ) { requestOverlayPermission() })
            container.addView(TextView(this@MainActivity).apply {
                text = if (isArabic)
                    "تحتاج هذه الصلاحية فقط لاستخدام فقاعة الشات أو نافذة التركيز العائمة."
                else
                    "This permission is only needed for the floating chat or focus window."
                setTextColor(textMutedColor())
                textSize = 12f
                setPadding(0, dp(6), 0, 0)
            })
        })

        body.addView(createAccordionSection(if (isArabic) "ℹ️ عن وَقْت" else "ℹ️ About WAQT") { container ->
            container.addView(TextView(this@MainActivity).apply {
                text = if (isArabic)
                    "وَقْت — مساحة هادئة لمهامك وعاداتك وتركيزك.\\nالوقت هو أغلى مواردك، فلا تضيعه."
                else
                    "WAQT — a calm space for your tasks, habits and focus.\\nTime is your most valuable resource."
                setTextColor(textMutedColor())
                textSize = 13f
                setLineSpacing(dp(3).toFloat(), 1f)
            })
        })

        scroll.addView(body)
        d.setContentView(scroll)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        d.show()
        d.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.92).toInt(),
            (resources.displayMetrics.heightPixels * 0.84).toInt()
        )
    }

    private fun createSettingsActionButton(label: String, icon: String, onClick: () -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = createPillDrawable(bgCardColor(), dp(13), "#3335B6AD")
            setPadding(dp(13), dp(12), dp(13), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
            addView(TextView(this@MainActivity).apply {
                text = icon
                textSize = 17f
                setTextColor(accentOrangeColor())
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(30), ViewGroup.LayoutParams.WRAP_CONTENT)
            })
            addView(TextView(this@MainActivity).apply {
                text = label
                textSize = 14f
                setTextColor(textPrimaryColor())
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            setOnClickListener { onClick() }
        }
    }

    private fun showDurationSettingDialog(title: String, currentValue: Int, isFocus: Boolean, parentDialog: Dialog) {
        val inputDialog = Dialog(this)
        inputDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(bgCardColor())
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.parseColor("#5535B6AD"))
            }
            setPadding(dp(20), dp(18), dp(20), dp(18))
        }
        panel.addView(TextView(this).apply {
            text = title
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textPrimaryColor())
        })
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setText(currentValue.toString())
            setTextColor(textPrimaryColor())
            setHintTextColor(textMutedColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14); bottomMargin = dp(12) }
        }
        panel.addView(input)
        panel.addView(createSettingsActionButton(if (isArabic) "حفظ" else "Save", "✓") {
            val value = input.text.toString().toIntOrNull()
            if (value == null || value !in 1..240) {
                input.error = if (isArabic) "اكتب رقمًا من 1 إلى 240" else "Enter a value from 1 to 240"
                return@createSettingsActionButton
            }
            val prefs = getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE).edit()
            if (isFocus) {
                selectedPomodoroMinutes = value
                prefs.putInt(ReminderRepository.KEY_DEFAULT_FOCUS_MINS, value)
                if (!isPomodoroRunning && !isBreakSession) {
                    pomodoroTotalMillis = value * 60 * 1000L
                    pomodoroRemainingMillis = pomodoroTotalMillis
                }
            } else {
                selectedBreakMinutes = value
                prefs.putInt(ReminderRepository.KEY_DEFAULT_BREAK_MINS, value)
                if (!isPomodoroRunning && isBreakSession) {
                    pomodoroTotalMillis = value * 60 * 1000L
                    pomodoroRemainingMillis = pomodoroTotalMillis
                }
            }
            prefs.apply()
            inputDialog.dismiss()
            parentDialog.dismiss()
            renderCurrentTab()
            showAccordionSettingsDialog()
        })
        inputDialog.setContentView(panel)
        inputDialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        inputDialog.show()
        inputDialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.84).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun createAccordionSection(title: String, buildContent: (LinearLayout) -> Unit): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = createPillDrawable(bgElevatedColor(), dp(14), null)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }

        var isExpanded = false
        val contentHolder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(14), 0, dp(14), dp(12))
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))

            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(textPrimaryColor())
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })

            val tvArrow = TextView(this@MainActivity).apply {
                text = "▸"
                textSize = 15f
                setTextColor(accentOrangeColor())
            }
            addView(tvArrow)

            setOnClickListener {
                isExpanded = !isExpanded
                tvArrow.text = if (isExpanded) "▾" else "▸"
                contentHolder.visibility = if (isExpanded) View.VISIBLE else View.GONE
            }
        }

        buildContent(contentHolder)
        root.addView(headerRow)
        root.addView(contentHolder)
        return root
    }

    private fun getFileNameFromUri(uri: Uri): String {
        var name = "Custom Audio"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx != -1) name = cursor.getString(idx)
            }
        }
        return name
    }

    private fun setupCardSwipeNavigation(card: View, onSwipe: (direction: Int) -> Unit) {
        var startX = 0f
        var startY = 0f

        card.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.x
                    startY = event.y
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - startX
                    val dy = event.y - startY
                    if (abs(dy) > dp(50) || abs(dx) > dp(50)) {
                        if (abs(dy) > abs(dx)) {
                            onSwipe(if (dy < 0) 1 else -1)
                        } else {
                            onSwipe(if (dx < 0) 1 else -1)
                        }
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun buildEmptyCardPlaceholder(title: String, subtitle: String): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = createPillDrawable(bgCardColor(), dp(20), "#2635B6AD")
            setPadding(dp(20), dp(36), dp(20), dp(36))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(24)
            }
            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(textPrimaryColor())
                textSize = 18f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
            })
            addView(TextView(this@MainActivity).apply {
                text = subtitle
                setTextColor(textMutedColor())
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, 0)
            })
        }
    }

    private fun createPillDrawable(fillColor: Int, radiusPx: Int, strokeColorHex: String?): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(fillColor)
            if (strokeColorHex != null) {
                setStroke(dp(1), Color.parseColor(strokeColorHex))
            }
        }
    }

    private fun triggerGentleHaptic() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (vibrator.hasVibrator()) {
                vibrator.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (_: Exception) {}
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun requestOverlayPermission() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun setPomodoroDuration(minutes: Int) {
        inAppCountDownTimer?.cancel()
        isPomodoroRunning = false
        ReminderRepository.clearActiveFocusState(this)
        selectedPomodoroMinutes = minutes
        pomodoroTotalMillis = minutes * 60 * 1000L
        pomodoroRemainingMillis = pomodoroTotalMillis
        activeFocusSessionId = UUID.randomUUID().toString()
        renderCurrentTab()
    }

    private fun toggleInAppPomodoro() {
        if (isPomodoroRunning) {
            inAppCountDownTimer?.cancel()
            isPomodoroRunning = false
            ReminderRepository.saveActiveFocusState(
                this,
                startEpochMs = 0L,
                totalDurationMs = pomodoroTotalMillis,
                remainingOnPauseMs = pomodoroRemainingMillis,
                isRunning = false,
                linkedTaskId = selectedFocusTaskId,
                isBreakMode = isBreakSession
            )
        } else {
            startWallClockCountDown(pomodoroRemainingMillis)
        }
        renderCurrentTab()
    }

    private fun startWallClockCountDown(durationMs: Long) {
        inAppCountDownTimer?.cancel()
        isPomodoroRunning = true
        val alreadyElapsed = pomodoroTotalMillis - durationMs
        pomodoroStartWallClockMs = System.currentTimeMillis() - alreadyElapsed

        ReminderRepository.saveActiveFocusState(
            this,
            startEpochMs = pomodoroStartWallClockMs,
            totalDurationMs = pomodoroTotalMillis,
            remainingOnPauseMs = durationMs,
            isRunning = true,
            linkedTaskId = selectedFocusTaskId,
            isBreakMode = isBreakSession
        )

        inAppCountDownTimer = object : CountDownTimer(durationMs, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                val trueElapsed = System.currentTimeMillis() - pomodoroStartWallClockMs
                pomodoroRemainingMillis = (pomodoroTotalMillis - trueElapsed).coerceAtLeast(0L)
                circularTimerView?.updateTimerDisplay(pomodoroRemainingMillis, pomodoroTotalMillis)
                if (isFlipClockModeActive) {
                    renderCurrentTab()
                }
            }

            override fun onFinish() {
                isPomodoroRunning = false
                ReminderRepository.clearActiveFocusState(this@MainActivity)
                pomodoroRemainingMillis = pomodoroTotalMillis
                triggerGentleHaptic()

                if (!isBreakSession) {
                    ReminderRepository.recordCompletedFocusSession(
                        this@MainActivity,
                        sessionId = activeFocusSessionId,
                        taskId = selectedFocusTaskId,
                        actualMinutes = selectedPomodoroMinutes
                    )
                }
                activeFocusSessionId = UUID.randomUUID().toString()
                renderCurrentTab()
            }
        }.start()
    }

    private fun launchFloatingFocusWindow(linkedTask: ReminderItem?) {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        val title = linkedTask?.title ?: (if (isArabic) "جلسة تركيز" else "Focus Session")
        val serviceIntent = Intent(this, FloatingCardService::class.java).apply {
            putExtra(FloatingCardService.EXTRA_ITEM_ID, linkedTask?.id ?: "pomodoro_session")
            putExtra(FloatingCardService.EXTRA_TITLE, title)
            putExtra(FloatingCardService.EXTRA_IS_HABIT, false)
            putExtra(FloatingCardService.EXTRA_CUSTOM_MINUTES, selectedPomodoroMinutes)
            putExtra(FloatingCardService.EXTRA_IS_ARABIC, isArabic)
            putExtra(FloatingCardService.EXTRA_AUTO_START_FOCUS, true)
            putExtra(FloatingCardService.EXTRA_SESSION_ID, activeFocusSessionId)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    private fun startRichAmbientSound(modeIndex: Int) {
        stopAmbientSound()
        stopCustomAudio()
        if (modeIndex == -1) {
            playCustomAudio()
            return
        }
        if (modeIndex <= 0) return

        isAmbientPlaying = true
        val sampleRate = 22050
        val bufferSize = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)

        ambientAudioTrack = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(bufferSize)
            .build()

        ambientAudioTrack?.setVolume(ambientVolume)
        ambientAudioTrack?.play()

        thread {
            val buffer = ShortArray(bufferSize)
            var lastOut = 0.0
            while (isAmbientPlaying) {
                for (i in buffer.indices) {
                    val white = Math.random() * 2.0 - 1.0
                    lastOut = (lastOut + (0.08 * white)) / 1.08
                    buffer[i] = (lastOut * 11000).toInt().coerceIn(-32000, 32000).toShort()
                }
                try { ambientAudioTrack?.write(buffer, 0, buffer.size) } catch (_: Exception) { break }
            }
        }
    }


    private fun playCustomAudio() {
        val uri = customAudioUri ?: return
        try {
            stopCustomAudio()
            customAudioPlayer = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                isLooping = true
                setVolume(ambientVolume, ambientVolume)
                setOnPreparedListener { player -> player.start() }
                setOnErrorListener { player, _, _ ->
                    try { player.reset(); player.release() } catch (_: Exception) { }
                    customAudioPlayer = null
                    Toast.makeText(this@MainActivity, if (isArabic) "تعذر تشغيل الملف الصوتي" else "Unable to play this audio file", Toast.LENGTH_SHORT).show()
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            stopCustomAudio()
            Toast.makeText(this, if (isArabic) "تعذر فتح الملف الصوتي" else "Could not open audio file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopCustomAudio() {
        try { customAudioPlayer?.stop() } catch (_: Exception) { }
        try { customAudioPlayer?.release() } catch (_: Exception) { }
        customAudioPlayer = null
    }

    private fun stopAmbientSound() {
        isAmbientPlaying = false
        try {
            ambientAudioTrack?.stop()
            ambientAudioTrack?.release()
        } catch (_: Exception) {}
        ambientAudioTrack = null
    }

    private fun createQuickPresetTask(minutes: Int) {
        val now = Calendar.getInstance().apply { add(Calendar.MINUTE, minutes) }
        val title = if (isArabic) "تذكير سريع ($minutes دقيقة)" else "Quick Reminder ($minutes mins)"
        val item = ReminderItem(
            id = UUID.randomUUID().toString(),
            title = title,
            isHabit = false,
            hour = now.get(Calendar.HOUR_OF_DAY),
            minute = now.get(Calendar.MINUTE),
            priority = "high",
            dueDateEpochDay = ReminderRepository.currentEpochDay()
        )
        ReminderRepository.addOrUpdateItem(this, item)
        AlarmScheduler.scheduleExactDelayMillis(this, item, minutes * 60 * 1000L)
        Toast.makeText(this, "⏰ $title", Toast.LENGTH_SHORT).show()
        renderCurrentTab()
    }

    private fun showCustomMinutesDialog() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = createPillDrawable(bgCardColor(), dp(20), COLOR_ORANGE)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "45"
            setHintTextColor(textMutedColor())
            setTextColor(textPrimaryColor())
        }
        v.addView(et)
        val btn = Button(this).apply {
            text = "OK"
            setOnClickListener {
                val m = et.text.toString().toIntOrNull()?.coerceIn(1, 240) ?: 25
                setPomodoroDuration(m)
                d.dismiss()
            }
        }
        v.addView(btn)
        d.setContentView(v)
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        d.show()
    }

    inner class AtmosphereBackgroundView(context: Context) : View(context) {
        private val petrolPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val orangePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val lowerPetrolPaint = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.parseColor("#0B1417"))
            val w = width.toFloat()
            val h = height.toFloat()
            petrolPaint.shader = RadialGradient(
                w * 0.88f, h * 0.18f, w * 0.72f,
                intArrayOf(Color.argb(44, 22, 125, 128), Color.argb(15, 22, 125, 128), Color.TRANSPARENT),
                floatArrayOf(0f, 0.48f, 1f), Shader.TileMode.CLAMP
            )
            orangePaint.shader = RadialGradient(
                w * 0.02f, h * 0.66f, w * 0.62f,
                intArrayOf(Color.argb(25, 255, 138, 61), Color.argb(8, 255, 138, 61), Color.TRANSPARENT),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
            lowerPetrolPaint.shader = RadialGradient(
                w * 0.62f, h * 0.92f, w * 0.78f,
                intArrayOf(Color.argb(27, 22, 125, 128), Color.argb(7, 22, 125, 128), Color.TRANSPARENT),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, 0f, w, h, petrolPaint)
            canvas.drawRect(0f, 0f, w, h, orangePaint)
            canvas.drawRect(0f, 0f, w, h, lowerPetrolPaint)
            petrolPaint.shader = null
            orangePaint.shader = null
            lowerPetrolPaint.shader = null
        }
    }

    inner class GTARadialWheelView(context: Context) : View(context) {
        var activeSector: Int = 0
            set(value) { field = value; invalidate() }

        private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(176, 2, 8, 10)
        }
        private val outerGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeWidth = dp(4).toFloat()
            color = Color.argb(90, 53, 182, 173)
        }
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1).toFloat()
            color = Color.argb(160, 88, 220, 205)
        }
        private val selectedEdgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(2).toFloat()
            color = Color.argb(235, 255, 174, 108)
        }
        private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = dp(12).toFloat()
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = dp(21).toFloat()
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        private val outerOval = RectF()
        private val innerOval = RectF()
        private val sectorPath = Path()

        init {
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        }

        private fun buildAnnularSector(cx: Float, cy: Float, outerR: Float, innerR: Float, start: Float, sweep: Float): Path {
            val outer = RectF(cx - outerR, cy - outerR, cx + outerR, cy + outerR)
            val inner = RectF(cx - innerR, cy - innerR, cx + innerR, cy + innerR)
            return Path().apply {
                val startRad = Math.toRadians(start.toDouble())
                moveTo(cx + outerR * cos(startRad).toFloat(), cy + outerR * sin(startRad).toFloat())
                arcTo(outer, start, sweep, false)
                val end = start + sweep
                val endRad = Math.toRadians(end.toDouble())
                lineTo(cx + innerR * cos(endRad).toFloat(), cy + innerR * sin(endRad).toFloat())
                arcTo(inner, end, -sweep, false)
                close()
            }
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)

            val cx = width / 2f
            val outerR = (width * 0.55f).coerceAtMost(dp(300).toFloat())
            val innerR = outerR - dp(84).toFloat()
            val cy = height + dp(50).toFloat()
            outerOval.set(cx - outerR, cy - outerR, cx + outerR, cy + outerR)
            innerOval.set(cx - innerR, cy - innerR, cx + innerR, cy + innerR)

            // Deep soft shadow behind the complete raised arc.
            val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = dp(92).toFloat()
                strokeCap = Paint.Cap.ROUND
                color = Color.argb(105, 0, 0, 0)
                setShadowLayer(dp(22).toFloat(), 0f, dp(8).toFloat(), Color.argb(210, 0, 0, 0))
            }
            canvas.drawArc(outerOval, 180f, 180f, false, shadow)

            // Sector order runs visually from left to right: Notes, Habits, Focus, Tasks.
            val labels = if (isArabic)
                listOf("📝" to "الملاحظات", "🌱" to "العادات", "◉" to "التركيز", "🎯" to "المهام")
            else listOf("📝" to "Notes", "🌱" to "Habits", "◉" to "Focus", "🎯" to "Tasks")
            val tabForSector = listOf(3, 1, 2, 0)
            for (i in 0..3) {
                val startAngle = 180f + i * 45f + 1.1f
                val sweep = 42.8f
                val selected = tabForSector[i] == activeSector
                val path = buildAnnularSector(cx, cy, outerR, innerR, startAngle, sweep)
                fillPaint.shader = if (selected) {
                    android.graphics.LinearGradient(
                        cx, cy - outerR, cx, cy - innerR,
                        intArrayOf(Color.parseColor("#FFFFA65E"), Color.parseColor("#FFFF7A2F"), Color.parseColor("#CCDB5B22")),
                        null, Shader.TileMode.CLAMP
                    )
                } else {
                    android.graphics.LinearGradient(
                        cx, cy - outerR, cx, cy - innerR,
                        intArrayOf(Color.parseColor("#E9274549"), Color.parseColor("#F2142D31"), Color.parseColor("#EE0C2024")),
                        null, Shader.TileMode.CLAMP
                    )
                }
                if (selected) fillPaint.setShadowLayer(dp(18).toFloat(), 0f, 0f, Color.argb(190, 255, 112, 42))
                else fillPaint.clearShadowLayer()
                canvas.drawPath(path, fillPaint)
                fillPaint.shader = null
                canvas.drawPath(path, if (selected) selectedEdgePaint else edgePaint)

                val mid = Math.toRadians((180f + i * 45f + 22.5f).toDouble())
                val labelR = (outerR + innerR) / 2f
                val x = cx + labelR * cos(mid).toFloat()
                val y = cy + labelR * sin(mid).toFloat()
                iconPaint.color = if (selected) Color.parseColor("#102326") else Color.parseColor("#D9F5F0")
                labelPaint.color = if (selected) Color.parseColor("#102326") else Color.parseColor("#F0F7F4")
                iconPaint.setShadowLayer(if (selected) dp(4).toFloat() else dp(2).toFloat(), 0f, dp(1).toFloat(), Color.argb(90, 0, 0, 0))
                canvas.drawText(labels[i].first, x, y - dp(1), iconPaint)
                canvas.drawText(labels[i].second, x, y + dp(17), labelPaint)
                iconPaint.clearShadowLayer()
            }

            // Inner lip gives the arc a machined, glass-like edge.
            val lip = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = dp(2).toFloat()
                color = Color.argb(105, 156, 255, 240)
            }
            canvas.drawArc(innerOval, 194f, 152f, false, lip)
            canvas.drawArc(outerOval, 194f, 152f, false, outerGlowPaint)
        }
    }

    inner class HourglassAnimatedView(context: Context) : View(context) {
        var progressFraction: Float = 1f
        private val sandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FF8A3D")
            style = Paint.Style.FILL
        }
        private val glassPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = dp(4).toFloat()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()

            canvas.drawLine(w * 0.2f, h * 0.15f, w * 0.8f, h * 0.15f, glassPaint)
            canvas.drawLine(w * 0.2f, h * 0.85f, w * 0.8f, h * 0.85f, glassPaint)
            canvas.drawLine(w * 0.2f, h * 0.15f, w * 0.8f, h * 0.85f, glassPaint)
            canvas.drawLine(w * 0.8f, h * 0.15f, w * 0.2f, h * 0.85f, glassPaint)

            val topSandH = (h * 0.35f) * progressFraction
            canvas.drawRect(w * 0.35f, (h * 0.5f) - topSandH, w * 0.65f, h * 0.5f, sandPaint)

            val btmSandH = (h * 0.35f) * (1f - progressFraction)
            canvas.drawRect(w * 0.35f, (h * 0.85f) - btmSandH, w * 0.65f, h * 0.85f, sandPaint)
        }
    }

    inner class CircularTimerRingView(context: Context) : View(context) {
        private var progressFraction: Float = 1f
        private var timeString: String = "25:00"

        private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(12).toFloat()
            color = bgElevatedColor()
            strokeCap = Paint.Cap.ROUND
        }

        private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(12).toFloat()
            color = accentOrangeColor()
            strokeCap = Paint.Cap.ROUND
        }

        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textPrimaryColor()
            textSize = dp(42).toFloat()
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }

        private val subTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentTealColor()
            textSize = dp(13).toFloat()
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }

        private val ovalRect = RectF()

        fun updateTimerDisplay(remainingMs: Long, totalMs: Long) {
            progressFraction = if (totalMs > 0) (remainingMs.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f) else 0f
            val totalSec = (remainingMs / 1000L).coerceAtLeast(0L)
            val m = totalSec / 60L
            val s = totalSec % 60L
            timeString = String.format(Locale.US, "%02d:%02d", m, s)
            trackPaint.color = bgElevatedColor()
            progressPaint.color = if (isBreakSession) Color.parseColor("#42C98A") else accentOrangeColor()
            textPaint.color = textPrimaryColor()
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val pad = dp(16).toFloat()
            ovalRect.set(pad, pad, width - pad, height - pad)

            canvas.drawArc(ovalRect, 0f, 360f, false, trackPaint)
            val sweepAngle = 360f * progressFraction
            canvas.drawArc(ovalRect, -90f, sweepAngle, false, progressPaint)

            val centerX = width / 2f
            val centerY = (height / 2f) - ((textPaint.descent() + textPaint.ascent()) / 2f) - dp(6)
            canvas.drawText(timeString, centerX, centerY, textPaint)

            val label = when {
                isBreakSession -> if (isArabic) "☕ استراحة" else "☕ BREAK"
                isPomodoroRunning -> if (isArabic) "🔥 جلسة جارية" else "🔥 ACTIVE"
                else -> if (isArabic) "المس لضبط الوقت" else "TAP TO SET TIME"
            }
            canvas.drawText(label, centerX, centerY + dp(28), subTextPaint)
        }
    }
}