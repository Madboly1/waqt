# WAQT 5.4.0 — Classic Explorer UI Direction

## Approved direction
The previous app UI is retired as the design direction. WAQT is moving toward a Windows 95-inspired desktop / classic Explorer interaction model.

## Implemented in this source update
- Replaced the Tasks carousel screen with a classic Explorer-style folder view.
- Each task is displayed as a folder tile; habits retain a plant icon.
- Selecting a folder opens a dedicated task detail view with a breadcrumb/back button.
- Existing task detail actions are reused from the original task card implementation to preserve editing, delete, alarm, snooze, focus linking, progress, restart, and habit actions.
- Taskbar section shortcuts now use folder-style labels; Start label no longer uses the modern Windows emoji.

## Important
- Existing task data and repository storage were not changed.
- This is a source update, not a verified APK. Build and test on Android before release.
- The rest of the sections (Habits, Focus, Notes) still need their Explorer-style window redesign in the next pass. The prior UI is considered deprecated and should not be expanded further.
