# WAQT 5.3.0 — Retro Desktop UI

- Replaced the previous glass-style app shell with a Windows 95-inspired desktop.
- Added desktop shortcuts for Tasks, Habits, Focus, and Notes.
- Added a classic application window with a blue title bar, menu strip, and window controls.
- Added a Start menu with section shortcuts, Settings, and Exit.
- Added a classic taskbar with section buttons and a live clock.
- Updated the shared app palette to classic gray surfaces, teal desktop, and navy accents.
- Existing task, habit, focus, notes, reminder, sound, and AI functionality remains in the existing screen implementations.

Build target: Android / Gradle 8.7 / JDK 17.
