# WAQT 6.0.2 – AI Assistant Fix & Speed Improvements

## AI model and connection
- Switched the default model to the stable `gemini-3.5-flash-lite` model, optimized for low-latency responses.
- Added `gemini-3.1-flash-lite` as a single fallback model.
- Replaced the previous repeated retry chain and multi-second sleeps with one short fallback attempt.
- Reduced connection/read timeouts and added explicit connection cleanup.
- Added more useful API error messages and handling for empty model responses.

## Response speed
- Limited conversation context to the latest 8 messages.
- Reduced the daily snapshot to 12 tasks and 8 habits to avoid sending unnecessary context.
- Reduced output token budget to 512 and lowered temperature for concise planner responses.

## Setup clarity
- The app now clearly asks the user to connect a Gemini API key instead of showing a fake local-AI task card when no key is configured.
- Existing old rolling model aliases migrate to the new stable default automatically.

## Build note
- Android Gradle build has not been run in this environment. Run GitHub Actions / `assembleDebug` to verify compilation and test with a valid Gemini API key on-device.
