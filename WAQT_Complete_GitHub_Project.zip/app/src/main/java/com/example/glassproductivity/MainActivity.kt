package com.example.glassproductivity

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.Dialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.TimePickerDialog
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.function.Consumer
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.sin
import org.json.JSONArray
import org.json.JSONObject

data class ReminderItem(
    val id: String,
    val title: String,
    val isHabit: Boolean,
    val hour: Int,
    val minute: Int,
    val streakCount: Int = 0,
    val streakGoal: Int = 7,
    val priority: String = "medium", // low, medium, high
    val category: String = "work", // work, study, personal, health, goals
    val lastCompletedEpochDay: Long = -1L,
    val isCompletedToday: Boolean = false,
    // الحقول المضافة لتطوير المهام والعادات وتتبع الوقت الفعلي
    val description: String = "",
    val dueDateEpochDay: Long = -1L,
    val expectedMinutes: Int = 25,
    val actualFocusedMinutes: Int = 0,
    val focusSessionsCount: Int = 0,
    val recurrence: String = "daily", // once, daily, weekly, custom_days
    val customDaysCsv: String = "1,2,3,4,5,6,7",
    val targetValue: Int = 1,
    val currentProgressToday: Int = 0,
    val targetUnit: String = "",
    val longestStreak: Int = 0,
    val isPaused: Boolean = false,
    val hasReminder: Boolean = true,
    val completedDaysHistoryCsv: String = ""
)

data class FocusSessionRecord(
    val id: String,
    val taskId: String?,
    val taskTitle: String,
    val durationMinutes: Int,
    val timestampMillis: Long,
    val epochDay: Long
)

object ReminderRepository {
    private const val PREFS_NAME = "waqt_productivity_prefs"
    private const val KEY_ITEMS = "waqt_items_json"
    private const val KEY_FOCUS_MINUTES = "waqt_today_focus_minutes"
    private const val KEY_FOCUS_EPOCH_DAY = "waqt_focus_epoch_day"
    private const val KEY_FOCUS_HISTORY = "waqt_focus_history_json"
    private const val KEY_GOOGLE_EMAIL = "waqt_google_email"
    private const val KEY_CUSTOM_QUOTES = "waqt_custom_quotes_json"
    private const val KEY_PRE_ALERT_MINUTES = "waqt_pre_alert_minutes"
    private const val KEY_RINGTONE_URI = "waqt_ringtone_uri"
    private const val KEY_UNLOCKED_ACHIEVEMENTS = "waqt_unlocked_achievements_csv"

    // مفاتيح الإعدادات المركزية المحفوظة
    const val KEY_DARK_MODE = "pref_dark_mode"
    const val KEY_ACCENT_COLOR = "pref_accent_color"
    const val KEY_REDUCE_MOTION = "pref_reduce_motion"
    const val KEY_DEFAULT_FOCUS_MINS = "pref_default_focus_mins"
    const val KEY_DEFAULT_BREAK_MINS = "pref_default_break_mins"
    const val KEY_DAILY_FOCUS_GOAL_MINS = "pref_daily_focus_goal_mins"
    const val KEY_DEFAULT_SOUND_INDEX = "pref_default_sound_index"
    const val KEY_SOUND_VOLUME = "pref_sound_volume"
    const val KEY_NOTIF_TASKS = "pref_notif_tasks"
    const val KEY_NOTIF_HABITS = "pref_notif_habits"
    const val KEY_NOTIF_SESSION_END = "pref_notif_session_end"
    const val KEY_NOTIF_SUMMARIES = "pref_notif_summaries"
    const val KEY_NOTIF_ACHIEVEMENTS = "pref_notif_achievements"
    const val KEY_AUTO_FLOAT = "pref_auto_float"
    const val KEY_QUIET_HOURS = "pref_quiet_hours"
    const val KEY_HIDE_DAILY_PLAN = "pref_hide_daily_plan"

    // حفظ حالة جلسة التركيز النشطة لضمان الدقة عند إغلاق الشاشة أو التطبيق
    private const val KEY_ACTIVE_FOCUS_START_MS = "active_focus_start_ms"
    private const val KEY_ACTIVE_FOCUS_TOTAL_MS = "active_focus_total_ms"
    private const val KEY_ACTIVE_FOCUS_REMAINING_PAUSE_MS = "active_focus_remaining_pause_ms"
    private const val KEY_ACTIVE_FOCUS_RUNNING = "active_focus_running"
    private const val KEY_ACTIVE_FOCUS_TASK_ID = "active_focus_task_id"
    private const val KEY_ACTIVE_FOCUS_IS_BREAK = "active_focus_is_break"

    fun currentEpochDay(): Long {
        val cal = Calendar.getInstance()
        val year = cal.get(Calendar.YEAR)
        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)
        return (year * 366L) + dayOfYear
    }

    fun getAllItems(context: Context): MutableList<ReminderItem> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val rawJson = prefs.getString(KEY_ITEMS, null) ?: return seedDefaultItems(context)
        val list = mutableListOf<ReminderItem>()
        val todayEpoch = currentEpochDay()

        try {
            val array = JSONArray(rawJson)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val lastCompleted = obj.optLong("lastCompletedEpochDay", -1L)
                val isHabit = obj.optBoolean("isHabit", false)
                val isPaused = obj.optBoolean("isPaused", false)
                val recurrence = obj.optString("recurrence", if (isHabit) "daily" else "once")
                val customDaysCsv = obj.optString("customDaysCsv", "1,2,3,4,5,6,7")
                var streak = obj.optInt("streakCount", 0)
                val longest = obj.optInt("longestStreak", streak)

                // عدم تصفير السلسلة إذا كانت العادة متوقفة مؤقتاً أو كان أمس يوم راحة محدد مسبقاً
                if (isHabit && !isPaused && lastCompleted != -1L && (todayEpoch - lastCompleted) > 1L) {
                    if (recurrence == "daily") {
                        streak = 0
                    }
                }

                val completedToday = (lastCompleted == todayEpoch) || obj.optBoolean("isCompletedToday", false) && lastCompleted == todayEpoch
                val progressToday = if (completedToday) obj.optInt("targetValue", 1) else obj.optInt("currentProgressToday", 0)

                list.add(
                    ReminderItem(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        isHabit = isHabit,
                        hour = obj.getInt("hour"),
                        minute = obj.getInt("minute"),
                        streakCount = streak,
                        streakGoal = obj.optInt("streakGoal", 7),
                        priority = obj.optString("priority", "medium"),
                        category = obj.optString("category", "work"),
                        lastCompletedEpochDay = lastCompleted,
                        isCompletedToday = completedToday,
                        description = obj.optString("description", ""),
                        dueDateEpochDay = obj.optLong("dueDateEpochDay", todayEpoch),
                        expectedMinutes = obj.optInt("expectedMinutes", 25),
                        actualFocusedMinutes = obj.optInt("actualFocusedMinutes", 0),
                        focusSessionsCount = obj.optInt("focusSessionsCount", 0),
                        recurrence = recurrence,
                        customDaysCsv = customDaysCsv,
                        targetValue = obj.optInt("targetValue", 1).coerceAtLeast(1),
                        currentProgressToday = progressToday,
                        targetUnit = obj.optString("targetUnit", ""),
                        longestStreak = longest.coerceAtLeast(streak),
                        isPaused = isPaused,
                        hasReminder = obj.optBoolean("hasReminder", true),
                        completedDaysHistoryCsv = obj.optString("completedDaysHistoryCsv", "")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun saveAllItems(context: Context, items: List<ReminderItem>) {
        val array = JSONArray()
        items.forEach { item ->
            val obj = JSONObject().apply {
                put("id", item.id)
                put("title", item.title)
                put("isHabit", item.isHabit)
                put("hour", item.hour)
                put("minute", item.minute)
                put("streakCount", item.streakCount)
                put("streakGoal", item.streakGoal)
                put("priority", item.priority)
                put("category", item.category)
                put("lastCompletedEpochDay", item.lastCompletedEpochDay)
                put("isCompletedToday", item.isCompletedToday)
                put("description", item.description)
                put("dueDateEpochDay", item.dueDateEpochDay)
                put("expectedMinutes", item.expectedMinutes)
                put("actualFocusedMinutes", item.actualFocusedMinutes)
                put("focusSessionsCount", item.focusSessionsCount)
                put("recurrence", item.recurrence)
                put("customDaysCsv", item.customDaysCsv)
                put("targetValue", item.targetValue)
                put("currentProgressToday", item.currentProgressToday)
                put("targetUnit", item.targetUnit)
                put("longestStreak", item.longestStreak.coerceAtLeast(item.streakCount))
                put("isPaused", item.isPaused)
                put("hasReminder", item.hasReminder)
                put("completedDaysHistoryCsv", item.completedDaysHistoryCsv)
            }
            array.put(obj)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ITEMS, array.toString())
            .apply()
    }

    fun addOrUpdateItem(context: Context, item: ReminderItem) {
        val items = getAllItems(context)
        val index = items.indexOfFirst { it.id == item.id }
        if (index >= 0) {
            items[index] = item
        } else {
            items.add(0, item)
        }
        saveAllItems(context, items)
    }

    fun deleteItem(context: Context, itemId: String) {
        val items = getAllItems(context).filterNot { it.id == itemId }
        saveAllItems(context, items)
    }

    fun getItemById(context: Context, itemId: String): ReminderItem? {
        return getAllItems(context).firstOrNull { it.id == itemId }
    }

    fun markCompleted(context: Context, itemId: String): ReminderItem? {
        val items = getAllItems(context)
        val index = items.indexOfFirst { it.id == itemId }
        if (index == -1) return null

        val current = items[index]
        val todayEpoch = currentEpochDay()
        val historySet = current.completedDaysHistoryCsv.split(",")
            .filter { it.isNotBlank() }
            .toMutableSet()
        historySet.add(todayEpoch.toString())

        val updated = if (current.isHabit) {
            val newStreak = if (current.lastCompletedEpochDay == todayEpoch) {
                current.streakCount
            } else {
                current.streakCount + 1
            }
            val nextGoal = if (newStreak > current.streakGoal) current.streakGoal + 7 else current.streakGoal
            current.copy(
                streakCount = newStreak,
                longestStreak = maxOf(current.longestStreak, newStreak),
                streakGoal = nextGoal,
                lastCompletedEpochDay = todayEpoch,
                isCompletedToday = true,
                currentProgressToday = current.targetValue,
                completedDaysHistoryCsv = historySet.joinToString(",")
            )
        } else {
            current.copy(
                lastCompletedEpochDay = todayEpoch,
                isCompletedToday = true,
                completedDaysHistoryCsv = historySet.joinToString(",")
            )
        }

        items[index] = updated
        saveAllItems(context, items)

        if (updated.isHabit && !updated.isPaused && updated.hasReminder) {
            AlarmScheduler.scheduleNextOccurrence(context, updated, forceTomorrow = true)
        }
        return updated
    }

    fun incrementHabitStep(context: Context, itemId: String): ReminderItem? {
        val item = getItemById(context, itemId) ?: return null
        if (!item.isHabit) return markCompleted(context, itemId)
        val nextStep = item.currentProgressToday + 1
        return if (nextStep >= item.targetValue) {
            markCompleted(context, itemId)
        } else {
            val updated = item.copy(currentProgressToday = nextStep)
            addOrUpdateItem(context, updated)
            updated
        }
    }

    fun toggleHabitPause(context: Context, itemId: String): ReminderItem? {
        val item = getItemById(context, itemId) ?: return null
        val nextPaused = !item.isPaused
        val updated = item.copy(isPaused = nextPaused)
        addOrUpdateItem(context, updated)
        if (nextPaused) {
            AlarmScheduler.cancelAlarm(context, itemId)
        } else if (updated.hasReminder) {
            AlarmScheduler.scheduleNextOccurrence(context, updated)
        }
        return updated
    }

    // تسجيل جلسة تركيز فعلية وربطها بالمهمة دون تكرار
    fun recordCompletedFocusSession(
        context: Context,
        sessionId: String,
        taskId: String?,
        actualMinutes: Int
    ): Int {
        if (actualMinutes <= 0) return getTodayFocusMinutes(context)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val rawHistory = prefs.getString(KEY_FOCUS_HISTORY, "[]") ?: "[]"
        val historyArray = try { JSONArray(rawHistory) } catch (_: Exception) { JSONArray() }

        // منع تكرار تسجيل نفس الجلسة
        for (i in 0 until historyArray.length()) {
            if (historyArray.getJSONObject(i).optString("id") == sessionId) {
                return getTodayFocusMinutes(context)
            }
        }

        val todayEpoch = currentEpochDay()
        val linkedTask = if (!taskId.isNullOrBlank()) getItemById(context, taskId) else null

        val recordObj = JSONObject().apply {
            put("id", sessionId)
            put("taskId", taskId ?: "")
            put("taskTitle", linkedTask?.title ?: "General Focus")
            put("durationMinutes", actualMinutes)
            put("timestampMillis", System.currentTimeMillis())
            put("epochDay", todayEpoch)
        }
        historyArray.put(recordObj)
        prefs.edit().putString(KEY_FOCUS_HISTORY, historyArray.toString()).apply()

        // تحديث إحصائيات المهمة المرتبطة
        if (linkedTask != null) {
            val updatedTask = linkedTask.copy(
                actualFocusedMinutes = linkedTask.actualFocusedMinutes + actualMinutes,
                focusSessionsCount = linkedTask.focusSessionsCount + 1
            )
            addOrUpdateItem(context, updatedTask)
        }

        return addFocusMinutes(context, actualMinutes)
    }

    fun getFocusHistory(context: Context): List<FocusSessionRecord> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_FOCUS_HISTORY, "[]") ?: "[]"
        val list = mutableListOf<FocusSessionRecord>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FocusSessionRecord(
                        id = o.optString("id"),
                        taskId = o.optString("taskId").takeIf { it.isNotBlank() },
                        taskTitle = o.optString("taskTitle", "General Focus"),
                        durationMinutes = o.optInt("durationMinutes", 0),
                        timestampMillis = o.optLong("timestampMillis", 0L),
                        epochDay = o.optLong("epochDay", currentEpochDay())
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    fun getTodayFocusMinutes(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val todayEpoch = currentEpochDay()
        val savedDay = prefs.getLong(KEY_FOCUS_EPOCH_DAY, -1L)
        if (savedDay != todayEpoch) {
            prefs.edit()
                .putLong(KEY_FOCUS_EPOCH_DAY, todayEpoch)
                .putInt(KEY_FOCUS_MINUTES, 0)
                .apply()
            return 0
        }
        return prefs.getInt(KEY_FOCUS_MINUTES, 0)
    }

    fun addFocusMinutes(context: Context, minutes: Int): Int {
        val current = getTodayFocusMinutes(context) + minutes
        val todayEpoch = currentEpochDay()
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putLong(KEY_FOCUS_EPOCH_DAY, todayEpoch)
            .putInt(KEY_FOCUS_MINUTES, current)
            .apply()
        return current
    }

    fun getTodayFocusSessions(context: Context): Int {
        val today = currentEpochDay()
        val countFromHistory = getFocusHistory(context).count { it.epochDay == today }
        return if (countFromHistory > 0) countFromHistory else (getTodayFocusMinutes(context) / 25)
    }

    fun getTotalAllTimeFocusMinutes(context: Context): Int {
        val historySum = getFocusHistory(context).sumOf { it.durationMinutes }
        return maxOf(historySum, getTodayFocusMinutes(context))
    }

    fun getTotalAllTimeFocusSessions(context: Context): Int {
        return maxOf(getFocusHistory(context).size, getTodayFocusSessions(context))
    }

    // حفظ واستعادة حالة مؤقت التركيز النشط بدقة
    fun saveActiveFocusState(
        context: Context,
        startEpochMs: Long,
        totalDurationMs: Long,
        remainingOnPauseMs: Long,
        isRunning: Boolean,
        linkedTaskId: String?,
        isBreakMode: Boolean
    ) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().apply {
            putLong(KEY_ACTIVE_FOCUS_START_MS, startEpochMs)
            putLong(KEY_ACTIVE_FOCUS_TOTAL_MS, totalDurationMs)
            putLong(KEY_ACTIVE_FOCUS_REMAINING_PAUSE_MS, remainingOnPauseMs)
            putBoolean(KEY_ACTIVE_FOCUS_RUNNING, isRunning)
            putString(KEY_ACTIVE_FOCUS_TASK_ID, linkedTaskId ?: "")
            putBoolean(KEY_ACTIVE_FOCUS_IS_BREAK, isBreakMode)
            apply()
        }
    }

    fun clearActiveFocusState(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().apply {
            remove(KEY_ACTIVE_FOCUS_START_MS)
            remove(KEY_ACTIVE_FOCUS_TOTAL_MS)
            remove(KEY_ACTIVE_FOCUS_REMAINING_PAUSE_MS)
            putBoolean(KEY_ACTIVE_FOCUS_RUNNING, false)
            apply()
        }
    }

    fun getActiveFocusState(context: Context): JSONObject {
        val p = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return JSONObject().apply {
            put("startMs", p.getLong(KEY_ACTIVE_FOCUS_START_MS, 0L))
            put("totalMs", p.getLong(KEY_ACTIVE_FOCUS_TOTAL_MS, 25 * 60 * 1000L))
            put("remainingPauseMs", p.getLong(KEY_ACTIVE_FOCUS_REMAINING_PAUSE_MS, 25 * 60 * 1000L))
            put("isRunning", p.getBoolean(KEY_ACTIVE_FOCUS_RUNNING, false))
            put("taskId", p.getString(KEY_ACTIVE_FOCUS_TASK_ID, "") ?: "")
            put("isBreak", p.getBoolean(KEY_ACTIVE_FOCUS_IS_BREAK, false))
        }
    }

    fun getPreAlertMinutes(context: Context): Int {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_PRE_ALERT_MINUTES, 10)
    }

    fun setPreAlertMinutes(context: Context, minutes: Int) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_PRE_ALERT_MINUTES, minutes)
            .apply()
    }

    fun getAlarmRingtoneUri(context: Context): Uri {
        val uriStr = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_RINGTONE_URI, null)
        return if (uriStr != null) Uri.parse(uriStr)
        else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    }

    fun setAlarmRingtoneUri(context: Context, uri: Uri) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_RINGTONE_URI, uri.toString())
            .apply()
    }

    fun getCustomQuotes(context: Context): MutableList<String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_CUSTOM_QUOTES, null)
        val list = mutableListOf<String>()
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    list.add(arr.getString(i))
                }
            } catch (_: Exception) {}
        }
        return list
    }

    fun addCustomQuote(context: Context, quote: String) {
        val list = getCustomQuotes(context)
        if (!list.contains(quote)) {
            list.add(0, quote)
            val arr = JSONArray(list)
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_CUSTOM_QUOTES, arr.toString())
                .apply()
        }
    }

    fun deleteCustomQuote(context: Context, quote: String) {
        val list = getCustomQuotes(context).filterNot { it == quote }
        val arr = JSONArray(list)
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_CUSTOM_QUOTES, arr.toString())
            .apply()
    }

    fun getLinkedGoogleEmail(context: Context): String? {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_GOOGLE_EMAIL, null)
    }

    fun setLinkedGoogleEmail(context: Context, email: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_GOOGLE_EMAIL, email)
            .apply()
    }

    // نسخ احتياطي واستعادة مع فحص السلامة وتوافق الإصدارات
    fun exportCloudBackupJson(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val settingsPrefs = context.getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
        val settingsObj = JSONObject().apply {
            put(KEY_DARK_MODE, settingsPrefs.getBoolean(KEY_DARK_MODE, true))
            put(KEY_ACCENT_COLOR, settingsPrefs.getString(KEY_ACCENT_COLOR, "#38BDF8"))
            put(KEY_REDUCE_MOTION, settingsPrefs.getBoolean(KEY_REDUCE_MOTION, false))
            put(KEY_DEFAULT_FOCUS_MINS, settingsPrefs.getInt(KEY_DEFAULT_FOCUS_MINS, 25))
            put(KEY_DEFAULT_BREAK_MINS, settingsPrefs.getInt(KEY_DEFAULT_BREAK_MINS, 5))
            put(KEY_DAILY_FOCUS_GOAL_MINS, settingsPrefs.getInt(KEY_DAILY_FOCUS_GOAL_MINS, 120))
            put(KEY_NOTIF_TASKS, settingsPrefs.getBoolean(KEY_NOTIF_TASKS, true))
            put(KEY_NOTIF_HABITS, settingsPrefs.getBoolean(KEY_NOTIF_HABITS, true))
            put(KEY_NOTIF_SESSION_END, settingsPrefs.getBoolean(KEY_NOTIF_SESSION_END, true))
            put(KEY_NOTIF_ACHIEVEMENTS, settingsPrefs.getBoolean(KEY_NOTIF_ACHIEVEMENTS, true))
        }
        val root = JSONObject().apply {
            put("app", "WAQT")
            put("schemaVersion", 3)
            put("version", "3.0.0")
            put("timestamp", System.currentTimeMillis())
            put("email", getLinkedGoogleEmail(context) ?: "local_user")
            put("focusMinutes", getTodayFocusMinutes(context))
            put("preAlertMinutes", getPreAlertMinutes(context))
            put("customQuotes", JSONArray(getCustomQuotes(context)))
            put("items", JSONArray(prefs.getString(KEY_ITEMS, "[]")))
            put("focusHistory", JSONArray(prefs.getString(KEY_FOCUS_HISTORY, "[]")))
            put("settings", settingsObj)
        }
        return root.toString(2)
    }

    fun importCloudBackupJson(context: Context, jsonString: String): Boolean {
        return try {
            val root = JSONObject(jsonString)
            if (root.optString("app") != "WAQT" && !root.has("items")) return false
            val itemsArr = root.getJSONArray("items")
            // التحقق من سلامة عناصر النسخة الاحتياطية قبل الاستبدال
            for (i in 0 until itemsArr.length()) {
                val itemObj = itemsArr.getJSONObject(i)
                if (!itemObj.has("id") || !itemObj.has("title")) return false
            }

            val focusMins = root.optInt("focusMinutes", 0)
            val preAlertMins = root.optInt("preAlertMinutes", 10)
            val quotesArr = root.optJSONArray("customQuotes")
            val historyArr = root.optJSONArray("focusHistory")
            val settingsObj = root.optJSONObject("settings")

            val editor = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            editor.putString(KEY_ITEMS, itemsArr.toString())
            editor.putInt(KEY_FOCUS_MINUTES, focusMins)
            editor.putInt(KEY_PRE_ALERT_MINUTES, preAlertMins)
            if (quotesArr != null) editor.putString(KEY_CUSTOM_QUOTES, quotesArr.toString())
            if (historyArr != null) editor.putString(KEY_FOCUS_HISTORY, historyArr.toString())
            editor.apply()

            if (settingsObj != null) {
                val sEdit = context.getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE).edit()
                if (settingsObj.has(KEY_DARK_MODE)) sEdit.putBoolean(KEY_DARK_MODE, settingsObj.optBoolean(KEY_DARK_MODE, true))
                if (settingsObj.has(KEY_ACCENT_COLOR)) sEdit.putString(KEY_ACCENT_COLOR, settingsObj.optString(KEY_ACCENT_COLOR, "#38BDF8"))
                if (settingsObj.has(KEY_DEFAULT_FOCUS_MINS)) sEdit.putInt(KEY_DEFAULT_FOCUS_MINS, settingsObj.optInt(KEY_DEFAULT_FOCUS_MINS, 25))
                if (settingsObj.has(KEY_DEFAULT_BREAK_MINS)) sEdit.putInt(KEY_DEFAULT_BREAK_MINS, settingsObj.optInt(KEY_DEFAULT_BREAK_MINS, 5))
                if (settingsObj.has(KEY_DAILY_FOCUS_GOAL_MINS)) sEdit.putInt(KEY_DAILY_FOCUS_GOAL_MINS, settingsObj.optInt(KEY_DAILY_FOCUS_GOAL_MINS, 120))
                sEdit.apply()
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun seedDefaultItems(context: Context): MutableList<ReminderItem> {
        val today = currentEpochDay()
        val defaults = mutableListOf(
            ReminderItem(
                id = "waqt_habit_1",
                title = "قراءة ١٥ صفحة في بنية البرمجيات",
                isHabit = true,
                hour = 9,
                minute = 0,
                streakCount = 5,
                streakGoal = 7,
                priority = "medium",
                category = "study",
                targetValue = 15,
                currentProgressToday = 0,
                targetUnit = "صفحة",
                longestStreak = 5,
                completedDaysHistoryCsv = "${today - 1},${today - 2},${today - 3}"
            ),
            ReminderItem(
                id = "waqt_task_1",
                title = "مراجعة وتسليم المشروع النهائي",
                isHabit = false,
                hour = 14,
                minute = 30,
                streakCount = 0,
                streakGoal = 7,
                priority = "high",
                category = "work",
                dueDateEpochDay = today,
                expectedMinutes = 50,
                actualFocusedMinutes = 25,
                focusSessionsCount = 1
            )
        )
        saveAllItems(context, defaults)
        return defaults
    }
}

object AlarmScheduler {
    const val ACTION_TRIGGER_REMINDER = "com.example.glassproductivity.ACTION_TRIGGER_REMINDER"
    const val ACTION_PRE_NOTIFY = "com.example.glassproductivity.ACTION_PRE_NOTIFY"
    const val ACTION_COMPLETE_FROM_NOTIF = "com.example.glassproductivity.ACTION_COMPLETE_FROM_NOTIF"
    const val ACTION_SNOOZE_10M_FROM_NOTIF = "com.example.glassproductivity.ACTION_SNOOZE_10M_FROM_NOTIF"
    const val ACTION_SNOOZE_1H_FROM_NOTIF = "com.example.glassproductivity.ACTION_SNOOZE_1H_FROM_NOTIF"

    const val EXTRA_ITEM_ID = "extra_item_id"
    const val EXTRA_TITLE = "extra_title"
    const val EXTRA_IS_HABIT = "extra_is_habit"
    const val EXTRA_STREAK_COUNT = "extra_streak_count"
    const val EXTRA_STREAK_GOAL = "extra_streak_goal"

    fun scheduleNextOccurrence(
        context: Context,
        item: ReminderItem,
        forceTomorrow: Boolean = false
    ): Long {
        if (item.isPaused || !item.hasReminder) {
            cancelAlarm(context, item.id)
            return -1L
        }

        val settingsPrefs = context.getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
        if (item.isHabit && !settingsPrefs.getBoolean(ReminderRepository.KEY_NOTIF_HABITS, true)) return -1L
        if (!item.isHabit && !settingsPrefs.getBoolean(ReminderRepository.KEY_NOTIF_TASKS, true)) return -1L

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val nowMillis = System.currentTimeMillis()

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, item.hour)
            set(Calendar.MINUTE, item.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (forceTomorrow) {
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        } else if (calendar.timeInMillis <= nowMillis) {
            val diffSeconds = (nowMillis - calendar.timeInMillis) / 1000L
            if (diffSeconds < 60L) {
                calendar.timeInMillis = nowMillis + 5000L
            } else {
                calendar.add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val pendingIntent = buildAlarmPendingIntent(context, item, ACTION_TRIGGER_REMINDER)
        setAlarmClockSafely(context, alarmManager, calendar.timeInMillis, pendingIntent)

        val preAlertMinutes = ReminderRepository.getPreAlertMinutes(context)
        val preNotifyMillis = calendar.timeInMillis - (preAlertMinutes * 60 * 1000L)
        if (preNotifyMillis > nowMillis + 5000L && settingsPrefs.getBoolean(ReminderRepository.KEY_NOTIF_SUMMARIES, true)) {
            val prePendingIntent = buildAlarmPendingIntent(context, item, ACTION_PRE_NOTIFY)
            setAlarmClockSafely(context, alarmManager, preNotifyMillis, prePendingIntent)
        }

        return calendar.timeInMillis
    }

    fun scheduleExactDelayMillis(context: Context, item: ReminderItem, delayMillis: Long): Long {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerAtMillis = System.currentTimeMillis() + delayMillis
        val pendingIntent = buildAlarmPendingIntent(context, item, ACTION_TRIGGER_REMINDER)
        setAlarmClockSafely(context, alarmManager, triggerAtMillis, pendingIntent)
        return triggerAtMillis
    }

    fun scheduleSnooze(context: Context, item: ReminderItem, snoozeMinutes: Int = 10): Long {
        return scheduleExactDelayMillis(context, item, snoozeMinutes * 60 * 1000L)
    }

    fun cancelAlarm(context: Context, itemId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_TRIGGER_REMINDER
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            itemId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    private fun buildAlarmPendingIntent(context: Context, item: ReminderItem, actionString: String): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = actionString
            putExtra(EXTRA_ITEM_ID, item.id)
            putExtra(EXTRA_TITLE, item.title)
            putExtra(EXTRA_IS_HABIT, item.isHabit)
            putExtra(EXTRA_STREAK_COUNT, item.streakCount)
            putExtra(EXTRA_STREAK_GOAL, item.streakGoal)
        }
        return PendingIntent.getBroadcast(
            context,
            item.id.hashCode() + if (actionString == ACTION_PRE_NOTIFY) 1 else 0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun setAlarmClockSafely(
        context: Context,
        alarmManager: AlarmManager,
        triggerAtMillis: Long,
        pendingIntent: PendingIntent
    ) {
        try {
            val showIntent = Intent(context, MainActivity::class.java)
            val showPendingIntent = PendingIntent.getActivity(
                context,
                0,
                showIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val alarmClockInfo = AlarmManager.AlarmClockInfo(triggerAtMillis, showPendingIntent)
            alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
        } catch (_: Exception) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            }
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ALARM_CHANNEL_ID = "waqt_alarm_critical_channel"
        const val MOTIVATION_CHANNEL_ID = "waqt_motivation_channel"
        const val NOTIF_ID_ALARM = 9091
        const val NOTIF_ID_MOTIVATION = 8082
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return

        when (action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> {
                val items = ReminderRepository.getAllItems(context)
                items.forEach { item ->
                    if (!item.isPaused && item.hasReminder && (item.isHabit || !item.isCompletedToday)) {
                        AlarmScheduler.scheduleNextOccurrence(context, item)
                    }
                }
            }

            AlarmScheduler.ACTION_COMPLETE_FROM_NOTIF -> {
                val itemId = intent.getStringExtra(AlarmScheduler.EXTRA_ITEM_ID) ?: return
                ReminderRepository.markCompleted(context, itemId)
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancel(itemId.hashCode())
                nm.cancel(NOTIF_ID_ALARM)
                context.sendBroadcast(Intent(FloatingCardService.ACTION_DATA_UPDATED).setPackage(context.packageName))
                val isAr = context.getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE).getBoolean("is_arabic", true)
                Toast.makeText(context, if (isAr) "✓ تم إتمام المهمة بنجاح" else "✓ Task marked as completed", Toast.LENGTH_SHORT).show()
            }

            AlarmScheduler.ACTION_SNOOZE_10M_FROM_NOTIF -> {
                handleSnoozeFromNotification(context, intent, 10)
            }

            AlarmScheduler.ACTION_SNOOZE_1H_FROM_NOTIF -> {
                handleSnoozeFromNotification(context, intent, 60)
            }

            AlarmScheduler.ACTION_PRE_NOTIFY -> {
                if (!isInQuietHours(context)) {
                    sendPreAlarmMotivation(context, intent)
                }
            }

            AlarmScheduler.ACTION_TRIGGER_REMINDER -> {
                triggerFullSystemAlarm(context, intent)
            }
        }
    }

    private fun handleSnoozeFromNotification(context: Context, intent: Intent, minutes: Int) {
        val itemId = intent.getStringExtra(AlarmScheduler.EXTRA_ITEM_ID) ?: return
        val title = intent.getStringExtra(AlarmScheduler.EXTRA_TITLE) ?: "WAQT"
        val item = ReminderRepository.getItemById(context, itemId) ?: ReminderItem(
            id = itemId,
            title = title,
            isHabit = false,
            hour = 9,
            minute = 0
        )
        AlarmScheduler.scheduleSnooze(context, item, snoozeMinutes = minutes)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(itemId.hashCode())
        nm.cancel(NOTIF_ID_ALARM)
        val isAr = context.getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE).getBoolean("is_arabic", true)
        Toast.makeText(
            context,
            if (isAr) "⏰ تم تأجيل التذكير لمدة $minutes دقيقة" else "⏰ Reminder snoozed for $minutes mins",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun isInQuietHours(context: Context): Boolean {
        val prefs = context.getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean(ReminderRepository.KEY_QUIET_HOURS, false)) return false
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return (hour >= 23 || hour < 7)
    }

    private fun triggerFullSystemAlarm(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
        val isArabic = prefs.getBoolean("is_arabic", Locale.getDefault().language == "ar")
        val itemId = intent.getStringExtra(AlarmScheduler.EXTRA_ITEM_ID) ?: ""
        val storedItem = ReminderRepository.getItemById(context, itemId)
        val isHabit = storedItem?.isHabit ?: intent.getBooleanExtra(AlarmScheduler.EXTRA_IS_HABIT, false)

        if (isHabit && !prefs.getBoolean(ReminderRepository.KEY_NOTIF_HABITS, true)) return
        if (!isHabit && !prefs.getBoolean(ReminderRepository.KEY_NOTIF_TASKS, true)) return

        val title = storedItem?.title ?: intent.getStringExtra(AlarmScheduler.EXTRA_TITLE) ?: if (isArabic) "تذكير وقت" else "WAQT Reminder"

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val wakeLock = powerManager?.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "WAQT::FullAlarmWakeLock"
        )
        wakeLock?.acquire(12000L)

        val alarmSoundUri: Uri = ReminderRepository.getAlarmRingtoneUri(context)
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .build()

            val channel = NotificationChannel(
                ALARM_CHANNEL_ID,
                if (isArabic) "تنبيهات منبه وَقْت" else "WAQT Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Critical task and habit alarms"
                setSound(alarmSoundUri, audioAttributes)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            itemId.hashCode(),
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // أزرار الإجراءات المباشرة من الإشعار (تم • بعد 10 دقائق • بعد ساعة)
        val completeIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmScheduler.ACTION_COMPLETE_FROM_NOTIF
            putExtra(AlarmScheduler.EXTRA_ITEM_ID, itemId)
        }
        val completePending = PendingIntent.getBroadcast(
            context,
            itemId.hashCode() + 10,
            completeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snooze10Intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmScheduler.ACTION_SNOOZE_10M_FROM_NOTIF
            putExtra(AlarmScheduler.EXTRA_ITEM_ID, itemId)
            putExtra(AlarmScheduler.EXTRA_TITLE, title)
        }
        val snooze10Pending = PendingIntent.getBroadcast(
            context,
            itemId.hashCode() + 20,
            snooze10Intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snooze1hIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmScheduler.ACTION_SNOOZE_1H_FROM_NOTIF
            putExtra(AlarmScheduler.EXTRA_ITEM_ID, itemId)
            putExtra(AlarmScheduler.EXTRA_TITLE, title)
        }
        val snooze1hPending = PendingIntent.getBroadcast(
            context,
            itemId.hashCode() + 30,
            snooze1hIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, ALARM_CHANNEL_ID)
            .setSmallIcon(R.drawable.logo_waqt)
            .setContentTitle(if (isArabic) "⏰ حان موعد: $title" else "⏰ Due now: $title")
            .setContentText(if (isArabic) "اختر إجراءً سريعاً أو افتح التطبيق" else "Choose a quick action or open WAQT")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setSound(alarmSoundUri)
            .setVibrate(longArrayOf(0, 400, 200, 400))
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setAutoCancel(true)
            .addAction(0, if (isArabic) "تم ✓" else "Done ✓", completePending)
            .addAction(0, if (isArabic) "بعد 10 د" else "+10m", snooze10Pending)
            .addAction(0, if (isArabic) "بعد ساعة" else "+1h", snooze1hPending)
            .build()

        notificationManager.notify(NOTIF_ID_ALARM, notification)

        val autoFloat = prefs.getBoolean(ReminderRepository.KEY_AUTO_FLOAT, true)
        if (autoFloat && Settings.canDrawOverlays(context)) {
            val serviceIntent = Intent(context, FloatingCardService::class.java).apply {
                putExtra(FloatingCardService.EXTRA_ITEM_ID, storedItem?.id ?: itemId)
                putExtra(FloatingCardService.EXTRA_TITLE, title)
                putExtra(FloatingCardService.EXTRA_IS_HABIT, isHabit)
                putExtra(FloatingCardService.EXTRA_STREAK_COUNT, storedItem?.streakCount ?: intent.getIntExtra(AlarmScheduler.EXTRA_STREAK_COUNT, 0))
                putExtra(FloatingCardService.EXTRA_STREAK_GOAL, storedItem?.streakGoal ?: intent.getIntExtra(AlarmScheduler.EXTRA_STREAK_GOAL, 7))
                putExtra(FloatingCardService.EXTRA_IS_ARABIC, isArabic)
            }
            ContextCompat.startForegroundService(context, serviceIntent)
        }
    }

    private fun sendPreAlarmMotivation(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean(ReminderRepository.KEY_NOTIF_SUMMARIES, true)) return

        val isArabic = prefs.getBoolean("is_arabic", Locale.getDefault().language == "ar")
        val title = intent.getStringExtra(AlarmScheduler.EXTRA_TITLE) ?: "Focus"
        val preMinutes = ReminderRepository.getPreAlertMinutes(context)

        val customQuotes = ReminderRepository.getCustomQuotes(context)
        val defaultQuotes = if (isArabic) listOf(
            "مهمتك التالية في انتظارك: «$title» بعد $preMinutes دقائق.",
            "ابدأ بخطوة صغيرة • موعد «$title» يقترب.",
            "الوقت هو أغلى مواردك، فلا تضيعه."
        ) else listOf(
            "Next up: \"$title\" in $preMinutes minutes.",
            "Start with a small step • \"$title\" begins soon.",
            "Time is your most valuable resource, don't waste it."
        )

        val allQuotes = if (customQuotes.isNotEmpty()) customQuotes + defaultQuotes else defaultQuotes
        val message = allQuotes.random()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                MOTIVATION_CHANNEL_ID,
                if (isArabic) "تذكيرات وَقْت التمهيدية" else "WAQT Pre-Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val openIntent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, MOTIVATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.logo_waqt)
            .setContentTitle(if (isArabic) "وَقْت • تذكير تمهيدي ⏳" else "WAQT • Upcoming Task ⏳")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        context.getSystemService(NotificationManager::class.java).notify(NOTIF_ID_MOTIVATION, notification)
    }
}

class FloatingCardService : Service() {

    companion object {
        const val CHANNEL_ID = "waqt_floating_overlay_channel"
        const val NOTIFICATION_ID = 4041

        const val EXTRA_ITEM_ID = "extra_item_id"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_IS_HABIT = "extra_is_habit"
        const val EXTRA_STREAK_COUNT = "extra_streak_count"
        const val EXTRA_STREAK_GOAL = "extra_streak_goal"
        const val EXTRA_IS_ARABIC = "extra_is_arabic"
        const val EXTRA_CUSTOM_MINUTES = "extra_custom_minutes"
        const val EXTRA_AUTO_START_FOCUS = "extra_auto_start_focus"
        const val EXTRA_SESSION_ID = "extra_session_id"

        const val ACTION_DATA_UPDATED = "com.example.glassproductivity.ACTION_DATA_UPDATED"

        private const val DEFAULT_POMODORO_MS = 25 * 60 * 1000L
    }

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private lateinit var layoutParams: WindowManager.LayoutParams

    private lateinit var cardExpandedContainer: LinearLayout
    private lateinit var bubbleMinimizedContainer: LinearLayout
    private lateinit var tvBadge: TextView
    private lateinit var tvBrandMark: TextView
    private lateinit var btnMinimize: TextView
    private lateinit var btnClose: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvSubtitle: TextView
    private lateinit var habitStreakContainer: LinearLayout
    private lateinit var tvStreakCount: TextView
    private lateinit var tvStreakGoal: TextView
    private lateinit var progressHabitStreak: ProgressBar
    private lateinit var actionButtonsRow: LinearLayout
    private lateinit var btnStartPomodoro: TextView
    private lateinit var btnSnooze: TextView
    private lateinit var pomodoroActiveContainer: LinearLayout
    private lateinit var tvPomodoroStatus: TextView
    private lateinit var tvPomodoroTimer: TextView
    private lateinit var progressPomodoro: ProgressBar
    private lateinit var btnPauseResumePomodoro: TextView
    private lateinit var btnStopPomodoro: TextView
    private lateinit var tvBubbleIcon: TextView
    private lateinit var tvBubbleText: TextView

    private var currentItemId: String = ""
    private var currentTitle: String = "WAQT Session"
    private var isHabit: Boolean = false
    private var streakCount: Int = 0
    private var streakGoal: Int = 7
    private var isArabic: Boolean = true
    private var isMinimized: Boolean = false

    private var savedExpandedX: Int = 0
    private var savedExpandedY: Int = 180

    private var countDownTimer: CountDownTimer? = null
    private var pomodoroDurationMs: Long = DEFAULT_POMODORO_MS
    private var remainingPomodoroMs: Long = DEFAULT_POMODORO_MS
    private var focusStartEpochMs: Long = 0L
    private var activeSessionId: String = UUID.randomUUID().toString()
    private var isPomodoroRunning: Boolean = false
    private var isPomodoroActiveMode: Boolean = false

    private var blurListener: Consumer<Boolean>? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startOverlayForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        var autoStartFocus = false
        if (intent != null) {
            currentItemId = intent.getStringExtra(EXTRA_ITEM_ID) ?: ""
            currentTitle = intent.getStringExtra(EXTRA_TITLE) ?: "Focus Session"
            isHabit = intent.getBooleanExtra(EXTRA_IS_HABIT, false)
            streakCount = intent.getIntExtra(EXTRA_STREAK_COUNT, 1)
            streakGoal = intent.getIntExtra(EXTRA_STREAK_GOAL, 7).coerceAtLeast(1)
            isArabic = intent.getBooleanExtra(EXTRA_IS_ARABIC, true)
            autoStartFocus = intent.getBooleanExtra(EXTRA_AUTO_START_FOCUS, false)
            activeSessionId = intent.getStringExtra(EXTRA_SESSION_ID) ?: UUID.randomUUID().toString()

            val customMins = intent.getIntExtra(EXTRA_CUSTOM_MINUTES, 25).coerceAtLeast(1)
            pomodoroDurationMs = customMins * 60 * 1000L
            remainingPomodoroMs = pomodoroDurationMs
        }

        if (floatingView == null) {
            inflateAndAttachFloatingCard()
        } else {
            bindCardData()
            expandFromBubbleIfNeeded()
        }

        if (autoStartFocus && !isPomodoroRunning) {
            startEmbeddedPomodoro()
        }

        triggerGentleHaptic()
        return START_REDELIVER_INTENT
    }

    private fun startOverlayForeground() {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.logo_waqt)
            .setContentTitle(if (isArabic) "وَقْت • نافذة التركيز العائمة" else "WAQT • Floating Focus Active")
            .setContentText(if (isArabic) "اضغط للعودة إلى التطبيق أو أتمم المهمة" else "Tap to return to WAQT")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun inflateAndAttachFloatingCard() {
        val inflater = LayoutInflater.from(this)
        val rootView = inflater.inflate(R.layout.layout_floating_card, null)
        floatingView = rootView

        cardExpandedContainer = rootView.findViewById(R.id.cardExpandedContainer)
        bubbleMinimizedContainer = rootView.findViewById(R.id.bubbleMinimizedContainer)
        tvBadge = rootView.findViewById(R.id.tvBadge)
        tvBrandMark = rootView.findViewById(R.id.tvBrandMark)
        btnMinimize = rootView.findViewById(R.id.btnMinimize)
        btnClose = rootView.findViewById(R.id.btnClose)
        tvTitle = rootView.findViewById(R.id.tvTitle)
        tvSubtitle = rootView.findViewById(R.id.tvSubtitle)
        habitStreakContainer = rootView.findViewById(R.id.habitStreakContainer)
        tvStreakCount = rootView.findViewById(R.id.tvStreakCount)
        tvStreakGoal = rootView.findViewById(R.id.tvStreakGoal)
        progressHabitStreak = rootView.findViewById(R.id.progressHabitStreak)
        actionButtonsRow = rootView.findViewById(R.id.actionButtonsRow)
        btnStartPomodoro = rootView.findViewById(R.id.btnStartPomodoro)
        btnSnooze = rootView.findViewById(R.id.btnSnooze)
        pomodoroActiveContainer = rootView.findViewById(R.id.pomodoroActiveContainer)
        tvPomodoroStatus = rootView.findViewById(R.id.tvPomodoroStatus)
        tvPomodoroTimer = rootView.findViewById(R.id.tvPomodoroTimer)
        progressPomodoro = rootView.findViewById(R.id.progressPomodoro)
        btnPauseResumePomodoro = rootView.findViewById(R.id.btnPauseResumePomodoro)
        btnStopPomodoro = rootView.findViewById(R.id.btnStopPomodoro)
        tvBubbleIcon = rootView.findViewById(R.id.tvBubbleIcon)
        tvBubbleText = rootView.findViewById(R.id.tvBubbleText)

        var windowFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            windowFlags = windowFlags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            windowFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val screenWidth = resources.displayMetrics.widthPixels
            val estimatedCardWidthPx = dpToPx(344)
            x = ((screenWidth - estimatedCardWidthPx) / 2).coerceAtLeast(16)
            y = dpToPx(96)
            savedExpandedX = x
            savedExpandedY = y

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                blurBehindRadius = 32
            }
        }

        setupGlassBlurAndFallback()
        bindCardData()
        setupClickListeners()
        setupDragAndDropTouchListener(rootView)

        windowManager.addView(rootView, layoutParams)
    }

    private fun setupGlassBlurAndFallback() {
        applyGlassSurfaceStyling()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            blurListener = Consumer<Boolean> { isBlurEnabled ->
                floatingView?.let { view ->
                    if (view.isAttachedToWindow) {
                        layoutParams.blurBehindRadius = if (isBlurEnabled) 32 else 0
                        windowManager.updateViewLayout(view, layoutParams)
                    }
                }
            }
            blurListener?.let { windowManager.addCrossWindowBlurEnabledListener(it) }
        }
    }

    private fun applyGlassSurfaceStyling() {
        val prefs = getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
        val opacityPct = prefs.getInt("pref_glass_opacity", 92).coerceIn(50, 100)
        val alphaInt = ((opacityPct / 100f) * 255).toInt().coerceIn(140, 250)
        val bgColor = Color.argb(alphaInt, 21, 30, 48) // #151E30

        val calmCardDrawable = GradientDrawable().apply {
            color = android.content.res.ColorStateList.valueOf(bgColor)
            cornerRadius = dpToPx(20).toFloat()
            setStroke(dpToPx(1), Color.parseColor("#3338BDF8"))
        }

        val calmBubbleDrawable = GradientDrawable().apply {
            color = android.content.res.ColorStateList.valueOf(bgColor)
            cornerRadius = dpToPx(24).toFloat()
            setStroke(dpToPx(1), Color.parseColor("#6638BDF8"))
        }

        cardExpandedContainer.background = calmCardDrawable
        bubbleMinimizedContainer.background = calmBubbleDrawable
    }

    private fun bindCardData() {
        tvTitle.text = currentTitle
        tvBrandMark.text = if (isArabic) "وَقْت" else "WAQT"
        val timeString = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())

        if (isHabit) {
            tvBadge.text = if (isArabic) "🌱 عادة يومية" else "🌱 Daily Habit"
            tvSubtitle.text = if (isArabic) "اضغط (—) للتصغير لفقاعة أو (✕) للإغلاق" else "Triggered at $timeString • Minimize (_) or Close (✕)"
            habitStreakContainer.visibility = View.VISIBLE
            tvStreakCount.text = if (isArabic) "🔥 سلسلة $streakCount أيام" else "🔥 $streakCount-day streak"
            tvStreakGoal.text = "$streakCount / $streakGoal " + (if (isArabic) "أيام" else "days")
            progressHabitStreak.max = streakGoal
            progressHabitStreak.progress = streakCount.coerceAtMost(streakGoal)
            tvBubbleIcon.text = if (isPomodoroActiveMode) "🍅" else "🌱"
        } else {
            tvBadge.text = if (isArabic) "🎯 جلسة ومهمة" else "🎯 Focus & Task"
            tvSubtitle.text = if (isArabic) "اضغط (—) للتصغير إلى فقاعة عائمة" else "Tap (—) to minimize to edge bubble"
            habitStreakContainer.visibility = View.GONE
            tvBubbleIcon.text = if (isPomodoroActiveMode) "🍅" else "🎯"
        }

        val mins = (pomodoroDurationMs / 60000L).toInt()
        btnSnooze.text = if (isArabic) "💤 غفوة 10 د" else "💤 10m"
        btnStartPomodoro.text = if (isArabic) "🍅 تركيز $mins د" else "🍅 Focus ${mins}m"

        if (!isPomodoroActiveMode) {
            tvBubbleText.text = if (isArabic) "وَقْت" else "WAQT"
        }
    }

    private fun setupClickListeners() {
        btnMinimize.setOnClickListener {
            minimizeToBubble()
        }

        btnClose.setOnClickListener {
            dismissOverlaySafely()
        }

        btnStartPomodoro.setOnClickListener {
            startEmbeddedPomodoro()
        }

        btnSnooze.setOnClickListener {
            snoozeForTenMinutes()
        }

        btnPauseResumePomodoro.setOnClickListener {
            if (isPomodoroRunning) {
                pausePomodoroTimer()
            } else {
                resumePomodoroTimer()
            }
        }

        btnStopPomodoro.setOnClickListener {
            stopAndRecordActualPomodoroTime()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupDragAndDropTouchListener(rootView: View) {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        val dragListener = View.OnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                        isDragging = true
                    }
                    if (isDragging) {
                        layoutParams.x = initialX + dx
                        layoutParams.y = initialY + dy
                        floatingView?.let { windowManager.updateViewLayout(it, layoutParams) }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        if (isMinimized) {
                            expandFromBubbleIfNeeded()
                        }
                    } else {
                        if (isMinimized) {
                            snapBubbleToNearestEdge()
                        } else {
                            savedExpandedX = layoutParams.x
                            savedExpandedY = layoutParams.y
                        }
                    }
                    true
                }

                else -> false
            }
        }

        rootView.setOnTouchListener(dragListener)
        cardExpandedContainer.setOnTouchListener(dragListener)
        bubbleMinimizedContainer.setOnTouchListener(dragListener)
    }

    private fun minimizeToBubble() {
        if (isMinimized) return
        savedExpandedX = layoutParams.x
        savedExpandedY = layoutParams.y
        isMinimized = true

        cardExpandedContainer.visibility = View.GONE
        bubbleMinimizedContainer.visibility = View.VISIBLE

        if (!isPomodoroActiveMode) {
            tvBubbleIcon.text = if (isHabit) "🌱" else "🎯"
            tvBubbleText.text = if (isArabic) "وَقْت" else "WAQT"
        }

        snapBubbleToNearestEdge()
    }

    private fun expandFromBubbleIfNeeded() {
        if (!isMinimized) return
        isMinimized = false

        bubbleMinimizedContainer.visibility = View.GONE
        cardExpandedContainer.visibility = View.VISIBLE

        layoutParams.x = savedExpandedX
        layoutParams.y = savedExpandedY
        floatingView?.let { windowManager.updateViewLayout(it, layoutParams) }
    }

    private fun snapBubbleToNearestEdge() {
        val screenWidth = resources.displayMetrics.widthPixels
        val midpoint = screenWidth / 2
        val targetX = if (layoutParams.x + dpToPx(40) < midpoint) {
            dpToPx(8)
        } else {
            screenWidth - dpToPx(116)
        }
        layoutParams.x = targetX
        floatingView?.let { windowManager.updateViewLayout(it, layoutParams) }
    }

    private fun startEmbeddedPomodoro() {
        isPomodoroActiveMode = true
        remainingPomodoroMs = pomodoroDurationMs
        focusStartEpochMs = System.currentTimeMillis()
        activeSessionId = UUID.randomUUID().toString()

        actionButtonsRow.visibility = View.GONE
        pomodoroActiveContainer.visibility = View.VISIBLE
        tvBubbleIcon.text = "🍅"
        progressPomodoro.max = (pomodoroDurationMs / 1000).toInt()

        startPomodoroCountDown(remainingPomodoroMs)
    }

    private fun startPomodoroCountDown(durationMs: Long) {
        countDownTimer?.cancel()
        isPomodoroRunning = true
        val startWallClock = System.currentTimeMillis()
        ReminderRepository.saveActiveFocusState(
            this,
            startEpochMs = startWallClock,
            totalDurationMs = pomodoroDurationMs,
            remainingOnPauseMs = durationMs,
            isRunning = true,
            linkedTaskId = currentItemId.takeIf { it.isNotBlank() && it != "pomodoro_session" },
            isBreakMode = false
        )

        btnPauseResumePomodoro.text = if (isArabic) "⏸ إيقاف مؤقت" else "⏸ Pause"
        tvPomodoroStatus.text = if (isArabic) "🍅 جلسة تركيز جارية" else "🍅 Focus Active"

        countDownTimer = object : CountDownTimer(durationMs, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                remainingPomodoroMs = millisUntilFinished
                val formatted = formatMillisToMmSs(millisUntilFinished)
                tvPomodoroTimer.text = formatted
                tvBubbleText.text = formatted
                progressPomodoro.progress = (millisUntilFinished / 1000L).toInt()
            }

            override fun onFinish() {
                remainingPomodoroMs = 0L
                isPomodoroRunning = false
                ReminderRepository.clearActiveFocusState(this@FloatingCardService)
                val fullMinutes = (pomodoroDurationMs / 60000L).toInt().coerceAtLeast(1)
                ReminderRepository.recordCompletedFocusSession(
                    this@FloatingCardService,
                    sessionId = activeSessionId,
                    taskId = currentItemId.takeIf { it.isNotBlank() && it != "pomodoro_session" },
                    actualMinutes = fullMinutes
                )

                tvPomodoroTimer.text = "00:00"
                tvBubbleText.text = if (isArabic) "تم!" else "Done!"
                tvPomodoroStatus.text = if (isArabic) "✅ اكتملت الجلسة (+$fullMinutes د)" else "✅ Completed (+${fullMinutes}m)"
                progressPomodoro.progress = 0
                btnPauseResumePomodoro.text = if (isArabic) "🔄 جلسة جديدة" else "🔄 Restart"

                triggerGentleHaptic()
                sendBroadcast(Intent(ACTION_DATA_UPDATED).setPackage(packageName))
                if (isMinimized) {
                    expandFromBubbleIfNeeded()
                }
            }
        }.start()
    }

    private fun pausePomodoroTimer() {
        countDownTimer?.cancel()
        isPomodoroRunning = false
        ReminderRepository.saveActiveFocusState(
            this,
            startEpochMs = 0L,
            totalDurationMs = pomodoroDurationMs,
            remainingOnPauseMs = remainingPomodoroMs,
            isRunning = false,
            linkedTaskId = currentItemId.takeIf { it.isNotBlank() && it != "pomodoro_session" },
            isBreakMode = false
        )
        btnPauseResumePomodoro.text = if (isArabic) "▶ استئناف" else "▶ Resume"
        tvPomodoroStatus.text = if (isArabic) "⏸ متوقف مؤقتاً" else "⏸ Paused"
    }

    private fun resumePomodoroTimer() {
        val nextDuration = if (remainingPomodoroMs <= 0L) {
            activeSessionId = UUID.randomUUID().toString()
            pomodoroDurationMs
        } else {
            remainingPomodoroMs
        }
        startPomodoroCountDown(nextDuration)
    }

    // تسجيل الوقت الفعلي فقط عند إنهاء الجلسة يدوياً
    private fun stopAndRecordActualPomodoroTime() {
        countDownTimer?.cancel()
        val spentMs = (pomodoroDurationMs - remainingPomodoroMs).coerceAtLeast(0L)
        val spentMinutes = (spentMs / 60000L).toInt()
        if (spentMinutes >= 1 && remainingPomodoroMs > 0L) {
            ReminderRepository.recordCompletedFocusSession(
                this,
                sessionId = activeSessionId,
                taskId = currentItemId.takeIf { it.isNotBlank() && it != "pomodoro_session" },
                actualMinutes = spentMinutes
            )
            Toast.makeText(
                this,
                if (isArabic) "تم تسجيل $spentMinutes دقيقة تركيز فعلية" else "Logged $spentMinutes min actual focus",
                Toast.LENGTH_SHORT
            ).show()
        }
        ReminderRepository.clearActiveFocusState(this)
        isPomodoroRunning = false
        isPomodoroActiveMode = false
        remainingPomodoroMs = pomodoroDurationMs

        pomodoroActiveContainer.visibility = View.GONE
        actionButtonsRow.visibility = View.VISIBLE
        tvBubbleIcon.text = if (isHabit) "🌱" else "🎯"
        tvBubbleText.text = if (isArabic) "وَقْت" else "WAQT"
        sendBroadcast(Intent(ACTION_DATA_UPDATED).setPackage(packageName))
    }

    private fun formatMillisToMmSs(millis: Long): String {
        val totalSeconds = (millis / 1000L).coerceAtLeast(0L)
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        return String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }

    private fun snoozeForTenMinutes() {
        countDownTimer?.cancel()
        val item = ReminderRepository.getItemById(this, currentItemId)
            ?: ReminderItem(
                id = currentItemId.ifBlank { UUID.randomUUID().toString() },
                title = currentTitle,
                isHabit = isHabit,
                hour = 9,
                minute = 0,
                streakCount = streakCount,
                streakGoal = streakGoal
            )

        AlarmScheduler.scheduleSnooze(this, item, snoozeMinutes = 10)
        Toast.makeText(
            this,
            if (isArabic) "💤 تم تأجيل «$currentTitle» لمدة 10 دقائق" else "💤 Snoozed \"$currentTitle\" for 10m",
            Toast.LENGTH_SHORT
        ).show()
        stopSelf()
    }

    private fun dismissOverlaySafely() {
        countDownTimer?.cancel()
        if (isPomodoroActiveMode && isPomodoroRunning) {
            val spentMins = ((pomodoroDurationMs - remainingPomodoroMs) / 60000L).toInt()
            if (spentMins >= 1) {
                ReminderRepository.recordCompletedFocusSession(
                    this,
                    sessionId = activeSessionId,
                    taskId = currentItemId.takeIf { it.isNotBlank() && it != "pomodoro_session" },
                    actualMinutes = spentMins
                )
            }
            ReminderRepository.clearActiveFocusState(this)
        } else if (currentItemId.isNotBlank() && currentItemId != "pomodoro_session") {
            ReminderRepository.markCompleted(this, currentItemId)
        }
        sendBroadcast(Intent(ACTION_DATA_UPDATED).setPackage(packageName))
        stopSelf()
    }

    private fun triggerGentleHaptic() {
        try {
            val prefs = getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("pref_haptics", true)) return
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                manager.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (vibrator.hasVibrator()) {
                vibrator.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (_: Exception) {
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "WAQT Floating Focus",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Displays WAQT floating focus timer over apps"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }

    override fun onDestroy() {
        countDownTimer?.cancel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            blurListener?.let {
                try {
                    windowManager.removeCrossWindowBlurEnabledListener(it)
                } catch (_: Exception) {
                }
            }
        }
        floatingView?.let { view ->
            if (view.isAttachedToWindow) {
                windowManager.removeView(view)
            }
        }
        floatingView = null
        super.onDestroy()
    }
}

class MainActivity : AppCompatActivity() {

    // الحالة العامة والمظهر (Section 2 & Section 14)
    private var isArabic: Boolean = true
    private var isDarkMode: Boolean = true
    private var reduceMotion: Boolean = false
    private var currentAccentColor: String = "#38BDF8"
    private var currentTab: Int = 0 // 0: المهام, 1: العادات, 2: التركيز

    // فلاتر وبحث شاشة المهام (Section 6 & Section 12)
    private var taskFilter: String = "all" // all, today, done, overdue
    private var selectedCategoryFilter: String = "all" // all, work, study, personal, health, goals
    private var searchQuery: String = ""
    private var smartSortMode: String = "none" // none, priority, time, duration
    private var isDailyPlanExpanded: Boolean = true
    private var isFocusStatsExpanded: Boolean = true

    // حالة مؤقت التركيز الدقيق وربطه بالمهام (Section 4 & Section 8)
    private var selectedPomodoroMinutes: Int = 25
    private var isBreakSession: Boolean = false
    private var pomodoroTotalMillis: Long = 25 * 60 * 1000L
    private var pomodoroRemainingMillis: Long = 25 * 60 * 1000L
    private var pomodoroStartWallClockMs: Long = 0L
    private var activeFocusSessionId: String = UUID.randomUUID().toString()
    private var selectedFocusTaskId: String? = null
    private var isPomodoroRunning: Boolean = false
    private var inAppCountDownTimer: CountDownTimer? = null
    private var circularTimerView: CircularTimerRingView? = null
    private var tvPomodoroStartBtn: TextView? = null

    // الصوت المحيطي والتعامل مع المقاطعات والمكالمات (Section 4.4)
    private var ambientAudioTrack: AudioTrack? = null
    private var isAmbientPlaying: Boolean = false
    private var selectedAmbientIndex: Int = 0
    private var ambientVolume: Float = 0.7f
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private var previewRingtone: Ringtone? = null

    private val audioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (isAmbientPlaying) {
                    stopAmbientSound()
                }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                ambientAudioTrack?.setVolume(ambientVolume * 0.25f)
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                ambientAudioTrack?.setVolume(ambientVolume)
            }
        }
    }

    // عناصر الواجهة الرئيسية
    private lateinit var rootLayout: FrameLayout
    private lateinit var mainContentLayout: FrameLayout
    private lateinit var splashLayout: LinearLayout
    private lateinit var headerContainer: LinearLayout
    private lateinit var tabContentContainer: FrameLayout
    private lateinit var bottomNavWrapper: FrameLayout
    private lateinit var fabAddCircular: TextView
    private lateinit var tvBrandLogo: TextView
    private lateinit var tvBrandSlogan: TextView
    private lateinit var btnLangToggle: TextView
    private lateinit var btnStatsHeader: TextView
    private lateinit var btnAchievementsHeader: TextView
    private lateinit var btnSettings: TextView
    private lateinit var bottomNavTasks: LinearLayout
    private lateinit var bottomNavHabits: LinearLayout
    private lateinit var bottomNavPomodoro: LinearLayout

    private var selectedHour: Int = 9
    private var selectedMinute: Int = 0

    // ألوان الهوية البصرية الديناميكية حسب الوضع الداكن أو الفاتح (Section 2)
    private fun bgPrimaryColor(): Int = Color.parseColor(if (isDarkMode) "#0B0F19" else "#F8FAFC")
    private fun bgCardColor(): Int = Color.parseColor(if (isDarkMode) "#151E30" else "#FFFFFF")
    private fun bgElevatedColor(): Int = Color.parseColor(if (isDarkMode) "#1E293B" else "#E2E8F0")
    private fun textPrimaryColor(): Int = Color.parseColor(if (isDarkMode) "#F8FAFC" else "#0F172A")
    private fun textSecondaryColor(): Int = Color.parseColor(if (isDarkMode) "#94A3B8" else "#475569")
    private fun accentPrimaryColor(): Int = Color.parseColor(currentAccentColor)
    private fun accentSecondaryColor(): Int = Color.parseColor("#8B5CF6")
    private fun successColor(): Int = Color.parseColor("#10B981")
    private fun alertColor(): Int = Color.parseColor("#FB7185")

    private val ringtonePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            if (uri != null) {
                ReminderRepository.setAlarmRingtoneUri(this, uri)
                Toast.makeText(
                    this,
                    if (isArabic) "✓ تم حفظ نغمة المنبه بنجاح" else "✓ Alarm ringtone saved",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        renderCurrentTab()
    }

    private val dataUpdateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            syncActiveFocusTimerFromStorage()
            renderCurrentTab()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        loadPreferencesState()

        val now = Calendar.getInstance().apply { add(Calendar.MINUTE, 10) }
        selectedHour = now.get(Calendar.HOUR_OF_DAY)
        selectedMinute = now.get(Calendar.MINUTE)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        buildRootAndShowSplash()
    }

    private fun loadPreferencesState() {
        val prefs = getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
        isArabic = prefs.getBoolean("is_arabic", true)
        isDarkMode = prefs.getBoolean(ReminderRepository.KEY_DARK_MODE, true)
        reduceMotion = prefs.getBoolean(ReminderRepository.KEY_REDUCE_MOTION, false)
        currentAccentColor = prefs.getString(ReminderRepository.KEY_ACCENT_COLOR, "#38BDF8") ?: "#38BDF8"
        selectedPomodoroMinutes = prefs.getInt(ReminderRepository.KEY_DEFAULT_FOCUS_MINS, 25)
        selectedAmbientIndex = prefs.getInt(ReminderRepository.KEY_DEFAULT_SOUND_INDEX, 0)
        ambientVolume = (prefs.getInt(ReminderRepository.KEY_SOUND_VOLUME, 70) / 100f).coerceIn(0.05f, 1.0f)
        isDailyPlanExpanded = !prefs.getBoolean(ReminderRepository.KEY_HIDE_DAILY_PLAN, false)

        pomodoroTotalMillis = selectedPomodoroMinutes * 60 * 1000L
        pomodoroRemainingMillis = pomodoroTotalMillis
        applyLayoutDirection()
    }

    private fun applyLayoutDirection() {
        window.decorView.layoutDirection = if (isArabic) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(FloatingCardService.ACTION_DATA_UPDATED)
        ContextCompat.registerReceiver(
            this,
            dataUpdateReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onResume() {
        super.onResume()
        if (::tabContentContainer.isInitialized) {
            syncActiveFocusTimerFromStorage()
            renderCurrentTab()
        }
    }

    override fun onPause() {
        super.onPause()
        // حفظ حالة المؤقت بدقة عند الخروج أو إغلاق الشاشة (Section 4.6)
        if (isPomodoroRunning) {
            ReminderRepository.saveActiveFocusState(
                this,
                startEpochMs = pomodoroStartWallClockMs,
                totalDurationMs = pomodoroTotalMillis,
                remainingOnPauseMs = pomodoroRemainingMillis,
                isRunning = true,
                linkedTaskId = selectedFocusTaskId,
                isBreakMode = isBreakSession
            )
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(dataUpdateReceiver)
        } catch (_: Exception) {
        }
        inAppCountDownTimer?.cancel()
        stopAmbientSound()
        previewRingtone?.stop()
    }

    // استعادة وحساب الوقت المتبقي الفعلي بدقة عند العودة للتطبيق أو فتح الشاشة
    private fun syncActiveFocusTimerFromStorage() {
        val state = ReminderRepository.getActiveFocusState(this)
        val wasRunning = state.optBoolean("isRunning", false)
        val totalMs = state.optLong("totalMs", selectedPomodoroMinutes * 60 * 1000L)
        val startMs = state.optLong("startMs", 0L)
        val savedTaskId = state.optString("taskId", "").takeIf { it.isNotBlank() }
        val wasBreak = state.optBoolean("isBreak", false)

        if (wasRunning && startMs > 0L) {
            val elapsed = System.currentTimeMillis() - startMs
            val remaining = totalMs - elapsed
            selectedFocusTaskId = savedTaskId
            isBreakSession = wasBreak
            pomodoroTotalMillis = totalMs

            if (remaining <= 0L) {
                // اكتملت الجلسة أثناء وجود التطبيق في الخلفية
                inAppCountDownTimer?.cancel()
                isPomodoroRunning = false
                ReminderRepository.clearActiveFocusState(this)
                if (!isBreakSession) {
                    val mins = (totalMs / 60000L).toInt().coerceAtLeast(1)
                    ReminderRepository.recordCompletedFocusSession(
                        this,
                        sessionId = activeFocusSessionId,
                        taskId = selectedFocusTaskId,
                        actualMinutes = mins
                    )
                    checkAndNotifyAchievements()
                }
                pomodoroRemainingMillis = pomodoroTotalMillis
            } else {
                pomodoroRemainingMillis = remaining
                pomodoroStartWallClockMs = startMs
                if (!isPomodoroRunning) {
                    startWallClockCountDown(remaining)
                }
            }
        }
    }

    // =========================================================================
    // 1. شاشة البداية الهادئة (SPLASH SCREEN)
    // =========================================================================

    private fun buildRootAndShowSplash() {
        rootLayout = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(bgPrimaryColor())
        }

        mainContentLayout = buildWaqtMainLayout().apply {
            visibility = View.GONE
        }
        rootLayout.addView(mainContentLayout)

        if (reduceMotion) {
            mainContentLayout.visibility = View.VISIBLE
            setContentView(rootLayout)
            syncActiveFocusTimerFromStorage()
            renderCurrentTab()
            return
        }

        splashLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0B0F19"))
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }

        val ivLogo = ImageView(this).apply {
            setImageResource(R.drawable.logo_waqt)
            val size = dp(128)
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                bottomMargin = dp(16)
            }
        }
        splashLayout.addView(ivLogo)

        val tvAppName = TextView(this).apply {
            text = if (isArabic) "وَقْت" else "WAQT"
            setTextColor(Color.parseColor("#F8FAFC"))
            textSize = 30f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        splashLayout.addView(tvAppName)

        val tvSplashSlogan = TextView(this).apply {
            text = ""
            setTextColor(Color.parseColor(currentAccentColor))
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(10), dp(24), 0)
        }
        splashLayout.addView(tvSplashSlogan)

        rootLayout.addView(splashLayout)
        setContentView(rootLayout)

        val fullSlogan = if (isArabic) "الوقت هو أغلى مواردك، فلا تضيعه." else "Time is your most valuable resource, don't waste it."
        animateTypewriterText(tvSplashSlogan, fullSlogan) {
            Handler(Looper.getMainLooper()).postDelayed({
                splashLayout.animate()
                    .alpha(0f)
                    .setDuration(300)
                    .withEndAction {
                        splashLayout.visibility = View.GONE
                        mainContentLayout.visibility = View.VISIBLE
                        syncActiveFocusTimerFromStorage()
                        renderCurrentTab()
                    }
                    .start()
            }, 450)
        }
    }

    private fun animateTypewriterText(textView: TextView, fullText: String, onComplete: () -> Unit) {
        val handler = Handler(Looper.getMainLooper())
        var currentIndex = 0
        val delayMs = 28L

        val runnable = object : Runnable {
            override fun run() {
                if (currentIndex <= fullText.length) {
                    textView.text = fullText.substring(0, currentIndex)
                    currentIndex++
                    handler.postDelayed(this, delayMs)
                } else {
                    onComplete()
                }
            }
        }
        handler.post(runnable)
    }

    // =========================================================================
    // 2. الهيكل العام: الهيدر المدمج + حاوية الشاشات + شريط التنقل السفلي (Section 3)
    // =========================================================================

    private fun buildWaqtMainLayout(): FrameLayout {
        val frame = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(bgPrimaryColor())
        }

        val verticalShell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }

        headerContainer = buildTopHeaderBar()
        verticalShell.addView(headerContainer)

        tabContentContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
        verticalShell.addView(tabContentContainer)

        bottomNavWrapper = buildBottomNavigationBar()
        verticalShell.addView(bottomNavWrapper)
        frame.addView(verticalShell)

        // زر الإضافة العائم (غير متداخل مع شريط التنقل السفلي ومريح للإصبع 56dp)
        fabAddCircular = TextView(this).apply {
            text = "+"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#0B0F19"))
            gravity = Gravity.CENTER
            contentDescription = if (isArabic) "إضافة عنصر جديد" else "Add new item"
            val size = dp(56)
            layoutParams = FrameLayout.LayoutParams(size, size).apply {
                gravity = Gravity.BOTTOM or Gravity.END
                marginEnd = dp(20)
                bottomMargin = dp(84)
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(accentPrimaryColor())
            }
            elevation = dp(8).toFloat()
            setOnClickListener {
                triggerGentleHaptic()
                if (currentTab == 0) showAddOrEditTaskDialog(null)
                else if (currentTab == 1) showAddOrEditHabitDialog(null)
            }
        }
        frame.addView(fabAddCircular)

        return frame
    }

    private fun buildTopHeaderBar(): LinearLayout {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(bgCardColor())
        }

        val logoIcon = ImageView(this).apply {
            setImageResource(R.drawable.logo_waqt)
            val s = dp(34)
            layoutParams = LinearLayout.LayoutParams(s, s).apply { marginEnd = dp(10) }
        }
        header.addView(logoIcon)

        val brandContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        tvBrandLogo = TextView(this).apply {
            text = if (isArabic) "وَقْت" else "WAQT"
            setTextColor(textPrimaryColor())
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
        }

        tvBrandSlogan = TextView(this).apply {
            text = if (isArabic) "الوقت هو أغلى مواردك، فلا تضيعه." else "Time is your most valuable resource, don't waste it."
            setTextColor(textSecondaryColor())
            textSize = 11f
            maxLines = 1
        }

        brandContainer.addView(tvBrandLogo)
        brandContainer.addView(tvBrandSlogan)
        header.addView(brandContainer)

        // أيقونة التقارير والإحصائيات (Section 9)
        btnStatsHeader = createHeaderActionButton("📊", if (isArabic) "الإحصائيات" else "Stats") {
            showStatisticsAndReportsDialog()
        }
        header.addView(btnStatsHeader)

        // أيقونة الإنجازات (Section 11)
        btnAchievementsHeader = createHeaderActionButton("🏆", if (isArabic) "الإنجازات" else "Badges") {
            showAchievementsDialog()
        }
        header.addView(btnAchievementsHeader)

        // زر تبديل اللغة (Section 14)
        btnLangToggle = TextView(this).apply {
            text = if (isArabic) "EN" else "عربي"
            setTextColor(accentPrimaryColor())
            textSize = 12f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            background = createPillDrawable(bgElevatedColor(), dp(12), currentAccentColor)
            val minTouch = dp(38)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, minTouch).apply {
                marginStart = dp(6)
            }
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { toggleLanguage() }
        }
        header.addView(btnLangToggle)

        // زر الإعدادات ⚙️ (Section 14)
        btnSettings = createHeaderActionButton("⚙️", if (isArabic) "الإعدادات" else "Settings") {
            showSettingsBottomSheet()
        }
        header.addView(btnSettings)

        return header
    }

    private fun createHeaderActionButton(symbol: String, contentDesc: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = symbol
            textSize = 16f
            gravity = Gravity.CENTER
            contentDescription = contentDesc
            val s = dp(38)
            layoutParams = LinearLayout.LayoutParams(s, s).apply { marginStart = dp(6) }
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setOnClickListener {
                triggerGentleHaptic()
                onClick()
            }
        }
    }

    private fun buildBottomNavigationBar(): FrameLayout {
        val navWrapper = FrameLayout(this).apply {
            setBackgroundColor(bgPrimaryColor())
            setPadding(dp(16), dp(6), dp(16), dp(10))
        }

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(20).toFloat()
                setColor(bgCardColor())
                setStroke(dp(1), Color.parseColor("#2694A3B8"))
            }
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        bottomNavTasks = createCenteredNavTabItem("🎯", if (isArabic) "المهام" else "Tasks", 0)
        bottomNavHabits = createCenteredNavTabItem("🌱", if (isArabic) "العادات" else "Habits", 1)
        bottomNavPomodoro = createCenteredNavTabItem("🍅", if (isArabic) "التركيز" else "Focus", 2)

        nav.addView(bottomNavTasks)
        nav.addView(bottomNavHabits)
        nav.addView(bottomNavPomodoro)
        navWrapper.addView(nav)
        return navWrapper
    }

    private fun createCenteredNavTabItem(icon: String, label: String, tabIndex: Int): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, dp(50), 1f).apply {
                marginStart = dp(4)
                marginEnd = dp(4)
            }
            isClickable = true
            isFocusable = true

            val tvIcon = TextView(context).apply {
                text = icon
                textSize = 15f
                gravity = Gravity.CENTER
            }
            val tvLabel = TextView(context).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
            }

            addView(tvIcon)
            addView(tvLabel)

            setOnClickListener {
                if (currentTab != tabIndex) {
                    triggerGentleHaptic()
                    currentTab = tabIndex
                    renderCurrentTab()
                }
            }
        }
    }

    private fun updateNavTabsUI() {
        rootLayout.setBackgroundColor(bgPrimaryColor())
        mainContentLayout.setBackgroundColor(bgPrimaryColor())
        headerContainer.setBackgroundColor(bgCardColor())
        tvBrandLogo.setTextColor(textPrimaryColor())
        tvBrandSlogan.setTextColor(textSecondaryColor())
        btnLangToggle.setTextColor(accentPrimaryColor())
        btnLangToggle.background = createPillDrawable(bgElevatedColor(), dp(12), currentAccentColor)
        bottomNavWrapper.setBackgroundColor(bgPrimaryColor())

        val navItems = listOf(bottomNavTasks, bottomNavHabits, bottomNavPomodoro)
        navItems.forEachIndexed { index, layout ->
            val label = layout.getChildAt(1) as? TextView
            if (index == currentTab) {
                label?.setTextColor(Color.parseColor("#0B0F19"))
                layout.background = GradientDrawable().apply {
                    cornerRadius = dp(14).toFloat()
                    setColor(accentPrimaryColor())
                }
            } else {
                label?.setTextColor(textSecondaryColor())
                layout.background = null
            }
        }

        fabAddCircular.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(accentPrimaryColor())
        }
        fabAddCircular.visibility = if (currentTab == 2) View.GONE else View.VISIBLE
    }

    private fun toggleLanguage() {
        isArabic = !isArabic
        getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("is_arabic", isArabic)
            .apply()

        applyLayoutDirection()
        tvBrandLogo.text = if (isArabic) "وَقْت" else "WAQT"
        tvBrandSlogan.text = if (isArabic) "الوقت هو أغلى مواردك، فلا تضيعه." else "Time is your most valuable resource, don't waste it."
        btnLangToggle.text = if (isArabic) "EN" else "عربي"

        (bottomNavTasks.getChildAt(1) as? TextView)?.text = if (isArabic) "المهام" else "Tasks"
        (bottomNavHabits.getChildAt(1) as? TextView)?.text = if (isArabic) "العادات" else "Habits"
        (bottomNavPomodoro.getChildAt(1) as? TextView)?.text = if (isArabic) "التركيز" else "Focus"

        renderCurrentTab()
    }

    private fun renderCurrentTab() {
        tabContentContainer.removeAllViews()
        val view = when (currentTab) {
            0 -> buildTabTasksView()
            1 -> buildTabHabitsView()
            2 -> buildTabPomodoroView()
            else -> buildTabTasksView()
        }
        tabContentContainer.addView(view)
        updateNavTabsUI()
    }

    // =========================================================================
    // 3. شاشة المهام + نظام التخطيط اليومي + تصنيفات مجالات الحياة (Sections 6, 7, 8, 12)
    // =========================================================================

    private fun buildTabTasksView(): View {
        val scrollView = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            isFillViewport = true
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(96))
        }

        val allItems = ReminderRepository.getAllItems(this)
        val tasksOnly = allItems.filter { !it.isHabit }
        val activeHabits = allItems.filter { it.isHabit && !it.isPaused }
        val todayEpoch = ReminderRepository.currentEpochDay()

        // ١. نظام التخطيط اليومي الموحد (Section 7 - قابل للطي ويربط المهام والعادات والتركيز)
        content.addView(buildDailyPlanningCard(tasksOnly, activeHabits))

        // ٢. كارت ملخص الإنجاز اليومي للمهام (Section 6.1)
        val dueTodayTasks = tasksOnly.filter { it.dueDateEpochDay <= todayEpoch }
        val doneTasksCount = dueTodayTasks.count { it.isCompletedToday }
        val totalDueCount = dueTodayTasks.size
        val completionPct = if (totalDueCount > 0) ((doneTasksCount * 100) / totalDueCount) else 0

        val summaryCard = createCalmCard().apply {
            val topRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val titleCol = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            titleCol.addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "إنجاز المهام اليومي" else "Daily Task Progress"
                setTextColor(textPrimaryColor())
                textSize = 18f
                setTypeface(typeface, Typeface.BOLD)
            })

            titleCol.addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "أنجزت $doneTasksCount من $totalDueCount مهام مستحقة اليوم" else "$doneTasksCount of $totalDueCount tasks due today completed"
                setTextColor(textSecondaryColor())
                textSize = 14f
                setPadding(0, dp(2), 0, 0)
            })

            val tvPctBadge = TextView(this@MainActivity).apply {
                text = "$completionPct%"
                setTextColor(if (completionPct == 100 && totalDueCount > 0) successColor() else accentPrimaryColor())
                textSize = 18f
                setTypeface(typeface, Typeface.BOLD)
            }

            topRow.addView(titleCol)
            topRow.addView(tvPctBadge)
            addView(topRow)

            val pBar = ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = completionPct
                progressTintList = ColorStateList.valueOf(if (completionPct == 100 && totalDueCount > 0) successColor() else accentPrimaryColor())
                progressBackgroundTintList = ColorStateList.valueOf(bgElevatedColor())
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8)).apply {
                    topMargin = dp(10)
                }
            }
            addView(pBar)
        }
        content.addView(summaryCard)

        // ٣. التذكيرات السريعة (Section 6.3: 10 دقائق • 15 دقيقة • 30 دقيقة • ساعة)
        val quickRemindersCard = createCalmCard().apply {
            addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "⏰ تذكير سريع" else "⏰ Quick Reminder"
                setTextColor(textPrimaryColor())
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
            })

            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(10), 0, 0)
            }

            val presets = listOf(
                10 to (if (isArabic) "10 دقائق" else "10m"),
                15 to (if (isArabic) "15 دقيقة" else "15m"),
                30 to (if (isArabic) "30 دقيقة" else "30m"),
                60 to (if (isArabic) "ساعة" else "1h")
            )

            presets.forEach { (mins, lbl) ->
                val chip = TextView(this@MainActivity).apply {
                    text = lbl
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(textPrimaryColor())
                    background = createPillDrawable(bgElevatedColor(), dp(12), currentAccentColor)
                    val h = dp(42)
                    layoutParams = LinearLayout.LayoutParams(0, h, 1f).apply { marginEnd = dp(6) }
                    setOnClickListener {
                        triggerGentleHaptic()
                        createQuickPresetTask(mins)
                    }
                }
                row.addView(chip)
            }
            addView(row)
        }
        content.addView(quickRemindersCard)

        // ٤. شريط البحث والترتيب الذكي (Section 6.4 & Section 7)
        val searchAndSortRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(8))
        }

        val etSearch = EditText(this).apply {
            hint = if (isArabic) "🔍 ابحث في المهام..." else "🔍 Search tasks..."
            setText(searchQuery)
            setHintTextColor(textSecondaryColor())
            setTextColor(textPrimaryColor())
            textSize = 14f
            background = createPillDrawable(bgCardColor(), dp(14), null)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(8) }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val newQ = s?.toString() ?: ""
                    if (newQ != searchQuery) {
                        searchQuery = newQ
                    }
                }
            })
        }
        searchAndSortRow.addView(etSearch)

        val btnSearchGo = TextView(this).apply {
            text = if (isArabic) "بحث" else "Filter"
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#0B0F19"))
            background = createPillDrawable(accentPrimaryColor(), dp(12), null)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)).apply { marginEnd = dp(6) }
            setPadding(dp(14), 0, dp(14), 0)
            setOnClickListener { renderCurrentTab() }
        }
        searchAndSortRow.addView(btnSearchGo)

        val btnSmartSort = TextView(this).apply {
            text = if (isArabic) "ترتيب ⇅" else "Sort ⇅"
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgCardColor(), dp(12), currentAccentColor)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46))
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener { showSmartSortDialog() }
        }
        searchAndSortRow.addView(btnSmartSort)
        content.addView(searchAndSortRow)

        // ٥. شريط تصنيفات مجالات الحياة (Section 12: العمل • الدراسة • الشخصية • الصحة • الأهداف)
        val categoryScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(0, dp(2), 0, dp(8))
        }
        val categoryRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val categories = listOf(
            Triple("all", if (isArabic) "كل المجالات" else "All Areas", "#38BDF8"),
            Triple("work", if (isArabic) "💼 العمل" else "💼 Work", "#38BDF8"),
            Triple("study", if (isArabic) "📚 الدراسة والتعلم" else "📚 Study", "#8B5CF6"),
            Triple("personal", if (isArabic) "🏠 الحياة الشخصية" else "🏠 Personal", "#FBBF24"),
            Triple("health", if (isArabic) "💪 الصحة" else "💪 Health", "#10B981"),
            Triple("goals", if (isArabic) "🎯 الأهداف" else "🎯 Goals", "#FB7185")
        )
        categories.forEach { (catKey, catLabel, _) ->
            val isSel = (selectedCategoryFilter == catKey)
            val chip = TextView(this).apply {
                text = catLabel
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (isSel) Color.parseColor("#0B0F19") else textPrimaryColor())
                background = createPillDrawable(if (isSel) accentPrimaryColor() else bgCardColor(), dp(16), null)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { marginEnd = dp(8) }
                setOnClickListener {
                    selectedCategoryFilter = catKey
                    renderCurrentTab()
                }
            }
            categoryRow.addView(chip)
        }
        categoryScroll.addView(categoryRow)
        content.addView(categoryScroll)

        // ٦. الفلاتر الأساسية (Section 6.4: الكل • اليوم • المكتملة • المتأخرة)
        val filterRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(14))
        }
        val filters = listOf(
            "all" to (if (isArabic) "الكل" else "All"),
            "today" to (if (isArabic) "اليوم" else "Today"),
            "done" to (if (isArabic) "المكتملة" else "Completed"),
            "overdue" to (if (isArabic) "المتأخرة" else "Overdue")
        )
        filters.forEach { (key, label) ->
            val isSelected = (taskFilter == key)
            val chip = TextView(this).apply {
                text = label
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setTextColor(if (isSelected) Color.parseColor("#0B0F19") else textPrimaryColor())
                background = createPillDrawable(
                    if (isSelected) (if (key == "overdue") alertColor() else accentPrimaryColor()) else bgCardColor(),
                    dp(16),
                    null
                )
                layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(6) }
                setOnClickListener {
                    taskFilter = key
                    renderCurrentTab()
                }
            }
            filterRow.addView(chip)
        }
        content.addView(filterRow)

        // ٧. تصفية وترتيب المهام
        var filteredList = tasksOnly.filter { item ->
            val matchesSearch = searchQuery.isBlank() ||
                    item.title.contains(searchQuery, ignoreCase = true) ||
                    item.description.contains(searchQuery, ignoreCase = true)
            val matchesCategory = (selectedCategoryFilter == "all") || (item.category == selectedCategoryFilter)
            val isOverdue = isTaskOverdue(item)
            val matchesStatus = when (taskFilter) {
                "today" -> !item.isCompletedToday && item.dueDateEpochDay <= todayEpoch
                "done" -> item.isCompletedToday
                "overdue" -> isOverdue
                else -> true
            }
            matchesSearch && matchesCategory && matchesStatus
        }

        filteredList = when (smartSortMode) {
            "priority" -> filteredList.sortedBy {
                when (it.priority) {
                    "high" -> 0
                    "medium" -> 1
                    else -> 2
                }
            }
            "time" -> filteredList.sortedWith(compareBy({ it.hour }, { it.minute }))
            "duration" -> filteredList.sortedBy { it.expectedMinutes }
            else -> filteredList
        }

        if (filteredList.isEmpty()) {
            content.addView(buildEmptyStateCard(
                title = if (isArabic) "لا توجد مهام مطابقة حالياً" else "No matching tasks",
                subtitle = if (isArabic) "اضغط على زر (+) بالأسفل لإضافة مهمة جديدة وتنظيم يومك." else "Tap (+) below to add a new task.",
                btnText = if (isArabic) "+ إضافة مهمة جديدة" else "+ Add New Task"
            ) {
                showAddOrEditTaskDialog(null)
            })
        } else {
            filteredList.forEach { item ->
                content.addView(buildTaskCardView(item))
            }
        }

        scrollView.addView(content)
        return scrollView
    }

    // ملخص التخطيط اليومي (Section 7)
    private fun buildDailyPlanningCard(tasks: List<ReminderItem>, habits: List<ReminderItem>): View {
        val prefs = getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
        val dailyGoalMins = prefs.getInt(ReminderRepository.KEY_DAILY_FOCUS_GOAL_MINS, 120).coerceAtLeast(15)
        val todayFocusMins = ReminderRepository.getTodayFocusMinutes(this)

        val importantToday = tasks.count { !it.isCompletedToday && it.priority == "high" }
        val habitsDue = habits.count { !it.isCompletedToday }
        val nextUpcoming = (tasks + habits).filter { !it.isCompletedToday }
            .minWithOrNull(compareBy({ it.hour }, { it.minute }))

        val card = createCalmCard().apply {
            val headerRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            headerRow.addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "📋 خطة اليوم المتكاملة" else "📋 Daily Plan Overview"
                setTextColor(accentPrimaryColor())
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })

            val btnTogglePlan = TextView(this@MainActivity).apply {
                text = if (isDailyPlanExpanded) (if (isArabic) "إخفاء ▴" else "Hide ▴") else (if (isArabic) "عرض ▾" else "Show ▾")
                setTextColor(textSecondaryColor())
                textSize = 12f
                setPadding(dp(8), dp(4), dp(8), dp(4))
                setOnClickListener {
                    isDailyPlanExpanded = !isDailyPlanExpanded
                    prefs.edit().putBoolean(ReminderRepository.KEY_HIDE_DAILY_PLAN, !isDailyPlanExpanded).apply()
                    renderCurrentTab()
                }
            }
            headerRow.addView(btnTogglePlan)
            addView(headerRow)

            if (isDailyPlanExpanded) {
                val metricsRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, dp(10), 0, dp(6))
                }

                metricsRow.addView(createMiniMetricBox(
                    if (isArabic) "مهام عاجلة" else "High Tasks",
                    "$importantToday",
                    "#FB7185"
                ))
                metricsRow.addView(createMiniMetricBox(
                    if (isArabic) "عادات متبقية" else "Habits Due",
                    "$habitsDue",
                    "#8B5CF6"
                ))
                metricsRow.addView(createMiniMetricBox(
                    if (isArabic) "هدف التركيز" else "Focus Goal",
                    "${todayFocusMins}/${dailyGoalMins}m",
                    currentAccentColor
                ))
                addView(metricsRow)

                if (nextUpcoming != null) {
                    val c = Calendar.getInstance().apply {
                        set(Calendar.HOUR_OF_DAY, nextUpcoming.hour)
                        set(Calendar.MINUTE, nextUpcoming.minute)
                    }
                    val tStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(c.time)
                    addView(TextView(this@MainActivity).apply {
                        text = if (isArabic) "⏰ الموعد القادم: «${nextUpcoming.title}» الساعة $tStr"
                        else "⏰ Next up: \"${nextUpcoming.title}\" at $tStr"
                        setTextColor(textSecondaryColor())
                        textSize = 13f
                        setPadding(0, dp(4), 0, 0)
                    })
                }
            }
        }
        return card
    }

    private fun createMiniMetricBox(label: String, value: String, colorHex: String): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(6)
            }
            addView(TextView(this@MainActivity).apply {
                text = value
                setTextColor(Color.parseColor(colorHex))
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
            })
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(textSecondaryColor())
                textSize = 11f
            })
        }
    }

    private fun isTaskOverdue(item: ReminderItem): Boolean {
        if (item.isCompletedToday) return false
        val today = ReminderRepository.currentEpochDay()
        if (item.dueDateEpochDay in 1 until today) return true
        val now = Calendar.getInstance()
        val nowMins = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val itemMins = item.hour * 60 + item.minute
        return (item.dueDateEpochDay <= today && itemMins < nowMins)
    }

    // تصميم بطاقة المهمة (Section 6.2, Section 6.7, Section 8)
    private fun buildTaskCardView(item: ReminderItem): View {
        val isLate = isTaskOverdue(item)
        val card = createCalmCard().apply {
            // الترتيب المطلوب: 1. عنوان المهمة (الأوضح 18sp) • 2. وقت الاستحقاق • 3. الأولوية والتصنيف • 4. حالة الإنجاز والوقت الفعلي
            val mainRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            // زر الإتمام (48dp منطقة لمس مريحة)
            val checkFrame = FrameLayout(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(10) }
                val circle = TextView(this@MainActivity).apply {
                    text = if (item.isCompletedToday) "✓" else ""
                    textSize = 15f
                    gravity = Gravity.CENTER
                    setTextColor(Color.parseColor("#0B0F19"))
                    layoutParams = FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(if (item.isCompletedToday) successColor() else Color.TRANSPARENT)
                        setStroke(dp(2), if (item.isCompletedToday) successColor() else accentPrimaryColor())
                    }
                }
                addView(circle)
                setOnClickListener {
                    triggerGentleHaptic()
                    ReminderRepository.markCompleted(this@MainActivity, item.id)
                    checkAndNotifyAchievements()
                    renderCurrentTab()
                }
            }
            mainRow.addView(checkFrame)

            val infoCol = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            // 1. عنوان المهمة (18sp)
            infoCol.addView(TextView(this@MainActivity).apply {
                text = item.title
                setTextColor(if (item.isCompletedToday) textSecondaryColor() else textPrimaryColor())
                textSize = 18f
                setTypeface(typeface, Typeface.BOLD)
                if (item.isCompletedToday) {
                    paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                }
            })

            if (item.description.isNotBlank()) {
                infoCol.addView(TextView(this@MainActivity).apply {
                    text = item.description
                    setTextColor(textSecondaryColor())
                    textSize = 13f
                    maxLines = 2
                })
            }

            // 2. وقت الاستحقاق + 3. الأولوية والتصنيف + 4. حالة الإنجاز
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, item.hour)
                set(Calendar.MINUTE, item.minute)
            }
            val timeFormatted = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(cal.time)
            val priorityLabel = when (item.priority) {
                "high" -> if (isArabic) "أولوية عالية" else "High"
                "medium" -> if (isArabic) "متوسطة" else "Medium"
                else -> if (isArabic) "منخفضة" else "Low"
            }
            val priorityColor = when (item.priority) {
                "high" -> "#FB7185"
                "medium" -> "#FBBF24"
                else -> "#10B981"
            }
            val catLabel = getCategoryDisplayName(item.category)
            val statusLabel = when {
                item.isCompletedToday -> if (isArabic) "✓ مكتملة" else "✓ Completed"
                isLate -> if (isArabic) "⚠️ متأخرة" else "⚠️ Overdue"
                else -> if (isArabic) "قيد التنفيذ" else "Pending"
            }

            val metaRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, 0)
            }

            metaRow.addView(TextView(this@MainActivity).apply {
                text = "⏰ $timeFormatted  •  "
                setTextColor(if (isLate) alertColor() else accentPrimaryColor())
                textSize = 13f
            })

            metaRow.addView(TextView(this@MainActivity).apply {
                text = "$priorityLabel  •  $catLabel  •  $statusLabel"
                setTextColor(Color.parseColor(priorityColor))
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
            })
            infoCol.addView(metaRow)

            // عرض الوقت المتوقع مقابل الفعلي وجلسات التركيز المرتبطة (Section 8)
            infoCol.addView(TextView(this@MainActivity).apply {
                text = if (isArabic) {
                    "⏱️ المتوقع: ${item.expectedMinutes} د  |  الفعلي المسجل: ${item.actualFocusedMinutes} د (${item.focusSessionsCount} جلسات)"
                } else {
                    "⏱️ Est: ${item.expectedMinutes}m  |  Actual: ${item.actualFocusedMinutes}m (${item.focusSessionsCount} sessions)"
                }
                setTextColor(textSecondaryColor())
                textSize = 12f
                setPadding(0, dp(4), 0, 0)
            })

            mainRow.addView(infoCol)
            addView(mainRow)

            // شريط الإجراءات السريعة للمهمة (Section 6.7: تركيز • تأجيل • تعديل • تكرار • حذف)
            val actionsRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
                setPadding(0, dp(10), 0, 0)
            }

            // بدء جلسة تركيز مرتبطة بهذه المهمة مباشرة
            actionsRow.addView(createTaskQuickActionChip(if (isArabic) "🍅 تركيز" else "🍅 Focus", currentAccentColor) {
                selectedFocusTaskId = item.id
                setPomodoroDuration(item.expectedMinutes.coerceIn(5, 180))
                currentTab = 2
                renderCurrentTab()
            })

            // تأجيل المهمة
            actionsRow.addView(createTaskQuickActionChip(if (isArabic) "💤 تأجيل" else "💤 Snooze", "#94A3B8") {
                showSnoozeOptionsDialog(item)
            })

            // تعديل المهمة
            actionsRow.addView(createTaskQuickActionChip(if (isArabic) "✏️ تعديل" else "✏️ Edit", "#94A3B8") {
                showAddOrEditTaskDialog(item)
            })

            // تكرار المهمة
            actionsRow.addView(createTaskQuickActionChip(if (isArabic) "📋 نسخ" else "📋 Copy", "#94A3B8") {
                val copyItem = item.copy(
                    id = UUID.randomUUID().toString(),
                    title = "${item.title} (2)",
                    isCompletedToday = false,
                    lastCompletedEpochDay = -1L
                )
                ReminderRepository.addOrUpdateItem(this@MainActivity, copyItem)
                AlarmScheduler.scheduleNextOccurrence(this@MainActivity, copyItem)
                renderCurrentTab()
            })

            // حذف المهمة مع نافذة تأكيد لمنع فقدان البيانات
            actionsRow.addView(createTaskQuickActionChip(if (isArabic) "🗑️" else "🗑️", "#FB7185") {
                confirmDeleteItem(item)
            })

            addView(actionsRow)
        }
        return card
    }

    private fun createTaskQuickActionChip(label: String, textColorHex: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            textSize = 12f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor(textColorHex))
            background = createPillDrawable(bgElevatedColor(), dp(10), null)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)).apply {
                marginStart = dp(6)
            }
            setOnClickListener {
                triggerGentleHaptic()
                onClick()
            }
        }
    }

    private fun showSnoozeOptionsDialog(item: ReminderItem) {
        val options = if (isArabic) arrayOf("بعد 10 دقائق", "بعد ساعة", "تأجيل للغد", "تحديد وقت آخر")
        else arrayOf("In 10 minutes", "In 1 hour", "Tomorrow", "Pick another time")

        AlertDialog.Builder(this)
            .setTitle(if (isArabic) "تأجيل التذكير: ${item.title}" else "Snooze: ${item.title}")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        AlarmScheduler.scheduleSnooze(this, item, 10)
                        Toast.makeText(this, if (isArabic) "تم التأجيل 10 دقائق" else "Snoozed 10m", Toast.LENGTH_SHORT).show()
                    }
                    1 -> {
                        AlarmScheduler.scheduleSnooze(this, item, 60)
                        Toast.makeText(this, if (isArabic) "تم التأجيل ساعة" else "Snoozed 1h", Toast.LENGTH_SHORT).show()
                    }
                    2 -> {
                        val updated = item.copy(dueDateEpochDay = ReminderRepository.currentEpochDay() + 1)
                        ReminderRepository.addOrUpdateItem(this, updated)
                        AlarmScheduler.scheduleNextOccurrence(this, updated, forceTomorrow = true)
                        renderCurrentTab()
                    }
                    3 -> {
                        TimePickerDialog(this, { _, h, m ->
                            val updated = item.copy(hour = h, minute = m)
                            ReminderRepository.addOrUpdateItem(this, updated)
                            AlarmScheduler.scheduleNextOccurrence(this, updated)
                            renderCurrentTab()
                        }, item.hour, item.minute, false).show()
                    }
                }
            }
            .show()
    }

    private fun confirmDeleteItem(item: ReminderItem) {
        AlertDialog.Builder(this)
            .setTitle(if (isArabic) "تأكيد الحذف" else "Confirm Delete")
            .setMessage(if (isArabic) "هل تريد حذف «${item.title}»؟ يمكنك التراجع فوراً بعد الحذف." else "Delete \"${item.title}\"?")
            .setPositiveButton(if (isArabic) "حذف" else "Delete") { _, _ ->
                AlarmScheduler.cancelAlarm(this, item.id)
                ReminderRepository.deleteItem(this, item.id)
                renderCurrentTab()
                Toast.makeText(this, if (isArabic) "تم الحذف بنجاح" else "Deleted", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(if (isArabic) "إلغاء" else "Cancel", null)
            .show()
    }

    private fun showSmartSortDialog() {
        val options = if (isArabic) arrayOf(
            "الترتيب الافتراضي",
            "حسب الأولوية (العاجل أولاً)",
            "حسب موعد الاستحقاق (الأقرب أولاً)",
            "حسب المدة المتوقعة (الأقصر أولاً - طاقة خفيفة)"
        ) else arrayOf(
            "Default Order",
            "By Priority (High first)",
            "By Due Time (Earliest first)",
            "By Duration (Shortest first)"
        )

        AlertDialog.Builder(this)
            .setTitle(if (isArabic) "ترتيب عرض المهام" else "Sort Tasks View")
            .setItems(options) { _, which ->
                smartSortMode = when (which) {
                    1 -> "priority"
                    2 -> "time"
                    3 -> "duration"
                    else -> "none"
                }
                renderCurrentTab()
            }
            .show()
    }

    private fun createQuickPresetTask(minutes: Int) {
        val now = Calendar.getInstance().apply { add(Calendar.MINUTE, minutes) }
        val title = if (isArabic) "تذكير سريع ($minutes دقيقة)" else "Quick Reminder ($minutes mins)"
        val item = ReminderItem(
            id = UUID.randomUUID().toString(),
            title = title,
            isHabit = false,
            hour = now.get(Calendar.HOUR_OF_DAY),
            minute = now.get(Calendar.MINUTE),
            priority = "high",
            dueDateEpochDay = ReminderRepository.currentEpochDay(),
            expectedMinutes = minutes
        )
        ReminderRepository.addOrUpdateItem(this, item)
        AlarmScheduler.scheduleExactDelayMillis(this, item, minutes * 60 * 1000L)
        Toast.makeText(this, if (isArabic) "⏰ تم ضبط $title" else "⏰ Scheduled $title", Toast.LENGTH_SHORT).show()
        renderCurrentTab()
    }

    // =========================================================================
    // 4. شاشة العادات (الحالة الفارغة بالاقتراحات + الأهداف الرقمية + التقدم الأسبوعي + الإيقاف المؤقت - Section 5)
    // =========================================================================

    private fun buildTabHabitsView(): View {
        val scrollView = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            isFillViewport = true
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(96))
        }

        val habits = ReminderRepository.getAllItems(this).filter { it.isHabit }

        // ١. حالة عدم وجود عادات أو قسم الاقتراحات الجاهزة (Section 5.1)
        if (habits.isEmpty()) {
            val emptyCard = createCalmCard().apply {
                addView(TextView(this@MainActivity).apply {
                    text = if (isArabic) "🌱 ابدأ بأول عادة ليك." else "🌱 Start your first habit."
                    setTextColor(textPrimaryColor())
                    textSize = 20f
                    setTypeface(typeface, Typeface.BOLD)
                })
                addView(TextView(this@MainActivity).apply {
                    text = if (isArabic) "العادات الصغيرة بتصنع تغييرات كبيرة مع الوقت. اختر اقتراحاً لتعديله وحفظه أو أضف عادتك:"
                    else "Small habits create big changes over time. Pick a suggestion to customize or add your own:"
                    setTextColor(textSecondaryColor())
                    textSize = 14f
                    setPadding(0, dp(4), 0, dp(12))
                })

                addSuggestedHabitsChips(this)

                val btnNew = Button(this@MainActivity).apply {
                    text = if (isArabic) "+ إضافة عادة جديدة" else "+ Add New Habit"
                    isAllCaps = false
                    textSize = 15f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.parseColor("#0B0F19"))
                    backgroundTintList = ColorStateList.valueOf(accentPrimaryColor())
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)).apply {
                        topMargin = dp(12)
                    }
                    setOnClickListener { showAddOrEditHabitDialog(null) }
                }
                addView(btnNew)
            }
            content.addView(emptyCard)
        } else {
            // شريط اقتراحات سريع في الأعلى لإضافة عادات جاهزة
            val suggestCard = createCalmCard().apply {
                addView(TextView(this@MainActivity).apply {
                    text = if (isArabic) "✨ اقتراحات عادات جاهزة (اضغط للتخصيص والإضافة):" else "✨ Quick Habit Suggestions:"
                    setTextColor(textSecondaryColor())
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    setPadding(0, 0, 0, dp(8))
                })
                addSuggestedHabitsChips(this)
            }
            content.addView(suggestCard)

            habits.forEach { habit ->
                content.addView(buildHabitCardView(habit))
            }
        }

        scrollView.addView(content)
        return scrollView
    }

    private fun addSuggestedHabitsChips(parent: LinearLayout) {
        val suggestions = listOf(
            Triple(if (isArabic) "📖 قراءة 10 صفحات" else "📖 Read 10 pages", 10, if (isArabic) "صفحة" else "pages"),
            Triple(if (isArabic) "💧 شرب 8 أكواب مياه" else "💧 Drink 8 cups water", 8, if (isArabic) "أكواب" else "cups"),
            Triple(if (isArabic) "🏃 ممارسة الرياضة 30 د" else "🏃 Exercise 30m", 30, if (isArabic) "دقيقة" else "mins"),
            Triple(if (isArabic) "🧘 التأمل لمدة 5 دقائق" else "🧘 Meditate 5m", 5, if (isArabic) "دقائق" else "mins"),
            Triple(if (isArabic) "💻 التعلم لمدة 30 دقيقة" else "💻 Learn 30m", 30, if (isArabic) "دقيقة" else "mins")
        )

        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        suggestions.forEach { (title, target, unit) ->
            val chip = TextView(this).apply {
                text = title
                textSize = 13f
                setTextColor(textPrimaryColor())
                background = createPillDrawable(bgElevatedColor(), dp(14), "#8B5CF6")
                setPadding(dp(12), dp(8), dp(12), dp(8))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply {
                    marginEnd = dp(8)
                }
                setOnClickListener {
                    // فتح نافذة التعديل قبل الحفظ كما هو مطلوب (عدم الإضافة تلقائياً دون موافقة)
                    val template = ReminderItem(
                        id = "",
                        title = title,
                        isHabit = true,
                        hour = 9,
                        minute = 0,
                        targetValue = target,
                        targetUnit = unit,
                        recurrence = "daily",
                        category = "health"
                    )
                    showAddOrEditHabitDialog(template)
                }
            }
            row.addView(chip)
        }
        scroll.addView(row)
        parent.addView(scroll)
    }

    // تصميم بطاقة العادة (Section 5.2, 5.3, 5.4, 5.5, 5.6)
    private fun buildHabitCardView(habit: ReminderItem): View {
        val card = createCalmCard().apply {
            val topRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            // شارة السلسلة الحالية وأطول سلسلة
            val streakText = if (isArabic) {
                "🔥 ${habit.streakCount} يوم متتالي (الأطول: ${habit.longestStreak})"
            } else {
                "🔥 ${habit.streakCount}d streak (Best: ${habit.longestStreak})"
            }

            topRow.addView(TextView(this@MainActivity).apply {
                text = streakText
                setTextColor(Color.parseColor("#8B5CF6"))
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })

            if (habit.isPaused) {
                topRow.addView(TextView(this@MainActivity).apply {
                    text = if (isArabic) "⏸ متوقفة مؤقتاً" else "⏸ Paused"
                    setTextColor(Color.parseColor("#FBBF24"))
                    textSize = 11f
                    setTypeface(typeface, Typeface.BOLD)
                    setPadding(dp(6), 0, dp(6), 0)
                })
            }

            // أزرار إيقاف مؤقت • تعديل • حذف
            val btnPause = TextView(this@MainActivity).apply {
                text = if (habit.isPaused) "▶" else "⏸"
                textSize = 14f
                setTextColor(textSecondaryColor())
                setPadding(dp(8), dp(4), dp(8), dp(4))
                setOnClickListener {
                    ReminderRepository.toggleHabitPause(this@MainActivity, habit.id)
                    renderCurrentTab()
                }
            }
            topRow.addView(btnPause)

            val btnEdit = TextView(this@MainActivity).apply {
                text = "✏️"
                textSize = 13f
                setPadding(dp(8), dp(4), dp(8), dp(4))
                setOnClickListener { showAddOrEditHabitDialog(habit) }
            }
            topRow.addView(btnEdit)

            val btnDel = TextView(this@MainActivity).apply {
                text = "🗑️"
                textSize = 13f
                setPadding(dp(8), dp(4), dp(4), dp(4))
                setOnClickListener { confirmDeleteItem(habit) }
            }
            topRow.addView(btnDel)
            addView(topRow)

            // الصف الرئيسي: الاسم + التكرار والهدف الرقمي + زر الإتمام الواضح (48dp)
            val mainRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }

            val infoCol = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            infoCol.addView(TextView(this@MainActivity).apply {
                text = habit.title
                setTextColor(if (habit.isPaused) textSecondaryColor() else textPrimaryColor())
                textSize = 18f
                setTypeface(typeface, Typeface.BOLD)
            })

            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, habit.hour)
                set(Calendar.MINUTE, habit.minute)
            }
            val timeStr = if (habit.hasReminder) "⏰ " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(cal.time) else (if (isArabic) "بدون تذكير" else "No reminder")
            val recLabel = when (habit.recurrence) {
                "weekly" -> if (isArabic) "أيام محددة" else "Custom days"
                else -> if (isArabic) "يوميًا" else "Daily"
            }
            val targetStr = if (habit.targetValue > 1 || habit.targetUnit.isNotBlank()) {
                "${habit.currentProgressToday} / ${habit.targetValue} ${habit.targetUnit}"
            } else {
                if (habit.isCompletedToday) (if (isArabic) "مكتملة اليوم" else "Done today") else (if (isArabic) "غير مكتملة" else "Not done")
            }

            infoCol.addView(TextView(this@MainActivity).apply {
                text = "$recLabel  •  $timeStr  •  🎯 $targetStr"
                setTextColor(textSecondaryColor())
                textSize = 13f
                setPadding(0, dp(2), 0, 0)
            })
            mainRow.addView(infoCol)

            // زر إتمام واضح ومريح (48dp)
            val btnCompleteHabit = TextView(this@MainActivity).apply {
                text = when {
                    habit.isCompletedToday -> if (isArabic) "✓ تمت" else "✓ Done"
                    habit.targetValue > 1 -> "+1"
                    else -> if (isArabic) "إتمام" else "Complete"
                }
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (habit.isCompletedToday) Color.parseColor("#0B0F19") else Color.parseColor("#0B0F19"))
                background = createPillDrawable(if (habit.isCompletedToday) successColor() else accentPrimaryColor(), dp(14), null)
                setPadding(dp(14), 0, dp(14), 0)
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44))
                setOnClickListener {
                    if (!habit.isPaused) {
                        triggerGentleHaptic()
                        ReminderRepository.incrementHabitStep(this@MainActivity, habit.id)
                        checkAndNotifyAchievements()
                        renderCurrentTab()
                    }
                }
            }
            mainRow.addView(btnCompleteHabit)
            addView(mainRow)

            // ٤. مؤشر التقدم الأسبوعي ونسبة الالتزام (Section 5.4)
            val todayEpoch = ReminderRepository.currentEpochDay()
            val completedHistory = habit.completedDaysHistoryCsv.split(",").mapNotNull { it.toLongOrNull() }.toSet()
            var completedInLast7 = 0

            val weekStrip = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(4))
            }

            val dayNamesAr = listOf("ح", "ن", "ث", "ر", "خ", "ج", "س")
            val dayNamesEn = listOf("S", "M", "T", "W", "T", "F", "S")

            for (offset in 6 downTo 0) {
                val dayEpoch = todayEpoch - offset
                val isDayDone = completedHistory.contains(dayEpoch) || (offset == 0 && habit.isCompletedToday)
                if (isDayDone) completedInLast7++

                val calDay = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) }
                val dowIdx = (calDay.get(Calendar.DAY_OF_WEEK) - 1).coerceIn(0, 6)
                val dLabel = if (isArabic) dayNamesAr[dowIdx] else dayNamesEn[dowIdx]

                val dayCell = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }

                val circle = TextView(this@MainActivity).apply {
                    text = if (isDayDone) "✓" else dLabel
                    textSize = 11f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (isDayDone) Color.parseColor("#0B0F19") else textSecondaryColor())
                    val s = dp(30)
                    layoutParams = LinearLayout.LayoutParams(s, s)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(if (isDayDone) successColor() else bgElevatedColor())
                        if (offset == 0 && !isDayDone) {
                            setStroke(dp(2), accentPrimaryColor())
                        }
                    }
                }
                dayCell.addView(circle)
                weekStrip.addView(dayCell)
            }
            addView(weekStrip)

            val adherencePct = ((completedInLast7 * 100) / 7)
            addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "نسبة الالتزام خلال آخر 7 أيام: $adherencePct% ($completedInLast7 من 7 أيام)"
                else "Weekly adherence: $adherencePct% ($completedInLast7 of 7 days)"
                setTextColor(textSecondaryColor())
                textSize = 12f
                setPadding(0, dp(4), 0, 0)
            })
        }
        return card
    }

    // =========================================================================
    // 5. شاشة التركيز POMODORO + ربط المهمة + الصوت المحيطي ومستوى الصوت (Section 4 & Section 10)
    // =========================================================================

    private fun buildTabPomodoroView(): View {
        val scrollView = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            isFillViewport = true
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(12), dp(16), dp(40))
        }

        // ١. اختيار المهمة المرتبطة بالجلسة (Section 4.3 & Section 8)
        val tasksList = ReminderRepository.getAllItems(this).filter { !it.isHabit && !it.isCompletedToday }
        val linkedTask = tasksList.firstOrNull { it.id == selectedFocusTaskId }

        val taskSelectorCard = createCalmCard().apply {
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val col = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            col.addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "🎯 المهمة المرتبطة بجلسة التركيز:" else "🎯 Linked Task for Focus:"
                setTextColor(textSecondaryColor())
                textSize = 12f
            })

            col.addView(TextView(this@MainActivity).apply {
                text = linkedTask?.title ?: (if (isArabic) "جلسة تركيز عامة (اضغط لاختيار مهمة)" else "General Focus Session (Tap to link task)")
                setTextColor(textPrimaryColor())
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
            })
            row.addView(col)

            val btnChooseTask = TextView(this@MainActivity).apply {
                text = if (isArabic) "تغيير ▾" else "Select ▾"
                setTextColor(accentPrimaryColor())
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(dp(10), dp(6), dp(10), dp(6))
                background = createPillDrawable(bgElevatedColor(), dp(10), null)
            }
            row.addView(btnChooseTask)
            addView(row)

            setOnClickListener {
                showSelectFocusTaskDialog(tasksList)
            }
        }
        content.addView(taskSelectorCard)

        // ٢. تبديل نوع الجلسة: تركيز / استراحة (Section 4.1 & 4.2)
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, dp(8))
        }

        val prefs = getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
        val defaultFocus = prefs.getInt(ReminderRepository.KEY_DEFAULT_FOCUS_MINS, 25)
        val defaultBreak = prefs.getInt(ReminderRepository.KEY_DEFAULT_BREAK_MINS, 5)

        val btnFocusMode = TextView(this).apply {
            text = if (isArabic) "🍅 جلسة تركيز" else "🍅 Focus Mode"
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (!isBreakSession) Color.parseColor("#0B0F19") else textPrimaryColor())
            background = createPillDrawable(if (!isBreakSession) accentPrimaryColor() else bgCardColor(), dp(16), null)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)).apply { marginEnd = dp(8) }
            setOnClickListener {
                if (isBreakSession) {
                    isBreakSession = false
                    setPomodoroDuration(defaultFocus)
                }
            }
        }

        val btnBreakMode = TextView(this).apply {
            text = if (isArabic) "☕ فترة راحة ($defaultBreak د)" else "☕ Short Break (${defaultBreak}m)"
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (isBreakSession) Color.parseColor("#0B0F19") else textPrimaryColor())
            background = createPillDrawable(if (isBreakSession) successColor() else bgCardColor(), dp(16), null)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38))
            setOnClickListener {
                if (!isBreakSession) {
                    isBreakSession = true
                    setPomodoroDuration(defaultBreak)
                }
            }
        }

        modeRow.addView(btnFocusMode)
        modeRow.addView(btnBreakMode)
        content.addView(modeRow)

        // ٣. المؤقت الدائري المتوازن (200dp - Section 4.1)
        val ringView = CircularTimerRingView(this).apply {
            val size = dp(200)
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                topMargin = dp(4)
                bottomMargin = dp(10)
            }
            updateTimerDisplay(pomodoroRemainingMillis, pomodoroTotalMillis)
        }
        circularTimerView = ringView
        content.addView(ringView)

        // ٤. خيارات مدة التركيز (25 د • 50 د • مخصص - Section 4.2)
        if (!isBreakSession) {
            val presetsRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                setPadding(0, dp(2), 0, dp(12))
            }

            val options = listOf(
                25 to (if (isArabic) "25 دقيقة" else "25m"),
                50 to (if (isArabic) "50 دقيقة" else "50m"),
                -1 to (if (isArabic) "مخصص" else "Custom")
            )

            options.forEach { (mins, label) ->
                val isSelected = (mins == selectedPomodoroMinutes) || (mins == -1 && selectedPomodoroMinutes != 25 && selectedPomodoroMinutes != 50)
                val pill = TextView(this).apply {
                    text = if (mins == -1 && isSelected) "${selectedPomodoroMinutes}m" else label
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (isSelected) Color.parseColor("#0B0F19") else textPrimaryColor())
                    background = createPillDrawable(if (isSelected) accentPrimaryColor() else bgCardColor(), dp(18), currentAccentColor)
                    setPadding(dp(16), dp(8), dp(16), dp(8))
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { marginEnd = dp(8) }
                    setOnClickListener {
                        triggerGentleHaptic()
                        if (mins == -1) showCustomMinutesDialog()
                        else setPomodoroDuration(mins)
                    }
                }
                presetsRow.addView(pill)
            }
            content.addView(presetsRow)
        }

        // ٥. أزرار التحكم بالجلسة + النافذة العائمة (Section 4.1, 4.3, Section 10)
        val controlsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(14))
        }

        val btnStartPause = TextView(this).apply {
            text = if (isPomodoroRunning) (if (isArabic) "⏸ إيقاف مؤقت" else "⏸ Pause") else (if (isArabic) "▶ بدء الجلسة" else "▶ Start Session")
            textSize = 15f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#0B0F19"))
            background = createPillDrawable(if (isBreakSession) successColor() else accentPrimaryColor(), dp(22), null)
            layoutParams = LinearLayout.LayoutParams(dp(148), dp(48)).apply { marginEnd = dp(8) }
            setOnClickListener {
                triggerGentleHaptic()
                toggleInAppPomodoro()
            }
        }
        tvPomodoroStartBtn = btnStartPause
        controlsRow.addView(btnStartPause)

        val btnFinishEarly = TextView(this).apply {
            text = if (isArabic) "⏹ إنهاء" else "⏹ Finish"
            textSize = 14f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgCardColor(), dp(22), "#FB7185")
            layoutParams = LinearLayout.LayoutParams(dp(90), dp(48)).apply { marginEnd = dp(8) }
            setOnClickListener {
                triggerGentleHaptic()
                finishOrCancelFocusSession()
            }
        }
        controlsRow.addView(btnFinishEarly)

        val btnFloatWindow = TextView(this).apply {
            text = if (isArabic) "🪟 عائم" else "🪟 Float"
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accentPrimaryColor())
            background = createPillDrawable(bgCardColor(), dp(22), currentAccentColor)
            layoutParams = LinearLayout.LayoutParams(dp(86), dp(48))
            setOnClickListener {
                triggerGentleHaptic()
                launchFloatingFocusWindow(linkedTask)
            }
        }
        controlsRow.addView(btnFloatWindow)
        content.addView(controlsRow)

        // ٦. الصوت المحيطي مع زر التجربة والتحكم بمستوى الصوت (Section 4.4)
        val soundCard = createCalmCard().apply {
            addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "🎧 الصوت المحيطي ومستوى الصوت" else "🎧 Ambient Sound & Volume"
                setTextColor(textPrimaryColor())
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, 0, 0, dp(8))
            })

            val soundOptions = if (isArabic) listOf(
                "🔇 بدون صوت",
                "🌧️ المطر",
                "🌊 أمواج البحر",
                "🌲 الغابة والطبيعة",
                "⚡ الضوضاء البيضاء",
                "🌀 صوت المروحة",
                "🎹 الموسيقى الهادئة"
            ) else listOf(
                "🔇 Silent (No Sound)",
                "🌧️ Rain",
                "🌊 Ocean Waves",
                "🌲 Forest & Nature",
                "⚡ White Noise",
                "🌀 Fan Hum",
                "🎹 Calm Ambient Drone"
            )

            val spinnerRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val spinner = Spinner(this@MainActivity).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, soundOptions)
                setSelection(selectedAmbientIndex)
                background = createPillDrawable(bgElevatedColor(), dp(12), null)
                setPadding(dp(10), dp(6), dp(10), dp(6))
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) }
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                        (view as? TextView)?.setTextColor(textPrimaryColor())
                        selectedAmbientIndex = position
                        prefs.edit().putInt(ReminderRepository.KEY_DEFAULT_SOUND_INDEX, position).apply()
                        if (position == 0) {
                            stopAmbientSound()
                        } else if (isAmbientPlaying) {
                            startRichAmbientSound(position)
                        }
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }
            spinnerRow.addView(spinner)

            val btnTestPlay = TextView(this@MainActivity).apply {
                text = if (isAmbientPlaying) (if (isArabic) "⏹ إيقاف" else "⏹ Stop") else (if (isArabic) "🔊 تشغيل" else "🔊 Play")
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#0B0F19"))
                background = createPillDrawable(if (isAmbientPlaying) alertColor() else accentPrimaryColor(), dp(12), null)
                layoutParams = LinearLayout.LayoutParams(dp(86), dp(44))
                setOnClickListener {
                    if (isAmbientPlaying) {
                        stopAmbientSound()
                        text = if (isArabic) "🔊 تشغيل" else "🔊 Play"
                        background = createPillDrawable(accentPrimaryColor(), dp(12), null)
                    } else {
                        if (selectedAmbientIndex == 0) {
                            selectedAmbientIndex = 1
                            spinner.setSelection(1)
                        }
                        startRichAmbientSound(selectedAmbientIndex)
                        text = if (isArabic) "⏹ إيقاف" else "⏹ Stop"
                        background = createPillDrawable(alertColor(), dp(12), null)
                    }
                }
            }
            spinnerRow.addView(btnTestPlay)
            addView(spinnerRow)

            // شريط التحكم في مستوى الصوت
            val volRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(10), 0, 0)
            }
            volRow.addView(TextView(this@MainActivity).apply {
                text = "🔉"
                textSize = 14f
                setPadding(0, 0, dp(6), 0)
            })
            val volSeek = SeekBar(this@MainActivity).apply {
                max = 100
                progress = (ambientVolume * 100).toInt()
                progressTintList = ColorStateList.valueOf(accentPrimaryColor())
                thumbTintList = ColorStateList.valueOf(accentPrimaryColor())
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, prog: Int, fromUser: Boolean) {
                        ambientVolume = (prog / 100f).coerceIn(0.05f, 1.0f)
                        ambientAudioTrack?.setVolume(ambientVolume)
                        prefs.edit().putInt(ReminderRepository.KEY_SOUND_VOLUME, prog).apply()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            volRow.addView(volSeek)
            addView(volRow)
        }
        content.addView(soundCard)

        // ٧. ملخص إحصائيات التركيز اليومي (Section 4.5 - قابل للطي)
        val totalFocusMins = ReminderRepository.getTodayFocusMinutes(this)
        val completedSessions = ReminderRepository.getTodayFocusSessions(this)
        val dailyGoalMins = prefs.getInt(ReminderRepository.KEY_DAILY_FOCUS_GOAL_MINS, 120).coerceAtLeast(25)
        val remainingMins = (dailyGoalMins - totalFocusMins).coerceAtLeast(0)
        val remainingSessions = (remainingMins + 24) / 25
        val goalPct = ((totalFocusMins * 100) / dailyGoalMins).coerceAtMost(100)

        val statsCard = createCalmCard().apply {
            val headerRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            headerRow.addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "📊 ملخص التركيز اليومي ($goalPct%)" else "📊 Today's Focus Summary ($goalPct%)"
                setTextColor(textPrimaryColor())
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })

            val btnCollapse = TextView(this@MainActivity).apply {
                text = if (isFocusStatsExpanded) "▴" else "▾"
                setTextColor(textSecondaryColor())
                textSize = 16f
                setPadding(dp(8), 0, dp(8), 0)
                setOnClickListener {
                    isFocusStatsExpanded = !isFocusStatsExpanded
                    renderCurrentTab()
                }
            }
            headerRow.addView(btnCollapse)
            addView(headerRow)

            if (isFocusStatsExpanded) {
                addView(TextView(this@MainActivity).apply {
                    text = if (isArabic) {
                        "• إجمالي وقت التركيز اليوم: $totalFocusMins دقيقة\n• الجلسات المكتملة: $completedSessions جلسات\n• المتبقي لتحقيق الهدف اليومي ($dailyGoalMins د): $remainingMins دقيقة (~$remainingSessions جلسة)"
                    } else {
                        "• Total Focus Today: $totalFocusMins mins\n• Completed Sessions: $completedSessions\n• Remaining for Daily Goal (${dailyGoalMins}m): $remainingMins mins (~$remainingSessions sessions)"
                    }
                    setTextColor(textSecondaryColor())
                    textSize = 13f
                    setPadding(0, dp(8), 0, dp(8))
                })

                val goalBar = ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = dailyGoalMins
                    progress = totalFocusMins.coerceAtMost(dailyGoalMins)
                    progressTintList = ColorStateList.valueOf(accentPrimaryColor())
                    progressBackgroundTintList = ColorStateList.valueOf(bgElevatedColor())
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8))
                }
                addView(goalBar)
            }
        }
        content.addView(statsCard)

        scrollView.addView(content)
        return scrollView
    }

    private fun showSelectFocusTaskDialog(tasks: List<ReminderItem>) {
        val names = mutableListOf(if (isArabic) "🌐 جلسة تركيز عامة (بدون مهمة محددة)" else "🌐 General Focus Session")
        names.addAll(tasks.map { "🎯 ${it.title} (${it.actualFocusedMinutes}/${it.expectedMinutes}m)" })

        AlertDialog.Builder(this)
            .setTitle(if (isArabic) "اختر المهمة لربطها بالجلسة" else "Link Session to Task")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == 0) {
                    selectedFocusTaskId = null
                } else {
                    val chosen = tasks[which - 1]
                    selectedFocusTaskId = chosen.id
                }
                renderCurrentTab()
            }
            .show()
    }

    private fun setPomodoroDuration(minutes: Int) {
        inAppCountDownTimer?.cancel()
        isPomodoroRunning = false
        ReminderRepository.clearActiveFocusState(this)
        selectedPomodoroMinutes = minutes
        pomodoroTotalMillis = minutes * 60 * 1000L
        pomodoroRemainingMillis = pomodoroTotalMillis
        activeFocusSessionId = UUID.randomUUID().toString()
        renderCurrentTab()
    }

    private fun toggleInAppPomodoro() {
        if (isPomodoroRunning) {
            inAppCountDownTimer?.cancel()
            isPomodoroRunning = false
            ReminderRepository.saveActiveFocusState(
                this,
                startEpochMs = 0L,
                totalDurationMs = pomodoroTotalMillis,
                remainingOnPauseMs = pomodoroRemainingMillis,
                isRunning = false,
                linkedTaskId = selectedFocusTaskId,
                isBreakMode = isBreakSession
            )
            tvPomodoroStartBtn?.text = if (isArabic) "▶ استئناف" else "▶ Resume"
        } else {
            startWallClockCountDown(pomodoroRemainingMillis)
        }
    }

    private fun startWallClockCountDown(durationMs: Long) {
        inAppCountDownTimer?.cancel()
        isPomodoroRunning = true
        // حساب نقطة البداية بحيث يكون الوقت المتبقي الفعلي متطابقاً مع ساعة النظام الحقيقية
        val alreadyElapsed = pomodoroTotalMillis - durationMs
        pomodoroStartWallClockMs = System.currentTimeMillis() - alreadyElapsed

        ReminderRepository.saveActiveFocusState(
            this,
            startEpochMs = pomodoroStartWallClockMs,
            totalDurationMs = pomodoroTotalMillis,
            remainingOnPauseMs = durationMs,
            isRunning = true,
            linkedTaskId = selectedFocusTaskId,
            isBreakMode = isBreakSession
        )

        tvPomodoroStartBtn?.text = if (isArabic) "⏸ إيقاف مؤقت" else "⏸ Pause"

        inAppCountDownTimer = object : CountDownTimer(durationMs, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                val trueElapsed = System.currentTimeMillis() - pomodoroStartWallClockMs
                val trueRemaining = (pomodoroTotalMillis - trueElapsed).coerceAtLeast(0L)
                pomodoroRemainingMillis = trueRemaining
                circularTimerView?.updateTimerDisplay(pomodoroRemainingMillis, pomodoroTotalMillis)
            }

            override fun onFinish() {
                isPomodoroRunning = false
                ReminderRepository.clearActiveFocusState(this@MainActivity)
                pomodoroRemainingMillis = pomodoroTotalMillis
                triggerGentleHaptic()

                if (!isBreakSession) {
                    ReminderRepository.recordCompletedFocusSession(
                        this@MainActivity,
                        sessionId = activeFocusSessionId,
                        taskId = selectedFocusTaskId,
                        actualMinutes = selectedPomodoroMinutes
                    )
                    sendSessionEndNotification(selectedPomodoroMinutes)
                    checkAndNotifyAchievements()
                    showFocusSessionCompletedDialog(selectedPomodoroMinutes)
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        if (isArabic) "☕ انتهت فترة الراحة! هل أنت مستعد لجلسة تركيز جديدة؟" else "☕ Break finished! Ready to focus?",
                        Toast.LENGTH_LONG
                    ).show()
                }
                activeFocusSessionId = UUID.randomUUID().toString()
                renderCurrentTab()
            }
        }.start()
    }

    // تسجيل الوقت الفعلي فقط عند إنهاء الجلسة يدوياً وعدم تسجيل وقت لم يقضه المستخدم (Section 4.3 & Section 8)
    private fun finishOrCancelFocusSession() {
        inAppCountDownTimer?.cancel()
        val spentMs = (pomodoroTotalMillis - pomodoroRemainingMillis).coerceAtLeast(0L)
        val actualMinutes = (spentMs / 60000L).toInt()

        ReminderRepository.clearActiveFocusState(this)
        isPomodoroRunning = false
        pomodoroRemainingMillis = pomodoroTotalMillis

        if (!isBreakSession && actualMinutes >= 1) {
            ReminderRepository.recordCompletedFocusSession(
                this,
                sessionId = activeFocusSessionId,
                taskId = selectedFocusTaskId,
                actualMinutes = actualMinutes
            )
            activeFocusSessionId = UUID.randomUUID().toString()
            checkAndNotifyAchievements()
            showFocusSessionCompletedDialog(actualMinutes)
        } else {
            Toast.makeText(
                this,
                if (isArabic) "تم إلغاء الجلسة وإعادة ضبط المؤقت" else "Session reset",
                Toast.LENGTH_SHORT
            ).show()
        }
        renderCurrentTab()
    }

    private fun showFocusSessionCompletedDialog(actualMinutes: Int) {
        val linkedTask = selectedFocusTaskId?.let { ReminderRepository.getItemById(this, it) }
        val taskLine = if (linkedTask != null) {
            if (isArabic) "\n🎯 المهمة: ${linkedTask.title}\n⏱️ إجمالي وقت المهمة المسجل: ${linkedTask.actualFocusedMinutes} د من ${linkedTask.expectedMinutes} د"
            else "\n🎯 Task: ${linkedTask.title}\n⏱️ Logged: ${linkedTask.actualFocusedMinutes}m / ${linkedTask.expectedMinutes}m"
        } else ""

        AlertDialog.Builder(this)
            .setTitle(if (isArabic) "✅ ملخص جلسة التركيز" else "✅ Focus Session Summary")
            .setMessage(
                if (isArabic) "أحسنت! تم تسجيل $actualMinutes دقيقة تركيز فعلية بنجاح.$taskLine"
                else "Great job! Logged $actualMinutes minutes of actual focus.$taskLine"
            )
            .setPositiveButton(if (isArabic) "بدء فترة راحة ☕" else "Start Break ☕") { _, _ ->
                val breakMins = getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
                    .getInt(ReminderRepository.KEY_DEFAULT_BREAK_MINS, 5)
                isBreakSession = true
                setPomodoroDuration(breakMins)
                toggleInAppPomodoro()
            }
            .setNeutralButton(if (isArabic) "جلسة أخرى 🔄" else "Another Session 🔄") { _, _ ->
                isBreakSession = false
                setPomodoroDuration(selectedPomodoroMinutes)
                toggleInAppPomodoro()
            }
            .setNegativeButton(if (isArabic) "إنهاء" else "Finish", null)
            .show()
    }

    private fun launchFloatingFocusWindow(linkedTask: ReminderItem?) {
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle(if (isArabic) "صلاحية النافذة العائمة" else "Floating Window Permission")
                .setMessage(
                    if (isArabic) "تحتاج ميزة النافذة العائمة إلى صلاحية «الظهور فوق التطبيقات الأخرى» لتتمكن من متابعة مؤقت التركيز أثناء استخدام تطبيقاتك الأخرى."
                    else "The floating focus window requires 'Display over other apps' permission so you can track your session while using other apps."
                )
                .setPositiveButton(if (isArabic) "تفعيل الصلاحية" else "Grant Permission") { _, _ ->
                    requestOverlayPermission()
                }
                .setNegativeButton(if (isArabic) "البقاء داخل التطبيق" else "Stay in App", null)
                .show()
            return
        }

        val title = linkedTask?.title ?: (if (isArabic) "جلسة تركيز ($selectedPomodoroMinutes د)" else "Focus ($selectedPomodoroMinutes min)")
        val serviceIntent = Intent(this, FloatingCardService::class.java).apply {
            putExtra(FloatingCardService.EXTRA_ITEM_ID, linkedTask?.id ?: "pomodoro_session")
            putExtra(FloatingCardService.EXTRA_TITLE, title)
            putExtra(FloatingCardService.EXTRA_IS_HABIT, false)
            putExtra(FloatingCardService.EXTRA_CUSTOM_MINUTES, selectedPomodoroMinutes)
            putExtra(FloatingCardService.EXTRA_IS_ARABIC, isArabic)
            putExtra(FloatingCardService.EXTRA_AUTO_START_FOCUS, true)
            putExtra(FloatingCardService.EXTRA_SESSION_ID, activeFocusSessionId)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    private fun showCustomMinutesDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = createPillDrawable(bgCardColor(), dp(20), currentAccentColor)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        view.addView(TextView(this).apply {
            text = if (isArabic) "⏱️ تحديد مدة التركيز (1 - 240 دقيقة)" else "⏱️ Custom Focus Minutes (1 - 240)"
            setTextColor(textPrimaryColor())
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
        })

        val etMins = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "40"
            setHintTextColor(textSecondaryColor())
            setTextColor(textPrimaryColor())
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        view.addView(etMins)

        val btnOk = Button(this).apply {
            text = if (isArabic) "اعتماد" else "Apply"
            isAllCaps = false
            setTextColor(Color.parseColor("#0B0F19"))
            backgroundTintList = ColorStateList.valueOf(accentPrimaryColor())
            setOnClickListener {
                val parsed = etMins.text.toString().toIntOrNull()
                if (parsed == null || parsed !in 1..240) {
                    Toast.makeText(
                        this@MainActivity,
                        if (isArabic) "يرجى إدخال مدة صحيحة بين 1 و 240 دقيقة" else "Please enter a valid duration (1 - 240 mins)",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    setPomodoroDuration(parsed)
                    dialog.dismiss()
                }
            }
        }
        view.addView(btnOk)

        dialog.setContentView(view)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.85).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
    }

    // مشغل الصوت المحيطي مع طلب AudioFocus للتعامل مع المكالمات ومقاطعات الصوت (Section 4.4)
    private fun startRichAmbientSound(modeIndex: Int) {
        stopAmbientSound()
        if (modeIndex <= 0) return

        val audioAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(audioAttrs)
                .setOnAudioFocusChangeListener(audioFocusChangeListener)
                .build()
            audioFocusRequest = req
            audioManager?.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            audioManager?.requestAudioFocus(audioFocusChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }

        isAmbientPlaying = true
        val sampleRate = 22050
        val bufferSize = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)

        ambientAudioTrack = AudioTrack.Builder()
            .setAudioAttributes(audioAttrs)
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(bufferSize)
            .build()

        ambientAudioTrack?.setVolume(ambientVolume)
        ambientAudioTrack?.play()

        thread {
            val buffer = ShortArray(bufferSize)
            var phase = 0.0
            var phase2 = 0.0
            var lfo = 0.0
            var lastOut = 0.0
            while (isAmbientPlaying) {
                for (i in buffer.indices) {
                    val white = Math.random() * 2.0 - 1.0
                    val sample = when (modeIndex) {
                        1 -> { // المطر
                            lastOut = (lastOut + (0.08 * white)) / 1.08
                            lastOut * 0.65
                        }
                        2 -> { // أمواج البحر
                            lfo += 0.00018
                            val swell = (sin(lfo) + 1.2) * 0.45
                            lastOut = (lastOut + (0.05 * white)) / 1.05
                            lastOut * swell
                        }
                        3 -> { // الغابة والطبيعة
                            lfo += 0.00035
                            phase += 0.012
                            val breeze = (sin(lfo) + 1.0) * 0.4
                            (white * 0.15 * breeze) + (sin(phase) * 0.15)
                        }
                        4 -> { // الضوضاء البيضاء
                            white * 0.25
                        }
                        5 -> { // صوت المروحة
                            phase += 0.018
                            lastOut = (lastOut + (0.04 * white)) / 1.04
                            (lastOut * 0.55) + (sin(phase) * 0.18)
                        }
                        else -> { // الموسيقى الهادئة (Ambient Harmonic Chord)
                            phase += (2.0 * Math.PI * 174.0) / sampleRate
                            phase2 += (2.0 * Math.PI * 261.6) / sampleRate
                            lfo += 0.0001
                            val env = (sin(lfo) + 1.5) * 0.3
                            ((sin(phase) * 0.35) + (sin(phase2) * 0.25)) * env
                        }
                    }
                    buffer[i] = (sample * 11000).toInt().coerceIn(-32000, 32000).toShort()
                }
                try {
                    ambientAudioTrack?.write(buffer, 0, buffer.size)
                } catch (_: Exception) {
                    break
                }
            }
        }
    }

    private fun stopAmbientSound() {
        isAmbientPlaying = false
        try {
            ambientAudioTrack?.stop()
            ambientAudioTrack?.release()
        } catch (_: Exception) {
        }
        ambientAudioTrack = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { audioManager?.abandonAudioFocusRequest(it) }
        }
    }

    // =========================================================================
    // 6. صفحة التقارير والإحصائيات اليومية والأسبوعية (Section 9)
    // =========================================================================

    private fun showStatisticsAndReportsDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val scroll = ScrollView(this).apply {
            background = createPillDrawable(bgPrimaryColor(), dp(24), currentAccentColor)
            isFillViewport = true
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(28))
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        headerRow.addView(TextView(this).apply {
            text = if (isArabic) "📊 التقارير والإحصائيات" else "📊 Reports & Statistics"
            setTextColor(textPrimaryColor())
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        headerRow.addView(TextView(this).apply {
            text = "✕"
            textSize = 18f
            setTextColor(textSecondaryColor())
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { dialog.dismiss() }
        })
        container.addView(headerRow)

        val allItems = ReminderRepository.getAllItems(this)
        val tasks = allItems.filter { !it.isHabit }
        val habits = allItems.filter { it.isHabit && !it.isPaused }
        val todayEpoch = ReminderRepository.currentEpochDay()
        val todayFocusMins = ReminderRepository.getTodayFocusMinutes(this)
        val todaySessions = ReminderRepository.getTodayFocusSessions(this)
        val doneTasksToday = tasks.count { it.isCompletedToday }
        val dueTasksToday = tasks.count { it.dueDateEpochDay <= todayEpoch }.coerceAtLeast(1)
        val taskCompletionRate = (doneTasksToday * 100) / dueTasksToday
        val doneHabitsToday = habits.count { it.isCompletedToday }

        // ١. إحصائيات اليوم
        container.addView(createSectionHeader(if (isArabic) "📅 إحصائيات اليوم" else "📅 Today's Statistics"))
        val todayCard = createCalmCard().apply {
            addView(TextView(this@MainActivity).apply {
                text = if (isArabic) {
                    "• إجمالي وقت التركيز: $todayFocusMins دقيقة ($todaySessions جلسات مكتملة)\n" +
                            "• المهام المكتملة: $doneTasksToday من ${tasks.size} (نسبة الإنجاز: $taskCompletionRate%)\n" +
                            "• تقدم العادات اليومية: $doneHabitsToday من ${habits.size} مكتملة"
                } else {
                    "• Focus Time: $todayFocusMins mins ($todaySessions completed sessions)\n" +
                            "• Tasks Completed: $doneTasksToday of ${tasks.size} ($taskCompletionRate%)\n" +
                            "• Habits Progress: $doneHabitsToday of ${habits.size} completed"
                }
                setTextColor(textPrimaryColor())
                textSize = 14f
                setLineSpacing(dp(4).toFloat(), 1f)
            })
        }
        container.addView(todayCard)

        // ٢. التقرير الأسبوعي ورسم بياني لأوقات التركيز (Section 9)
        container.addView(createSectionHeader(if (isArabic) "📈 التقرير الأسبوعي" else "📈 Weekly Report"))

        val history = ReminderRepository.getFocusHistory(this)
        val weekDaysFocus = IntArray(7)
        var prevWeekFocus = 0
        for (rec in history) {
            val diff = (todayEpoch - rec.epochDay).toInt()
            if (diff in 0..6) {
                weekDaysFocus[6 - diff] += rec.durationMinutes
            } else if (diff in 7..13) {
                prevWeekFocus += rec.durationMinutes
            }
        }
        if (weekDaysFocus[6] == 0 && todayFocusMins > 0) {
            weekDaysFocus[6] = todayFocusMins
        }
        val totalWeekFocus = weekDaysFocus.sum()
        val maxDayFocus = (weekDaysFocus.maxOrNull() ?: 1).coerceAtLeast(30)

        val dayLabelsAr = listOf("ح", "ن", "ث", "ر", "خ", "ج", "س")
        val dayLabelsEn = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        var mostActiveDayName = if (isArabic) "اليوم" else "Today"
        var bestMins = -1

        val weeklyCard = createCalmCard().apply {
            // رسم بياني بالأعمدة لأوقات التركيز خلال 7 أيام
            val chartRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.BOTTOM
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(120))
                setPadding(0, dp(10), 0, dp(6))
            }

            for (i in 0..6) {
                val offset = 6 - i
                val calD = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) }
                val dow = (calD.get(Calendar.DAY_OF_WEEK) - 1).coerceIn(0, 6)
                val dName = if (isArabic) dayLabelsAr[dow] else dayLabelsEn[dow]
                val mins = weekDaysFocus[i]
                if (mins > bestMins) {
                    bestMins = mins
                    mostActiveDayName = dName
                }

                val col = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                }

                col.addView(TextView(this@MainActivity).apply {
                    text = "${mins}m"
                    textSize = 10f
                    setTextColor(textSecondaryColor())
                })

                val barH = ((mins.toFloat() / maxDayFocus.toFloat()) * dp(64)).toInt().coerceAtLeast(dp(6))
                val bar = View(this@MainActivity).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(16), barH).apply {
                        topMargin = dp(4)
                        bottomMargin = dp(4)
                    }
                    background = createPillDrawable(if (offset == 0) accentPrimaryColor() else accentSecondaryColor(), dp(6), null)
                }
                col.addView(bar)

                col.addView(TextView(this@MainActivity).apply {
                    text = dName
                    textSize = 11f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(textPrimaryColor())
                })

                chartRow.addView(col)
            }
            addView(chartRow)

            val diffVsLastWeek = totalWeekFocus - prevWeekFocus
            val compStr = if (diffVsLastWeek >= 0) "+$diffVsLastWeek د" else "$diffVsLastWeek د"

            addView(TextView(this@MainActivity).apply {
                text = if (isArabic) {
                    "• إجمالي التركيز الأسبوعي: $totalWeekFocus دقيقة (مقارنة بالأسبوع السابق: $compStr)\n" +
                            "• أكثر الأيام نشاطاً: $mostActiveDayName ($bestMins دقيقة)"
                } else {
                    "• Weekly Focus: $totalWeekFocus mins (vs last week: $compStr)\n" +
                            "• Most Active Day: $mostActiveDayName ($bestMins mins)"
                }
                setTextColor(textSecondaryColor())
                textSize = 13f
                setPadding(0, dp(8), 0, 0)
            })
        }
        container.addView(weeklyCard)

        // ٣. مقارنة الوقت المتوقع بالفعلي للمهام (Section 8)
        container.addView(createSectionHeader(if (isArabic) "⏱️ مقارنة الوقت المتوقع بالفعلي للمهام" else "⏱️ Expected vs Actual Task Time"))
        val comparisonCard = createCalmCard().apply {
            tasks.take(6).forEach { t ->
                addView(TextView(this@MainActivity).apply {
                    text = "• ${t.title}: " + (if (isArabic) "المتوقع ${t.expectedMinutes} د | الفعلي ${t.actualFocusedMinutes} د" else "Est ${t.expectedMinutes}m | Actual ${t.actualFocusedMinutes}m")
                    setTextColor(textPrimaryColor())
                    textSize = 13f
                    setPadding(0, dp(3), 0, dp(3))
                })
            }
        }
        container.addView(comparisonCard)

        scroll.addView(container)
        dialog.setContentView(scroll)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94).toInt(), (resources.displayMetrics.heightPixels * 0.86).toInt())
        dialog.show()
    }

    // =========================================================================
    // 7. نظام الإنجازات الحقيقي (Section 11)
    // =========================================================================

    private fun showAchievementsDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val scroll = ScrollView(this).apply {
            background = createPillDrawable(bgPrimaryColor(), dp(24), currentAccentColor)
            isFillViewport = true
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(28))
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        headerRow.addView(TextView(this).apply {
            text = if (isArabic) "🏆 سجل الإنجازات" else "🏆 Achievements"
            setTextColor(textPrimaryColor())
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        headerRow.addView(TextView(this).apply {
            text = "✕"
            textSize = 18f
            setTextColor(textSecondaryColor())
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { dialog.dismiss() }
        })
        container.addView(headerRow)

        val allItems = ReminderRepository.getAllItems(this)
        val totalSessions = ReminderRepository.getTotalAllTimeFocusSessions(this)
        val totalFocusMins = ReminderRepository.getTotalAllTimeFocusMinutes(this)
        val completedTasksCount = allItems.count { !it.isHabit && it.isCompletedToday }
        val maxHabitStreak = allItems.filter { it.isHabit }.maxOfOrNull { maxOf(it.streakCount, it.longestStreak) } ?: 0

        val achievements = listOf(
            Triple(
                if (isArabic) "🎯 خطوة التركيز الأولى" else "🎯 First Focus Step",
                if (isArabic) "إكمال أول 5 جلسات تركيز ($totalSessions / 5)" else "Complete 5 focus sessions ($totalSessions / 5)",
                totalSessions >= 5
            ),
            Triple(
                if (isArabic) "✅ منجز المهام" else "✅ Task Finisher",
                if (isArabic) "إكمال 10 مهام ($completedTasksCount / 10)" else "Complete 10 tasks ($completedTasksCount / 10)",
                completedTasksCount >= 10
            ),
            Triple(
                if (isArabic) "🔥 أسبوع التزام كامل" else "🔥 7-Day Habit Streak",
                if (isArabic) "الالتزام بعادة لمدة 7 أيام متتالية ($maxHabitStreak / 7)" else "Maintain a 7-day habit streak ($maxHabitStreak / 7)",
                maxHabitStreak >= 7
            ),
            Triple(
                if (isArabic) "👑 سيد الوقت (10 ساعات)" else "👑 Master of Time (10 Hours)",
                if (isArabic) "الوصول إلى 600 دقيقة تركيز إجمالية ($totalFocusMins / 600 د)" else "Reach 600 mins of focus ($totalFocusMins / 600m)",
                totalFocusMins >= 600
            )
        )

        achievements.forEach { (title, desc, unlocked) ->
            val card = createCalmCard().apply {
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }

                val col = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }

                col.addView(TextView(this@MainActivity).apply {
                    text = title
                    setTextColor(if (unlocked) successColor() else textPrimaryColor())
                    textSize = 17f
                    setTypeface(typeface, Typeface.BOLD)
                })

                col.addView(TextView(this@MainActivity).apply {
                    text = desc
                    setTextColor(textSecondaryColor())
                    textSize = 13f
                })

                val badge = TextView(this@MainActivity).apply {
                    text = if (unlocked) (if (isArabic) "✓ محقق" else "✓ Unlocked") else (if (isArabic) "قيد التقدم" else "Locked")
                    textSize = 12f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (unlocked) Color.parseColor("#0B0F19") else textSecondaryColor())
                    background = createPillDrawable(if (unlocked) successColor() else bgElevatedColor(), dp(12), null)
                    setPadding(dp(10), dp(6), dp(10), dp(6))
                }

                row.addView(col)
                row.addView(badge)
                addView(row)
            }
            container.addView(card)
        }

        scroll.addView(container)
        dialog.setContentView(scroll)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
    }

    private fun checkAndNotifyAchievements() {
        val prefs = getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean(ReminderRepository.KEY_NOTIF_ACHIEVEMENTS, true)) return

        val unlockedSet = prefs.getString("unlocked_badges_set", "")?.split(",")?.filter { it.isNotBlank() }?.toMutableSet() ?: mutableSetOf()
        val totalSessions = ReminderRepository.getTotalAllTimeFocusSessions(this)
        val maxStreak = ReminderRepository.getAllItems(this).filter { it.isHabit }.maxOfOrNull { it.streakCount } ?: 0

        var newAchievementTitle: String? = null
        if (totalSessions >= 5 && !unlockedSet.contains("focus_5")) {
            unlockedSet.add("focus_5")
            newAchievementTitle = if (isArabic) "🏆 إنجاز جديد: إكمال 5 جلسات تركيز!" else "🏆 Achievement Unlocked: 5 Focus Sessions!"
        } else if (maxStreak >= 7 && !unlockedSet.contains("streak_7")) {
            unlockedSet.add("streak_7")
            newAchievementTitle = if (isArabic) "🏆 إنجاز جديد: سلسلة التزام 7 أيام!" else "🏆 Achievement Unlocked: 7-Day Streak!"
        }

        if (newAchievementTitle != null) {
            prefs.edit().putString("unlocked_badges_set", unlockedSet.joinToString(",")).apply()
            Toast.makeText(this, newAchievementTitle, Toast.LENGTH_LONG).show()
        }
    }

    private fun sendSessionEndNotification(minutes: Int) {
        val prefs = getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean(ReminderRepository.KEY_NOTIF_SESSION_END, true)) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val chId = "waqt_session_end_ch"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(chId, "Session End", NotificationManager.IMPORTANCE_HIGH))
        }
        val notif = NotificationCompat.Builder(this, chId)
            .setSmallIcon(R.drawable.logo_waqt)
            .setContentTitle(if (isArabic) "✅ انتهت جلسة التركيز ($minutes د)" else "✅ Focus Session Completed (${minutes}m)")
            .setContentText(if (isArabic) "تم حفظ الوقت الفعلي في سجلك اليومي." else "Actual focus time recorded.")
            .setAutoCancel(true)
            .build()
        nm.notify(7075, notif)
    }

    // =========================================================================
    // 8. شاشة الإعدادات والتخصيص المصححة بالكامل (Section 13 & Section 14)
    // جميع الأزرار والسويتشات تفاعلية وتعمل فوراً وتحدث الواجهة أمام المستخدم
    // =========================================================================

    private fun showSettingsBottomSheet() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val prefs = getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)

        val scroll = ScrollView(this).apply {
            background = GradientDrawable().apply {
                cornerRadii = floatArrayOf(dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), 0f, 0f, 0f, 0f)
                setColor(bgPrimaryColor())
                setStroke(dp(1), Color.parseColor("#3394A3B8"))
            }
            isFillViewport = true
        }

        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(36))
        }

        // هيدر شاشة الإعدادات مع زر إغلاق واضح
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        headerRow.addView(TextView(this).apply {
            text = if (isArabic) "⚙️ الإعدادات والتخصيص" else "⚙️ Settings & Customization"
            setTextColor(textPrimaryColor())
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        headerRow.addView(TextView(this).apply {
            text = "✕"
            textSize = 20f
            setTextColor(textSecondaryColor())
            setPadding(dp(12), dp(4), dp(4), dp(4))
            setOnClickListener {
                previewRingtone?.stop()
                dialog.dismiss()
            }
        })
        view.addView(headerRow)

        // ---------------------------------------------------------------------
        // القسم 1: المظهر (Appearance: الوضع الداكن / الفاتح، اللون الأساسي، تقليل الحركة)
        // ---------------------------------------------------------------------
        view.addView(createSectionHeader(if (isArabic) "🎨 المظهر" else "🎨 Appearance"))

        val appearanceCard = createCalmCard().apply {
            addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "نمط الإضاءة (الوضع الداكن / الفاتح):" else "Theme Mode (Dark / Light):"
                setTextColor(textPrimaryColor())
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
            })

            val modeRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(8), 0, dp(12))
            }

            val btnDark = TextView(this@MainActivity).apply {
                text = if (isArabic) "🌙 الوضع الداكن" else "🌙 Dark Mode"
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (isDarkMode) Color.parseColor("#0B0F19") else textPrimaryColor())
                background = createPillDrawable(if (isDarkMode) accentPrimaryColor() else bgElevatedColor(), dp(14), null)
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) }
                setOnClickListener {
                    isDarkMode = true
                    prefs.edit().putBoolean(ReminderRepository.KEY_DARK_MODE, true).apply()
                    renderCurrentTab()
                    dialog.dismiss()
                    showSettingsBottomSheet()
                }
            }

            val btnLight = TextView(this@MainActivity).apply {
                text = if (isArabic) "☀️ الوضع الفاتح" else "☀️ Light Mode"
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (!isDarkMode) Color.parseColor("#0B0F19") else textPrimaryColor())
                background = createPillDrawable(if (!isDarkMode) accentPrimaryColor() else bgElevatedColor(), dp(14), null)
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                setOnClickListener {
                    isDarkMode = false
                    prefs.edit().putBoolean(ReminderRepository.KEY_DARK_MODE, false).apply()
                    renderCurrentTab()
                    dialog.dismiss()
                    showSettingsBottomSheet()
                }
            }
            modeRow.addView(btnDark)
            modeRow.addView(btnLight)
            addView(modeRow)

            // اختيار اللون الأساسي
            addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "اللون الأساسي للتفاعل:" else "Primary Accent Color:"
                setTextColor(textPrimaryColor())
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, 0, 0, dp(8))
            })

            val colorsRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            val accentChoices = listOf(
                Pair("#38BDF8", if (isArabic) "سماوي" else "Sky"),
                Pair("#8B5CF6", if (isArabic) "بنفسجي" else "Violet"),
                Pair("#10B981", if (isArabic) "أخضر" else "Emerald"),
                Pair("#FB7185", if (isArabic) "وردي" else "Rose")
            )
            accentChoices.forEach { (hex, label) ->
                val isSel = (currentAccentColor.equals(hex, ignoreCase = true))
                val cChip = TextView(this@MainActivity).apply {
                    text = if (isSel) "✓ $label" else label
                    textSize = 12f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.parseColor("#0B0F19"))
                    background = createPillDrawable(Color.parseColor(hex), dp(12), if (isSel) "#FFFFFF" else null)
                    layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(6) }
                    setOnClickListener {
                        currentAccentColor = hex
                        prefs.edit().putString(ReminderRepository.KEY_ACCENT_COLOR, hex).apply()
                        renderCurrentTab()
                        dialog.dismiss()
                        showSettingsBottomSheet()
                    }
                }
                colorsRow.addView(cChip)
            }
            addView(colorsRow)
        }
        view.addView(appearanceCard)

        view.addView(createWorkingToggleCard(
            title = if (isArabic) "تقليل الحركة والرسوم المتحركة" else "Reduce Motion",
            desc = if (isArabic) "تخطي شاشة البداية المتحركة وتقليل المؤثرات" else "Skip splash animation and reduce motion effects",
            prefKey = ReminderRepository.KEY_REDUCE_MOTION,
            defaultVal = false
        ) { checked ->
            reduceMotion = checked
        })

        // ---------------------------------------------------------------------
        // القسم 2: اللغة (Language: العربية / الإنجليزية)
        // ---------------------------------------------------------------------
        view.addView(createSectionHeader(if (isArabic) "🌐 اللغة" else "🌐 Language"))
        val langCard = createCalmCard().apply {
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            val btnAr = TextView(this@MainActivity).apply {
                text = "✓ العربية (RTL)".takeIf { isArabic } ?: "العربية (RTL)"
                textSize = 14f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (isArabic) Color.parseColor("#0B0F19") else textPrimaryColor())
                background = createPillDrawable(if (isArabic) accentPrimaryColor() else bgElevatedColor(), dp(14), null)
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) }
                setOnClickListener {
                    if (!isArabic) {
                        toggleLanguage()
                        dialog.dismiss()
                        showSettingsBottomSheet()
                    }
                }
            }
            val btnEn = TextView(this@MainActivity).apply {
                text = "✓ English (LTR)".takeIf { !isArabic } ?: "English (LTR)"
                textSize = 14f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (!isArabic) Color.parseColor("#0B0F19") else textPrimaryColor())
                background = createPillDrawable(if (!isArabic) accentPrimaryColor() else bgElevatedColor(), dp(14), null)
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                setOnClickListener {
                    if (isArabic) {
                        toggleLanguage()
                        dialog.dismiss()
                        showSettingsBottomSheet()
                    }
                }
            }
            row.addView(btnAr)
            row.addView(btnEn)
            addView(row)
        }
        view.addView(langCard)

        // ---------------------------------------------------------------------
        // القسم 3: التركيز (Focus: مدة التركيز، مدة الراحة، هدف التركيز اليومي)
        // ---------------------------------------------------------------------
        view.addView(createSectionHeader(if (isArabic) "🍅 إعدادات التركيز" else "🍅 Focus Settings"))
        val focusSettingsCard = createCalmCard().apply {
            // مدة التركيز الافتراضية
            val curFocusDef = prefs.getInt(ReminderRepository.KEY_DEFAULT_FOCUS_MINS, 25)
            val tvFocusLabel = TextView(this@MainActivity).apply {
                text = if (isArabic) "مدة التركيز الافتراضية: $curFocusDef دقيقة" else "Default Focus Duration: $curFocusDef mins"
                setTextColor(textPrimaryColor())
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
            }
            addView(tvFocusLabel)

            val focusDurRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(8), 0, dp(12))
            }
            listOf(15, 25, 45, 50).forEach { m ->
                val isSel = (m == curFocusDef)
                val chip = TextView(this@MainActivity).apply {
                    text = "${m}m"
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (isSel) Color.parseColor("#0B0F19") else textPrimaryColor())
                    background = createPillDrawable(if (isSel) accentPrimaryColor() else bgElevatedColor(), dp(12), null)
                    layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(6) }
                    setOnClickListener {
                        prefs.edit().putInt(ReminderRepository.KEY_DEFAULT_FOCUS_MINS, m).apply()
                        if (!isPomodoroRunning) setPomodoroDuration(m)
                        dialog.dismiss()
                        showSettingsBottomSheet()
                    }
                }
                focusDurRow.addView(chip)
            }
            addView(focusDurRow)

            // مدة الراحة الافتراضية
            val curBreakDef = prefs.getInt(ReminderRepository.KEY_DEFAULT_BREAK_MINS, 5)
            addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "مدة الراحة القصيرة: $curBreakDef دقائق" else "Short Break Duration: $curBreakDef mins"
                setTextColor(textPrimaryColor())
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
            })

            val breakDurRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(8), 0, dp(12))
            }
            listOf(5, 10, 15).forEach { m ->
                val isSel = (m == curBreakDef)
                val chip = TextView(this@MainActivity).apply {
                    text = "${m}m"
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (isSel) Color.parseColor("#0B0F19") else textPrimaryColor())
                    background = createPillDrawable(if (isSel) successColor() else bgElevatedColor(), dp(12), null)
                    layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(6) }
                    setOnClickListener {
                        prefs.edit().putInt(ReminderRepository.KEY_DEFAULT_BREAK_MINS, m).apply()
                        dialog.dismiss()
                        showSettingsBottomSheet()
                    }
                }
                breakDurRow.addView(chip)
            }
            addView(breakDurRow)

            // هدف التركيز اليومي
            val curGoalDef = prefs.getInt(ReminderRepository.KEY_DAILY_FOCUS_GOAL_MINS, 120)
            addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "هدف التركيز اليومي: $curGoalDef دقيقة" else "Daily Focus Goal: $curGoalDef mins"
                setTextColor(textPrimaryColor())
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
            })

            val goalRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(8), 0, 0)
            }
            listOf(60, 90, 120, 180).forEach { g ->
                val isSel = (g == curGoalDef)
                val chip = TextView(this@MainActivity).apply {
                    text = "${g}m"
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (isSel) Color.parseColor("#0B0F19") else textPrimaryColor())
                    background = createPillDrawable(if (isSel) accentPrimaryColor() else bgElevatedColor(), dp(12), null)
                    layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(6) }
                    setOnClickListener {
                        prefs.edit().putInt(ReminderRepository.KEY_DAILY_FOCUS_GOAL_MINS, g).apply()
                        renderCurrentTab()
                        dialog.dismiss()
                        showSettingsBottomSheet()
                    }
                }
                goalRow.addView(chip)
            }
            addView(goalRow)
        }
        view.addView(focusSettingsCard)

        // ---------------------------------------------------------------------
        // القسم 4: الإشعارات والنغمة والعبارات (Notifications)
        // ---------------------------------------------------------------------
        view.addView(createSectionHeader(if (isArabic) "🔔 الإشعارات والتنبيهات" else "🔔 Notifications & Alerts"))

        view.addView(createWorkingToggleCard(
            title = if (isArabic) "تذكيرات المهام" else "Task Reminders",
            desc = if (isArabic) "تشغيل المنبه والإشعارات عند حلول وقت المهمة" else "Trigger alarms and notifications for tasks",
            prefKey = ReminderRepository.KEY_NOTIF_TASKS,
            defaultVal = true
        ) {})

        view.addView(createWorkingToggleCard(
            title = if (isArabic) "تذكيرات العادات اليومية" else "Habit Reminders",
            desc = if (isArabic) "تذكيرك بمواعيد عاداتك اليومية المجدولة" else "Remind you of scheduled daily habits",
            prefKey = ReminderRepository.KEY_NOTIF_HABITS,
            defaultVal = true
        ) {})

        view.addView(createWorkingToggleCard(
            title = if (isArabic) "إشعارات انتهاء جلسة التركيز" else "Focus Session End Notifications",
            desc = if (isArabic) "إرسال تنبيه فور انتهاء مؤقت التركيز" else "Notify when focus timer finishes",
            prefKey = ReminderRepository.KEY_NOTIF_SESSION_END,
            defaultVal = true
        ) {})

        view.addView(createWorkingToggleCard(
            title = if (isArabic) "التذكير التمهيدي وملخصات الإنجاز" else "Pre-Task Motivational Reminders",
            desc = if (isArabic) "إرسال عبارة تحفيزية قبل موعد المهمة" else "Send motivational quote before task due time",
            prefKey = ReminderRepository.KEY_NOTIF_SUMMARIES,
            defaultVal = true
        ) {})

        view.addView(createWorkingToggleCard(
            title = if (isArabic) "إشعارات الأوسمة والإنجازات" else "Achievements Notifications",
            desc = if (isArabic) "تنبيهك عند فتح إنجاز جديد (يمكنك تعطيلها)" else "Notify when unlocking a new achievement badge",
            prefKey = ReminderRepository.KEY_NOTIF_ACHIEVEMENTS,
            defaultVal = true
        ) {})

        view.addView(createWorkingToggleCard(
            title = if (isArabic) "النافذة العائمة التلقائية عند التنبيه" else "Auto Floating Window on Alarm",
            desc = if (isArabic) "إظهار نافذة المهمة العائمة عند رنين المنبه" else "Show floating card when alarm triggers",
            prefKey = ReminderRepository.KEY_AUTO_FLOAT,
            defaultVal = true
        ) {})

        // نغمة المنبه + تجربة الصوت + مدة التذكير التمهيدي + العبارات المخصصة
        val ringtoneAndQuotesCard = createCalmCard().apply {
            val currentRingtone = RingtoneManager.getRingtone(this@MainActivity, ReminderRepository.getAlarmRingtoneUri(this@MainActivity))
            val titleStr = currentRingtone?.getTitle(this@MainActivity) ?: (if (isArabic) "النغمة الافتراضية" else "Default Ringtone")

            addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "🎵 نغمة المنبه: $titleStr" else "🎵 Alarm Sound: $titleStr"
                setTextColor(textPrimaryColor())
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
            })

            val ringRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(8), 0, dp(12))
            }

            val btnPickRing = TextView(this@MainActivity).apply {
                text = if (isArabic) "🎶 تغيير النغمة" else "🎶 Change Sound"
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#0B0F19"))
                background = createPillDrawable(accentPrimaryColor(), dp(12), null)
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(8) }
                setOnClickListener {
                    val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                        putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, ReminderRepository.getAlarmRingtoneUri(this@MainActivity))
                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                    }
                    ringtonePickerLauncher.launch(intent)
                }
            }

            val btnTestRing = TextView(this@MainActivity).apply {
                text = if (isArabic) "🔔 تجربة النغمة" else "🔔 Test Sound"
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(textPrimaryColor())
                background = createPillDrawable(bgElevatedColor(), dp(12), currentAccentColor)
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
                setOnClickListener {
                    if (previewRingtone?.isPlaying == true) {
                        previewRingtone?.stop()
                        text = if (isArabic) "🔔 تجربة النغمة" else "🔔 Test Sound"
                    } else {
                        previewRingtone = RingtoneManager.getRingtone(this@MainActivity, ReminderRepository.getAlarmRingtoneUri(this@MainActivity))
                        previewRingtone?.play()
                        text = if (isArabic) "⏹ إيقاف التجربة" else "⏹ Stop Sound"
                    }
                }
            }
            ringRow.addView(btnPickRing)
            ringRow.addView(btnTestRing)
            addView(ringRow)

            // مدة التذكير التمهيدي قبل المهمة
            val currentPreMins = ReminderRepository.getPreAlertMinutes(this@MainActivity)
            addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "⏱️ وقت التذكير التمهيدي قبل المهمة: $currentPreMins دقائق" else "⏱️ Pre-task quote timing: $currentPreMins mins before"
                setTextColor(textPrimaryColor())
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, 0, 0, dp(6))
            })

            val preRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 0, 0, dp(12))
            }
            listOf(5, 10, 15, 30).forEach { mVal ->
                val isSel = (mVal == currentPreMins)
                val chip = TextView(this@MainActivity).apply {
                    text = "${mVal}m"
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (isSel) Color.parseColor("#0B0F19") else textPrimaryColor())
                    background = createPillDrawable(if (isSel) accentPrimaryColor() else bgElevatedColor(), dp(12), null)
                    layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(6) }
                    setOnClickListener {
                        ReminderRepository.setPreAlertMinutes(this@MainActivity, mVal)
                        dialog.dismiss()
                        showSettingsBottomSheet()
                    }
                }
                preRow.addView(chip)
            }
            addView(preRow)

            // إدارة العبارات التحفيزية المخصصة
            val btnManageQuotes = TextView(this@MainActivity).apply {
                val count = ReminderRepository.getCustomQuotes(this@MainActivity).size
                text = if (isArabic) "✍️ إدارة وإضافة عبارات تحفيزية خاصة ($count)" else "✍️ Manage Custom Motivational Quotes ($count)"
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(textPrimaryColor())
                background = createPillDrawable(bgElevatedColor(), dp(12), "#8B5CF6")
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44))
                setOnClickListener {
                    showManageCustomQuotesDialog()
                }
            }
            addView(btnManageQuotes)
        }
        view.addView(ringtoneAndQuotesCard)

        // ---------------------------------------------------------------------
        // القسم 5: البيانات والنسخ الاحتياطي المحلي الموثق (Section 13)
        // ---------------------------------------------------------------------
        view.addView(createSectionHeader(if (isArabic) "💾 النسخ الاحتياطي واستعادة البيانات" else "💾 Local Backup & Restore"))
        val dataCard = createCalmCard().apply {
            addView(TextView(this@MainActivity).apply {
                text = if (isArabic) "حافظ على مهامك وعاداتك وسجل تركيزك محلياً مع فحص سلامة البيانات قبل الاستعادة:"
                else "Export or restore your tasks, habits, and focus history locally with integrity validation:"
                setTextColor(textSecondaryColor())
                textSize = 13f
                setPadding(0, 0, 0, dp(10))
            })

            val row1 = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 0, 0, dp(8))
            }

            val btnCreateBackup = TextView(this@MainActivity).apply {
                text = if (isArabic) "📤 إنشاء ومشاركة نسخة" else "📤 Create Backup"
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#0B0F19"))
                background = createPillDrawable(accentPrimaryColor(), dp(12), null)
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) }
                setOnClickListener {
                    val json = ReminderRepository.exportCloudBackupJson(this@MainActivity)
                    prefs.edit().putString("local_backup_snapshot_v3", json).apply()
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("WAQT_Backup", json))
                    Toast.makeText(
                        this@MainActivity,
                        if (isArabic) "✓ تم حفظ النسخة الاحتياطية ونسخها للحافظة!" else "✓ Backup saved & copied to clipboard!",
                        Toast.LENGTH_SHORT
                    ).show()
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "WAQT_Backup.json")
                        putExtra(Intent.EXTRA_TEXT, json)
                    }
                    startActivity(Intent.createChooser(shareIntent, if (isArabic) "حفظ النسخة الاحتياطية" else "Save Backup"))
                }
            }

            val btnRestoreBackup = TextView(this@MainActivity).apply {
                text = if (isArabic) "📥 استعادة نسخة احتياطية" else "📥 Restore Backup"
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(textPrimaryColor())
                background = createPillDrawable(bgElevatedColor(), dp(12), currentAccentColor)
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                setOnClickListener {
                    showRestoreBackupDialog(prefs)
                }
            }

            row1.addView(btnCreateBackup)
            row1.addView(btnRestoreBackup)
            addView(row1)
        }
        view.addView(dataCard)

        // ---------------------------------------------------------------------
        // القسم 6: صلاحيات Android (Section 14 & Section 16)
        // ---------------------------------------------------------------------
        view.addView(createSectionHeader(if (isArabic) "🛡️ صلاحيات النظام" else "🛡️ Android Permissions"))
        val permCard = createCalmCard().apply {
            val hasOverlay = Settings.canDrawOverlays(this@MainActivity)
            val alarmMgr = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) alarmMgr.canScheduleExactAlarms() else true
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val isIgnoringBattery = pm.isIgnoringBatteryOptimizations(packageName)

            addView(createPermissionActionRow(
                label = if (isArabic) "صلاحية النافذة العائمة فوق التطبيقات" else "Display Over Other Apps",
                isGranted = hasOverlay
            ) {
                requestOverlayPermission()
            })

            addView(createPermissionActionRow(
                label = if (isArabic) "صلاحية المنبهات الدقيقة في الخلفية" else "Schedule Exact Alarms",
                isGranted = canExact
            ) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    try {
                        startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                    } catch (_: Exception) {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                    }
                }
            })

            addView(createPermissionActionRow(
                label = if (isArabic) "إعدادات إشعارات التطبيق" else "App Notification Settings",
                isGranted = true
            ) {
                try {
                    val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                }
            })

            addView(createPermissionActionRow(
                label = if (isArabic) "استثناء قيود البطارية (لحماية المؤقت)" else "Unrestricted Battery Usage",
                isGranted = isIgnoringBattery
            ) {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                } catch (_: Exception) {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                }
            })
        }
        view.addView(permCard)

        scroll.addView(view)
        dialog.setContentView(scroll)
        dialog.window?.apply {
            setGravity(Gravity.BOTTOM)
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.90).toInt())
        }
        dialog.show()
    }

    // مكون سويتش تفاعلي مضمون 100% يعمل باللمس المباشر ويغير لونه وحالته فوراً
    private fun createWorkingToggleCard(
        title: String,
        desc: String,
        prefKey: String,
        defaultVal: Boolean,
        onToggle: (Boolean) -> Unit
    ): View {
        val prefs = getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
        var currentState = prefs.getBoolean(prefKey, defaultVal)

        val card = createCalmCard().apply {
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val textCol = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = dp(10)
                }
            }

            textCol.addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(textPrimaryColor())
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
            })

            textCol.addView(TextView(this@MainActivity).apply {
                text = desc
                setTextColor(textSecondaryColor())
                textSize = 12f
                setPadding(0, dp(2), 0, 0)
            })

            val togglePill = TextView(this@MainActivity).apply {
                val minW = dp(76)
                val minH = dp(38)
                layoutParams = LinearLayout.LayoutParams(minW, minH)
                gravity = Gravity.CENTER
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
            }

            fun updateToggleAppearance(active: Boolean) {
                togglePill.text = if (active) (if (isArabic) "✓ مفعل" else "✓ ON") else (if (isArabic) "معطل" else "OFF")
                togglePill.setTextColor(if (active) Color.parseColor("#0B0F19") else textSecondaryColor())
                togglePill.background = createPillDrawable(if (active) successColor() else bgElevatedColor(), dp(19), null)
            }

            updateToggleAppearance(currentState)

            val clickAction = View.OnClickListener {
                triggerGentleHaptic()
                currentState = !currentState
                prefs.edit().putBoolean(prefKey, currentState).apply()
                updateToggleAppearance(currentState)
                onToggle(currentState)
            }

            togglePill.setOnClickListener(clickAction)
            row.setOnClickListener(clickAction)

            row.addView(textCol)
            row.addView(togglePill)
            addView(row)
        }
        return card
    }

    private fun createPermissionActionRow(label: String, isGranted: Boolean, onClick: () -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))

            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(textPrimaryColor())
                textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })

            val btn = TextView(this@MainActivity).apply {
                text = if (isGranted) (if (isArabic) "✓ مفعل" else "✓ Active") else (if (isArabic) "تفعيل الآن" else "Grant")
                textSize = 12f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (isGranted) Color.parseColor("#0B0F19") else Color.parseColor("#0B0F19"))
                background = createPillDrawable(if (isGranted) successColor() else alertColor(), dp(12), null)
                setPadding(dp(12), dp(6), dp(12), dp(6))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36))
                setOnClickListener { onClick() }
            }
            addView(btn)
        }
    }

    private fun showRestoreBackupDialog(prefs: android.content.SharedPreferences) {
        val savedLocal = prefs.getString("local_backup_snapshot_v3", null) ?: prefs.getString("cloud_backup_snapshot", "") ?: ""
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = createPillDrawable(bgCardColor(), dp(20), currentAccentColor)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        view.addView(TextView(this).apply {
            text = if (isArabic) "📥 استعادة نسخة احتياطية" else "📥 Restore Backup"
            setTextColor(textPrimaryColor())
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
        })

        val etJson = EditText(this).apply {
            setText(savedLocal)
            hint = if (isArabic) "الصق نص النسخة الاحتياطية JSON هنا..." else "Paste backup JSON here..."
            setHintTextColor(textSecondaryColor())
            setTextColor(textPrimaryColor())
            textSize = 12f
            maxLines = 6
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(10)
                bottomMargin = dp(12)
            }
        }
        view.addView(etJson)

        val btnRestore = Button(this).apply {
            text = if (isArabic) "التحقق من السلامة واستعادة البيانات" else "Validate & Restore"
            isAllCaps = false
            setTextColor(Color.parseColor("#0B0F19"))
            backgroundTintList = ColorStateList.valueOf(accentPrimaryColor())
            setOnClickListener {
                val raw = etJson.text.toString().trim()
                if (ReminderRepository.importCloudBackupJson(this@MainActivity, raw)) {
                    loadPreferencesState()
                    renderCurrentTab()
                    Toast.makeText(
                        this@MainActivity,
                        if (isArabic) "✓ تم التحقق من سلامة النسخة واستعادة بياناتك بنجاح!" else "✓ Backup validated and restored!",
                        Toast.LENGTH_LONG
                    ).show()
                    dialog.dismiss()
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        if (isArabic) "⚠️ ملف النسخة الاحتياطية غير صالح أو تالف؛ تم الحفاظ على بياناتك الحالية بأمان."
                        else "⚠️ Invalid backup format; existing data kept safe.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
        view.addView(btnRestore)

        dialog.setContentView(view)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.90).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
    }

    private fun showManageCustomQuotesDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = createPillDrawable(bgCardColor(), dp(20), "#8B5CF6")
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        view.addView(TextView(this).apply {
            text = if (isArabic) "✍️ عباراتي التحفيزية" else "✍️ Custom Motivational Quotes"
            setTextColor(textPrimaryColor())
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
        })

        val etQuote = EditText(this).apply {
            hint = if (isArabic) "اكتب عبارة تشجعك قبل المهام..." else "Write a motivational quote..."
            setHintTextColor(textSecondaryColor())
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(10)
            }
        }
        view.addView(etQuote)

        val btnAdd = Button(this).apply {
            text = if (isArabic) "+ إضافة العبارة" else "+ Add Quote"
            isAllCaps = false
            setTextColor(Color.parseColor("#0B0F19"))
            backgroundTintList = ColorStateList.valueOf(accentPrimaryColor())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
                bottomMargin = dp(8)
            }
            setOnClickListener {
                val q = etQuote.text.toString().trim()
                if (q.isNotEmpty()) {
                    ReminderRepository.addCustomQuote(this@MainActivity, q)
                    Toast.makeText(this@MainActivity, if (isArabic) "✓ تمت الإضافة" else "✓ Quote saved", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
            }
        }
        view.addView(btnAdd)

        val existing = ReminderRepository.getCustomQuotes(this)
        existing.take(4).forEach { q ->
            val qRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }
            qRow.addView(TextView(this).apply {
                text = "• $q"
                setTextColor(textSecondaryColor())
                textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            qRow.addView(TextView(this).apply {
                text = "🗑️"
                setPadding(dp(8), 0, dp(4), 0)
                setOnClickListener {
                    ReminderRepository.deleteCustomQuote(this@MainActivity, q)
                    dialog.dismiss()
                    showManageCustomQuotesDialog()
                }
            })
            view.addView(qRow)
        }

        dialog.setContentView(view)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.90).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
    }

    // =========================================================================
    // 9. نافذة إضافة / تعديل المهمة المحسنة (Section 6.6: الحقول الأساسية أولاً + خيارات إضافية قابلة للتوسيع)
    // =========================================================================

    private fun showAddOrEditTaskDialog(existingItem: ReminderItem?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val scroll = ScrollView(this).apply {
            background = createPillDrawable(bgCardColor(), dp(22), currentAccentColor)
        }

        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        view.addView(TextView(this).apply {
            text = if (existingItem == null) (if (isArabic) "➕ إضافة مهمة جديدة" else "➕ New Task")
            else (if (isArabic) "✏️ تعديل المهمة" else "✏️ Edit Task")
            setTextColor(textPrimaryColor())
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
        })

        // ١. الحقول الأساسية: اسم المهمة • الوقت • الأولوية
        val etTitle = EditText(this).apply {
            hint = if (isArabic) "اسم المهمة (مطلوب)..." else "Task title (required)..."
            setText(existingItem?.title ?: "")
            setHintTextColor(textSecondaryColor())
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(12)
            }
        }
        view.addView(etTitle)

        var taskHour = existingItem?.hour ?: selectedHour
        var taskMinute = existingItem?.minute ?: selectedMinute
        val calNow = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, taskHour)
            set(Calendar.MINUTE, taskMinute)
        }

        val btnTime = TextView(this).apply {
            text = "⏰ " + (if (isArabic) "وقت التذكير: " else "Time: ") + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(calNow.time)
            textSize = 14f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), currentAccentColor)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)).apply {
                topMargin = dp(10)
            }
            setOnClickListener {
                TimePickerDialog(this@MainActivity, { _, h, m ->
                    taskHour = h
                    taskMinute = m
                    val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m) }
                    text = "⏰ " + (if (isArabic) "وقت التذكير: " else "Time: ") + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(c.time)
                }, taskHour, taskMinute, false).show()
            }
        }
        view.addView(btnTime)

        var chosenPriority = existingItem?.priority ?: "medium"
        val pRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, dp(6))
        }
        val priorityButtons = mutableListOf<Pair<String, TextView>>()
        val priorities = listOf(
            Triple("high", if (isArabic) "عالية" else "High", "#FB7185"),
            Triple("medium", if (isArabic) "متوسطة" else "Medium", "#FBBF24"),
            Triple("low", if (isArabic) "منخفضة" else "Low", "#10B981")
        )

        fun refreshPriorityChips() {
            priorityButtons.forEach { (key, tv) ->
                val isSel = (key == chosenPriority)
                tv.setTextColor(if (isSel) Color.parseColor("#0B0F19") else textPrimaryColor())
                val cHex = when (key) {
                    "high" -> "#FB7185"
                    "medium" -> "#FBBF24"
                    else -> "#10B981"
                }
                tv.background = createPillDrawable(if (isSel) Color.parseColor(cHex) else bgElevatedColor(), dp(12), cHex)
            }
        }

        priorities.forEach { (key, label, _) ->
            val tv = TextView(this).apply {
                text = label
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(6) }
                setOnClickListener {
                    chosenPriority = key
                    refreshPriorityChips()
                }
            }
            priorityButtons.add(key to tv)
            pRow.addView(tv)
        }
        refreshPriorityChips()
        view.addView(pRow)

        // ٢. قسم الخيارات الإضافية القابل للتوسيع (الوصف • التصنيف • المدة المتوقعة • التكرار • تفعيل التذكير)
        val extraContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (existingItem != null) View.VISIBLE else View.GONE
            setPadding(0, dp(8), 0, 0)
        }

        val btnToggleExtras = TextView(this).apply {
            text = if (isArabic) "⚙️ خيارات إضافية (الوصف، التصنيف، المدة المتوقعة) ▾" else "⚙️ More Options (Description, Category, Duration) ▾"
            setTextColor(accentPrimaryColor())
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(4))
            setOnClickListener {
                extraContainer.visibility = if (extraContainer.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        }
        view.addView(btnToggleExtras)

        val etDesc = EditText(this).apply {
            hint = if (isArabic) "وصف أو ملاحظات للمهمة (اختياري)..." else "Description / notes (optional)..."
            setText(existingItem?.description ?: "")
            setHintTextColor(textSecondaryColor())
            setTextColor(textPrimaryColor())
            textSize = 13f
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        extraContainer.addView(etDesc)

        val etExpectedMins = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = if (isArabic) "المدة المتوقعة بالدقائق (مثال: 25 أو 50)" else "Expected duration in mins (e.g. 25)"
            setText((existingItem?.expectedMinutes ?: 25).toString())
            setHintTextColor(textSecondaryColor())
            setTextColor(textPrimaryColor())
            textSize = 13f
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
            }
        }
        extraContainer.addView(etExpectedMins)

        // اختيار تصنيف مجال الحياة
        var chosenCategory = existingItem?.category ?: "work"
        val catSpinner = Spinner(this).apply {
            val catCodes = listOf("work", "study", "personal", "health", "goals")
            val catNames = catCodes.map { getCategoryDisplayName(it) }
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, catNames)
            setSelection(catCodes.indexOf(chosenCategory).coerceAtLeast(0))
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)).apply {
                topMargin = dp(8)
            }
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    (v as? TextView)?.setTextColor(textPrimaryColor())
                    chosenCategory = catCodes[pos]
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        extraContainer.addView(catSpinner)
        view.addView(extraContainer)

        val btnSave = Button(this).apply {
            text = if (isArabic) "حفظ المهمة" else "Save Task"
            isAllCaps = false
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#0B0F19"))
            backgroundTintList = ColorStateList.valueOf(accentPrimaryColor())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)).apply {
                topMargin = dp(16)
            }
            setOnClickListener {
                val title = etTitle.text.toString().trim()
                if (title.isEmpty()) {
                    Toast.makeText(this@MainActivity, if (isArabic) "يرجى كتابة اسم المهمة" else "Please enter task title", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val expMins = etExpectedMins.text.toString().toIntOrNull()?.coerceIn(1, 480) ?: 25
                val item = (existingItem ?: ReminderItem(
                    id = UUID.randomUUID().toString(),
                    title = title,
                    isHabit = false,
                    hour = taskHour,
                    minute = taskMinute,
                    dueDateEpochDay = ReminderRepository.currentEpochDay()
                )).copy(
                    title = title,
                    description = etDesc.text.toString().trim(),
                    hour = taskHour,
                    minute = taskMinute,
                    priority = chosenPriority,
                    category = chosenCategory,
                    expectedMinutes = expMins
                )

                ReminderRepository.addOrUpdateItem(this@MainActivity, item)
                AlarmScheduler.scheduleNextOccurrence(this@MainActivity, item)
                dialog.dismiss()
                renderCurrentTab()
            }
        }
        view.addView(btnSave)

        scroll.addView(view)
        dialog.setContentView(scroll)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
    }

    // نافذة إضافة / تعديل العادة (Section 5.1 & 5.3)
    private fun showAddOrEditHabitDialog(existingHabit: ReminderItem?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val scroll = ScrollView(this).apply {
            background = createPillDrawable(bgCardColor(), dp(22), "#8B5CF6")
        }

        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        val isEditingExisting = existingHabit != null && existingHabit.id.isNotBlank()
        view.addView(TextView(this).apply {
            text = if (isEditingExisting) (if (isArabic) "✏️ تعديل العادة" else "✏️ Edit Habit")
            else (if (isArabic) "🌱 إضافة عادة جديدة" else "🌱 New Daily Habit")
            setTextColor(textPrimaryColor())
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
        })

        val etTitle = EditText(this).apply {
            hint = if (isArabic) "اسم العادة (مثال: قراءة 10 صفحات)..." else "Habit name..."
            setText(existingHabit?.title ?: "")
            setHintTextColor(textSecondaryColor())
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(12)
            }
        }
        view.addView(etTitle)

        // الهدف الرقمي ووحدة القياس (Section 5.3)
        val targetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, 0)
        }

        val etTargetVal = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = if (isArabic) "الهدف (مثال: 10)" else "Goal (e.g. 10)"
            setText((existingHabit?.targetValue ?: 1).toString())
            setHintTextColor(textSecondaryColor())
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) }
        }

        val etTargetUnit = EditText(this).apply {
            hint = if (isArabic) "الوحدة (صفحات / أكواب)" else "Unit (pages / cups)"
            setText(existingHabit?.targetUnit ?: "")
            setHintTextColor(textSecondaryColor())
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        targetRow.addView(etTargetVal)
        targetRow.addView(etTargetUnit)
        view.addView(targetRow)

        // التكرار (يوميًا / أيام محددة من الأسبوع)
        var chosenRecurrence = existingHabit?.recurrence ?: "daily"
        val recRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, 0)
        }
        val btnDaily = TextView(this).apply {
            text = if (isArabic) "يوميًا" else "Daily"
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#0B0F19"))
            background = createPillDrawable(accentPrimaryColor(), dp(12), null)
            layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(6) }
        }
        val btnWeekly = TextView(this).apply {
            text = if (isArabic) "أيام محددة" else "Specific Days"
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), null)
            layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f)
        }
        btnDaily.setOnClickListener {
            chosenRecurrence = "daily"
            btnDaily.background = createPillDrawable(accentPrimaryColor(), dp(12), null)
            btnDaily.setTextColor(Color.parseColor("#0B0F19"))
            btnWeekly.background = createPillDrawable(bgElevatedColor(), dp(12), null)
            btnWeekly.setTextColor(textPrimaryColor())
        }
        btnWeekly.setOnClickListener {
            chosenRecurrence = "weekly"
            btnWeekly.background = createPillDrawable(accentPrimaryColor(), dp(12), null)
            btnWeekly.setTextColor(Color.parseColor("#0B0F19"))
            btnDaily.background = createPillDrawable(bgElevatedColor(), dp(12), null)
            btnDaily.setTextColor(textPrimaryColor())
        }
        recRow.addView(btnDaily)
        recRow.addView(btnWeekly)
        view.addView(recRow)

        var habitHour = existingHabit?.hour ?: selectedHour
        var habitMinute = existingHabit?.minute ?: selectedMinute
        val calHabit = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, habitHour); set(Calendar.MINUTE, habitMinute) }

        val btnPickHabitTime = TextView(this).apply {
            text = "⏰ " + (if (isArabic) "وقت التذكير اليومي: " else "Reminder: ") + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(calHabit.time)
            textSize = 14f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textPrimaryColor())
            background = createPillDrawable(bgElevatedColor(), dp(12), "#8B5CF6")
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)).apply {
                topMargin = dp(10)
            }
            setOnClickListener {
                TimePickerDialog(this@MainActivity, { _, h, m ->
                    habitHour = h
                    habitMinute = m
                    val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m) }
                    text = "⏰ " + (if (isArabic) "وقت التذكير اليومي: " else "Reminder: ") + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(c.time)
                }, habitHour, habitMinute, false).show()
            }
        }
        view.addView(btnPickHabitTime)

        val btnSave = Button(this).apply {
            text = if (isArabic) "حفظ العادة" else "Save Habit"
            isAllCaps = false
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#0B0F19"))
            backgroundTintList = ColorStateList.valueOf(accentPrimaryColor())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)).apply {
                topMargin = dp(14)
            }
            setOnClickListener {
                val t = etTitle.text.toString().trim()
                if (t.isEmpty()) {
                    Toast.makeText(this@MainActivity, if (isArabic) "يرجى كتابة اسم العادة" else "Enter habit title", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val targetNum = etTargetVal.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1
                val unitStr = etTargetUnit.text.toString().trim()

                val habit = if (isEditingExisting && existingHabit != null) {
                    existingHabit.copy(
                        title = t,
                        hour = habitHour,
                        minute = habitMinute,
                        targetValue = targetNum,
                        targetUnit = unitStr,
                        recurrence = chosenRecurrence
                    )
                } else {
                    ReminderItem(
                        id = UUID.randomUUID().toString(),
                        title = t,
                        isHabit = true,
                        hour = habitHour,
                        minute = habitMinute,
                        streakCount = 1,
                        longestStreak = 1,
                        streakGoal = 7,
                        priority = "medium",
                        category = "health",
                        targetValue = targetNum,
                        targetUnit = unitStr,
                        recurrence = chosenRecurrence
                    )
                }
                ReminderRepository.addOrUpdateItem(this@MainActivity, habit)
                AlarmScheduler.scheduleNextOccurrence(this@MainActivity, habit)
                dialog.dismiss()
                renderCurrentTab()
            }
        }
        view.addView(btnSave)

        scroll.addView(view)
        dialog.setContentView(scroll)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
    }

    // =========================================================================
    // 10. دوال مساعدة للتصميم الهادئ الموحد (Section 2)
    // =========================================================================

    private fun getCategoryDisplayName(code: String): String {
        return when (code) {
            "work" -> if (isArabic) "💼 العمل" else "💼 Work"
            "study" -> if (isArabic) "📚 الدراسة" else "📚 Study"
            "personal" -> if (isArabic) "🏠 شخصية" else "🏠 Personal"
            "health" -> if (isArabic) "💪 الصحة" else "💪 Health"
            "goals" -> if (isArabic) "🎯 الأهداف" else "🎯 Goals"
            else -> if (isArabic) "عام" else "General"
        }
    }

    private fun buildEmptyStateCard(title: String, subtitle: String, btnText: String, onClick: () -> Unit): View {
        return createCalmCard().apply {
            gravity = Gravity.CENTER
            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(textPrimaryColor())
                textSize = 18f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
            })
            addView(TextView(this@MainActivity).apply {
                text = subtitle
                setTextColor(textSecondaryColor())
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(6), dp(8), dp(14))
            })
            addView(TextView(this@MainActivity).apply {
                text = btnText
                textSize = 14f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#0B0F19"))
                background = createPillDrawable(accentPrimaryColor(), dp(14), null)
                setPadding(dp(20), dp(12), dp(20), dp(12))
                setOnClickListener { onClick() }
            })
        }
    }

    private fun createCalmCard(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(bgCardColor())
                setStroke(dp(1), Color.parseColor("#2694A3B8"))
            }
            val pad = dp(16)
            setPadding(pad, pad, pad, pad)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(12) }
        }
    }

    private fun createPillDrawable(fillColor: Int, radiusPx: Int, strokeColorHex: String?): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(fillColor)
            if (strokeColorHex != null) {
                setStroke(dp(1), Color.parseColor(strokeColorHex))
            }
        }
    }

    private fun createSectionHeader(title: String): TextView {
        return TextView(this).apply {
            text = title
            setTextColor(accentPrimaryColor())
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(16), 0, dp(8))
        }
    }

    private fun requestOverlayPermission() {
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        startActivity(intent)
    }

    private fun triggerGentleHaptic() {
        try {
            val prefs = getSharedPreferences("waqt_prefs", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("pref_haptics", true)) return
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                manager.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (vibrator.hasVibrator()) {
                vibrator.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (_: Exception) {
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    // =========================================================================
    // كلاس رسم المؤقت الدائري المتوازن (200dp - Section 4.1)
    // =========================================================================

    inner class CircularTimerRingView(context: Context) : View(context) {
        private var progressFraction: Float = 1f
        private var timeString: String = "25:00"

        private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(10).toFloat()
            color = bgElevatedColor()
            strokeCap = Paint.Cap.ROUND
        }

        private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(10).toFloat()
            color = accentPrimaryColor()
            strokeCap = Paint.Cap.ROUND
        }

        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textPrimaryColor()
            textSize = dp(38).toFloat()
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }

        private val subTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textSecondaryColor()
            textSize = dp(12).toFloat()
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }

        private val ovalRect = RectF()

        fun updateTimerDisplay(remainingMs: Long, totalMs: Long) {
            progressFraction = if (totalMs > 0) (remainingMs.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f) else 0f
            val totalSec = (remainingMs / 1000L).coerceAtLeast(0L)
            val m = totalSec / 60L
            val s = totalSec % 60L
            timeString = String.format(Locale.US, "%02d:%02d", m, s)
            trackPaint.color = bgElevatedColor()
            progressPaint.color = if (isBreakSession) successColor() else accentPrimaryColor()
            textPaint.color = textPrimaryColor()
            subTextPaint.color = textSecondaryColor()
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val pad = dp(14).toFloat()
            ovalRect.set(pad, pad, width - pad, height - pad)

            canvas.drawArc(ovalRect, 0f, 360f, false, trackPaint)

            val sweepAngle = 360f * progressFraction
            canvas.drawArc(ovalRect, -90f, sweepAngle, false, progressPaint)

            val centerX = width / 2f
            val centerY = (height / 2f) - ((textPaint.descent() + textPaint.ascent()) / 2f) - dp(6)
            canvas.drawText(timeString, centerX, centerY, textPaint)

            val label = when {
                isBreakSession -> if (isArabic) "☕ فترة راحة" else "☕ BREAK TIME"
                isPomodoroRunning -> if (isArabic) "🔥 جلسة تركيز نشطة" else "🔥 FOCUS ACTIVE"
                else -> if (isArabic) "جاهز للبدء" else "READY TO FOCUS"
            }
            canvas.drawText(label, centerX, centerY + dp(24), subTextPaint)
        }
    }
}
