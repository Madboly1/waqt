package com.example.glassproductivity

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.AudioManager
import android.util.Base64
import org.json.JSONObject
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Full-duplex Gemini Live voice session: continuous PCM mic stream + streamed PCM speech playback. */
class GeminiLiveVoiceSession(
    private val apiKey: String,
    private val systemInstruction: String,
    private val listener: Listener
) {
    interface Listener {
        fun onStatus(status: String)
        fun onUserTranscript(text: String)
        fun onAssistantTranscript(text: String)
        fun onError(message: String)
        fun onClosed()
    }

    companion object {
        private const val MODEL = "gemini-3.8-live"
        private const val INPUT_RATE = 16000
        private const val OUTPUT_RATE = 24000
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
    private val running = AtomicBoolean(false)
    @Volatile private var socket: WebSocket? = null
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var track: AudioTrack? = null
    private var micThread: Thread? = null

    fun start() {
        if (running.getAndSet(true)) return
        listener.onStatus("جاري الاتصال بالمساعد الصوتي…")
        val request = Request.Builder()
            .url("wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=${apiKey.trim()}")
            .build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val setup = JSONObject().put("setup", JSONObject()
                    .put("model", "models/$MODEL")
                    .put("generationConfig", JSONObject().put("responseModalities", org.json.JSONArray().put("AUDIO")))
                    .put("systemInstruction", JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", systemInstruction))))
                    .put("inputAudioTranscription", JSONObject())
                    .put("outputAudioTranscription", JSONObject()))
                webSocket.send(setup.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val root = JSONObject(text)
                    if (root.has("setupComplete")) {
                        listener.onStatus("متصل — اتكلم براحتك، وتقدر تقاطعه في أي وقت")
                        startMicrophone()
                        return
                    }
                    val content = root.optJSONObject("serverContent") ?: return
                    content.optJSONObject("inputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let(listener::onUserTranscript)
                    content.optJSONObject("outputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let(listener::onAssistantTranscript)
                    if (content.optBoolean("interrupted", false)) {
                        try { track?.pause(); track?.flush(); track?.play() } catch (_: Exception) { }
                    }
                    val parts = content.optJSONObject("modelTurn")?.optJSONArray("parts")
                    if (parts != null) for (i in 0 until parts.length()) {
                        val part = parts.optJSONObject(i) ?: continue
                        val inline = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data")
                        val data = inline?.optString("data").orEmpty()
                        if (data.isNotBlank()) playAudio(Base64.decode(data, Base64.DEFAULT))
                    }
                    if (content.optBoolean("turnComplete", false)) listener.onStatus("مستنيك تكمل…")
                } catch (e: Exception) {
                    listener.onError("تعذر قراءة رد المحادثة الصوتية: ${e.message ?: ""}")
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                listener.onError("تعذر الاتصال بالمحادثة الصوتية: ${t.message ?: "تحقق من الإنترنت ومفتاح Gemini"}")
                stop()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                stopResources()
                listener.onClosed()
            }
        })
    }

    private fun startMicrophone() {
        if (!running.get() || micThread != null) return
        val min = AudioRecord.getMinBufferSize(INPUT_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { listener.onError("الميكروفون غير مدعوم على الجهاز"); stop(); return }
        val bufferSize = maxOf(min, INPUT_RATE / 5 * 2)
        try {
            val audioRecord = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, INPUT_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
            if (audioRecord.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("تعذر تشغيل الميكروفون")
            recorder = audioRecord
            audioRecord.startRecording()
            micThread = Thread {
                val chunk = ByteArray(3200) // 100 ms at 16 kHz, mono, PCM16
                while (running.get()) {
                    val count = try { audioRecord.read(chunk, 0, chunk.size) } catch (_: Exception) { -1 }
                    if (count > 0 && running.get()) {
                        val encoded = Base64.encodeToString(chunk.copyOf(count), Base64.NO_WRAP)
                        val message = JSONObject().put("realtimeInput", JSONObject().put("audio",
                            JSONObject().put("data", encoded).put("mimeType", "audio/pcm;rate=16000")))
                        if (socket?.send(message.toString()) != true) break
                    }
                }
            }.apply { name = "waqt-live-microphone"; start() }
        } catch (e: Exception) {
            listener.onError("تعذر بدء الميكروفون: ${e.message ?: ""}")
            stop()
        }
    }

    @Synchronized private fun playAudio(pcm: ByteArray) {
        try {
            var audioTrack = track
            if (audioTrack == null) {
                val min = AudioTrack.getMinBufferSize(OUTPUT_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(OUTPUT_RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                    .setBufferSizeInBytes(maxOf(min, OUTPUT_RATE * 2))
                    .setTransferMode(AudioTrack.MODE_STREAM).build()
                track = audioTrack
                audioTrack.play()
            }
            var offset = 0
            while (offset < pcm.size && running.get()) {
                val written = audioTrack.write(pcm, offset, pcm.size - offset)
                if (written <= 0) break
                offset += written
            }
        } catch (e: Exception) { listener.onError("مشكلة في تشغيل صوت المساعد: ${e.message ?: ""}") }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        try { socket?.close(1000, "User ended voice chat") } catch (_: Exception) { }
        socket = null
        stopResources()
        listener.onClosed()
    }

    private fun stopResources() {
        running.set(false)
        try { recorder?.stop() } catch (_: Exception) { }
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null
        micThread = null
        try { track?.pause(); track?.flush(); track?.stop(); track?.release() } catch (_: Exception) { }
        track = null
    }
}
