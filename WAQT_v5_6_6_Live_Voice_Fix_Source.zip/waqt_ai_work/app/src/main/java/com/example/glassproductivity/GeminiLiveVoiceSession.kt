package com.example.glassproductivity

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Gemini Live session. Microphone streaming starts only after setupComplete. */
class GeminiLiveVoiceSession(
    private val apiKey: String,
    private val systemInstruction: String,
    private val listener: Listener
) {
    interface Listener {
        fun onStatus(status: String)
        fun onUserTranscript(text: String)
        fun onAssistantTranscript(text: String)
        fun onError(message: String)
        fun onClosed()
    }

    companion object {
        private const val MODEL = "gemini-3.8-live"
        private const val INPUT_RATE = 16000
        private const val OUTPUT_RATE = 24000
        private const val CONNECT_TIMEOUT_SECONDS = 15L
        private const val SETUP_TIMEOUT_SECONDS = 20L
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val running = AtomicBoolean(false)
    private val setupReady = AtomicBoolean(false)
    private val terminalCallbackSent = AtomicBoolean(false)
    private val scheduler: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()

    @Volatile private var socket: WebSocket? = null
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var track: AudioTrack? = null
    @Volatile private var micThread: Thread? = null
    @Volatile private var setupTimeout: java.util.concurrent.ScheduledFuture<*>? = null

    fun start() {
        if (!running.compareAndSet(false, true)) return
        if (apiKey.isBlank()) {
            fail("مفتاح Gemini غير موجود. افتح إعدادات المساعد وأضف API Key صحيح.")
            return
        }

        listener.onStatus("جاري فتح الاتصال بـ Gemini…")
        val url = try {
            HttpUrl.Builder()
                .scheme("wss")
                .host("generativelanguage.googleapis.com")
                .addPathSegments("ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent")
                .addQueryParameter("key", apiKey.trim())
                .build()
        } catch (e: Exception) {
            fail("تعذر تجهيز عنوان الاتصال: ${e.message ?: "عنوان غير صالح"}")
            return
        }

        val request = Request.Builder().url(url).build()
        setupTimeout = scheduler.schedule({
            if (running.get() && !setupReady.get()) {
                fail("انتهت مهلة تجهيز Gemini (20 ثانية). لم تصل رسالة setupComplete؛ تحقق من الإنترنت ومفتاح API وصلاحية Live API.")
            }
        }, SETUP_TIMEOUT_SECONDS, TimeUnit.SECONDS)

        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (!running.get()) {
                    webSocket.close(1000, "Session already stopped")
                    return
                }
                listener.onStatus("تم فتح القناة — جاري تجهيز جلسة الصوت…")
                val setup = JSONObject().put("setup", JSONObject()
                    .put("model", "models/$MODEL")
                    .put("generationConfig", JSONObject()
                        .put("responseModalities", JSONArray().put("AUDIO")))
                    .put("systemInstruction", JSONObject()
                        .put("parts", JSONArray().put(JSONObject().put("text", systemInstruction))))
                    .put("inputAudioTranscription", JSONObject())
                    .put("outputAudioTranscription", JSONObject()))

                if (!webSocket.send(setup.toString())) {
                    fail("تم فتح الاتصال لكن تعذر إرسال إعدادات جلسة الصوت.")
                } else {
                    listener.onStatus("تم إرسال الإعدادات — في انتظار تأكيد Gemini…")
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (!running.get()) return
                try {
                    val root = JSONObject(text)
                    if (root.has("error")) {
                        val error = root.optJSONObject("error")
                        val code = error?.optInt("code", 0) ?: 0
                        val message = error?.optString("message").orEmpty().ifBlank { text.take(500) }
                        fail("Gemini رفض جلسة الصوت${if (code > 0) " ($code)" else ""}: $message")
                        return
                    }
                    if (root.has("setupComplete")) {
                        if (setupReady.compareAndSet(false, true)) {
                            setupTimeout?.cancel(false)
                            listener.onStatus("متصل — اتكلم براحتك")
                            startMicrophone()
                        }
                        return
                    }

                    // Transcriptions can be top-level or nested in serverContent, depending on API version.
                    emitTranscript(root.optJSONObject("inputTranscription")?.optString("text"), true)
                    emitTranscript(root.optJSONObject("outputTranscription")?.optString("text"), false)
                    val content = root.optJSONObject("serverContent") ?: return
                    emitTranscript(content.optJSONObject("inputTranscription")?.optString("text"), true)
                    emitTranscript(content.optJSONObject("outputTranscription")?.optString("text"), false)

                    if (content.optBoolean("interrupted", false)) {
                        try { track?.pause(); track?.flush(); track?.play() } catch (_: Exception) { }
                    }
                    val parts = content.optJSONObject("modelTurn")?.optJSONArray("parts")
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val part = parts.optJSONObject(i) ?: continue
                            val inline = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data")
                            val data = inline?.optString("data").orEmpty()
                            if (data.isNotBlank()) {
                                try { playAudio(Base64.decode(data, Base64.DEFAULT)) }
                                catch (e: Exception) { listener.onError("تعذر فك صوت المساعد: ${e.message ?: "بيانات صوت غير صالحة"}") }
                            }
                        }
                    }
                    if (content.optBoolean("turnComplete", false)) listener.onStatus("مستنيك تكمل…")
                } catch (e: Exception) {
                    listener.onError("تعذر قراءة رسالة Gemini: ${e.message ?: "صيغة رد غير مفهومة"}")
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                // The Gemini Live JSON protocol is expected as text frames. Keep binary frames visible in diagnostics.
                listener.onError("وصلت رسالة صوتية بصيغة غير متوقعة من الخادم؛ لم يتم تجاهلها بصمت.")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val httpCode = response?.code
                val body = try { response?.peekBody(2048)?.string().orEmpty() } catch (_: Exception) { "" }
                val details = when {
                    httpCode != null -> "HTTP $httpCode${if (body.isNotBlank()) ": ${body.take(450)}" else ""}"
                    else -> t.localizedMessage ?: t.javaClass.simpleName
                }
                fail("فشل اتصال Gemini Live: $details")
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                listener.onStatus("Gemini بيقفل الاتصال ($code): ${reason.ifBlank { "بدون تفاصيل" }}")
                webSocket.close(code, reason)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                cleanupResources()
                notifyClosedOnce()
            }
        })
    }

    private fun emitTranscript(value: String?, isUser: Boolean) {
        val text = value?.trim().orEmpty()
        if (text.isNotBlank()) {
            if (isUser) listener.onUserTranscript(text) else listener.onAssistantTranscript(text)
        }
    }

    private fun startMicrophone() {
        if (!running.get() || !setupReady.get() || micThread != null) return
        val minBuffer = AudioRecord.getMinBufferSize(
            INPUT_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            fail("الجهاز لم يستطع تجهيز الميكروفون (AudioRecord buffer=$minBuffer).")
            return
        }
        try {
            val bufferSize = maxOf(minBuffer, INPUT_RATE / 5 * 2)
            val audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                INPUT_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
            if (audioRecord.state != AudioRecord.STATE_INITIALIZED) {
                audioRecord.release()
                throw IllegalStateException("تعذر تهيئة الميكروفون")
            }
            recorder = audioRecord
            audioRecord.startRecording()
            if (audioRecord.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                throw IllegalStateException("الميكروفون لم يبدأ التسجيل")
            }
            micThread = Thread {
                val chunk = ByteArray(3200) // 100 ms, 16 kHz, mono, PCM16
                try {
                    while (running.get() && setupReady.get()) {
                        val count = audioRecord.read(chunk, 0, chunk.size)
                        if (count == AudioRecord.ERROR_INVALID_OPERATION || count == AudioRecord.ERROR_BAD_VALUE || count < 0) {
                            throw IllegalStateException("AudioRecord.read error=$count")
                        }
                        if (count > 0 && running.get()) {
                            val encoded = Base64.encodeToString(chunk.copyOf(count), Base64.NO_WRAP)
                            val message = JSONObject().put("realtimeInput", JSONObject().put("audio",
                                JSONObject().put("data", encoded).put("mimeType", "audio/pcm;rate=16000")))
                            if (socket?.send(message.toString()) != true) {
                                throw IllegalStateException("قناة الاتصال أغلقت أثناء إرسال الصوت")
                            }
                        }
                    }
                } catch (e: Exception) {
                    if (running.get()) fail("مشكلة أثناء إرسال صوت الميكروفون: ${e.message ?: "خطأ غير معروف"}")
                }
            }.apply { name = "waqt-live-microphone"; start() }
        } catch (e: SecurityException) {
            fail("إذن الميكروفون غير متاح. اسمح لـ WAQT باستخدام الميكروفون ثم حاول مرة أخرى.")
        } catch (e: Exception) {
            fail("تعذر بدء الميكروفون: ${e.message ?: "خطأ غير معروف"}")
        }
    }

    @Synchronized private fun playAudio(pcm: ByteArray) {
        if (!running.get() || pcm.isEmpty()) return
        try {
            var audioTrack = track
            if (audioTrack == null) {
                val min = AudioTrack.getMinBufferSize(
                    OUTPUT_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                if (min <= 0) throw IllegalStateException("تعذر تجهيز مخرج الصوت ($min)")
                audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder()
                        .setSampleRate(OUTPUT_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                    .setBufferSizeInBytes(maxOf(min, OUTPUT_RATE * 2))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                if (audioTrack.state != AudioTrack.STATE_INITIALIZED) {
                    audioTrack.release()
                    throw IllegalStateException("تعذر تهيئة مخرج الصوت")
                }
                track = audioTrack
                audioTrack.play()
            }
            var offset = 0
            while (offset < pcm.size && running.get()) {
                val written = audioTrack.write(pcm, offset, pcm.size - offset)
                if (written <= 0) throw IllegalStateException("AudioTrack.write error=$written")
                offset += written
            }
        } catch (e: Exception) {
            listener.onError("مشكلة في تشغيل صوت المساعد: ${e.message ?: "خطأ غير معروف"}")
        }
    }

    private fun fail(message: String) {
        if (!running.getAndSet(false)) return
        setupTimeout?.cancel(false)
        listener.onError(message)
        try { socket?.close(1011, "Live session failed") } catch (_: Exception) { }
        socket = null
        cleanupResources()
        notifyClosedOnce()
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        setupTimeout?.cancel(false)
        try { socket?.close(1000, "User ended voice chat") } catch (_: Exception) { }
        socket = null
        cleanupResources()
        notifyClosedOnce()
    }

    private fun cleanupResources() {
        running.set(false)
        setupTimeout?.cancel(false)
        try { recorder?.stop() } catch (_: Exception) { }
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null
        micThread = null
        try { track?.pause(); track?.flush(); track?.stop(); track?.release() } catch (_: Exception) { }
        track = null
        try { scheduler.shutdownNow() } catch (_: Exception) { }
    }

    private fun notifyClosedOnce() {
        if (terminalCallbackSent.compareAndSet(false, true)) listener.onClosed()
    }
}
