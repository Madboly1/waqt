package com.example.glassproductivity

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.Random
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Synthesizes every sound procedurally (no audio files needed):
 * ambient scenes (rain, sea, fire...), a real tick-tock clock, and a completion chime.
 */
class SoundEngine {
    private val sr = 22050

    @Volatile private var ambientRunning = false
    @Volatile private var tickRunning = false
    @Volatile private var ambientVolume = 0.7f
    @Volatile private var tickVolume = 0.7f
    private var ambientTrack: AudioTrack? = null
    private var tickTrack: AudioTrack? = null
    private val lock = Any()

    private fun newTrack(bufferBytes: Int, mode: Int = AudioTrack.MODE_STREAM): AudioTrack =
        AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(mode)
            .build()

    // ---------------------------------------------------------------- ambient

    fun startAmbient(kind: Int, volume: Float) {
        stopAmbient()
        if (kind <= 0) return
        ambientVolume = volume
        val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val chunk = 2048
        val track = try { newTrack(maxOf(minBuf, chunk * 4)) } catch (_: Exception) { return }
        synchronized(lock) { ambientTrack = track }
        ambientRunning = true
        try { track.play() } catch (_: Exception) { ambientRunning = false; return }
        thread(name = "waqt-ambient") {
            val gen = AmbientGenerator(kind, sr)
            val buf = ShortArray(chunk)
            while (ambientRunning && ambientTrack === track) {
                val v = ambientVolume
                for (i in buf.indices) {
                    val x = (gen.next() * v).coerceIn(-1f, 1f)
                    buf[i] = (x * 30000f).toInt().toShort()
                }
                try {
                    if (track.write(buf, 0, buf.size) < 0) break
                } catch (_: Exception) { break }
            }
        }
    }

    fun setAmbientVolume(v: Float) {
        ambientVolume = v
        tickVolume = v
    }

    fun stopAmbient() {
        ambientRunning = false
        val t: AudioTrack?
        synchronized(lock) { t = ambientTrack; ambientTrack = null }
        killTrack(t)
    }

    // ---------------------------------------------------------------- tick-tock

    fun startTick(volume: Float) {
        tickVolume = volume
        if (tickRunning) return
        val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val second = buildTickSecond()
        val track = try { newTrack(maxOf(minBuf, second.size * 2)) } catch (_: Exception) { return }
        synchronized(lock) { tickTrack = track }
        tickRunning = true
        try { track.play() } catch (_: Exception) { tickRunning = false; return }
        thread(name = "waqt-tick") {
            val out = ShortArray(second.size)
            while (tickRunning && tickTrack === track) {
                val v = tickVolume.coerceIn(0.1f, 1f)
                for (i in out.indices) out[i] = (second[i] * v).toInt().toShort()
                try {
                    if (track.write(out, 0, out.size) < 0) break
                } catch (_: Exception) { break }
            }
        }
    }

    fun stopTick() {
        tickRunning = false
        val t: AudioTrack?
        synchronized(lock) { t = tickTrack; tickTrack = null }
        killTrack(t)
    }

    /** One second of audio: "tick" at 0.0s and a lower "tock" at 0.5s. */
    private fun buildTickSecond(): ShortArray {
        val out = FloatArray(sr)
        fun click(at: Int, freq: Double, amp: Float) {
            val len = (sr * 0.06).toInt()
            val r = Random(at.toLong())
            for (i in 0 until len) {
                if (at + i >= out.size) break
                val t = i.toDouble() / sr
                val env = exp(-t * 90.0)
                val body = sin(2 * PI * freq * t) * env
                val snap = (r.nextFloat() * 2f - 1f) * exp(-t * 400.0)
                out[at + i] += ((body * 0.8 + snap * 0.5) * amp).toFloat()
            }
        }
        click(0, 1900.0, 0.9f)
        click(sr / 2, 1250.0, 0.75f)
        return ShortArray(sr) { (out[it].coerceIn(-1f, 1f) * 30000f).toInt().toShort() }
    }

    // ---------------------------------------------------------------- chime

    fun playChime(volume: Float = 0.8f) {
        thread(name = "waqt-chime") {
            val notes = doubleArrayOf(659.25, 783.99, 1046.5) // E5 G5 C6
            val noteLen = (sr * 0.45).toInt()
            val total = noteLen * notes.size + sr / 2
            val pcm = ShortArray(total)
            for ((n, f) in notes.withIndex()) {
                val start = n * noteLen
                for (i in 0 until (noteLen + sr / 2).coerceAtMost(total - start)) {
                    val t = i.toDouble() / sr
                    val env = exp(-t * 3.2) * (if (i < 200) i / 200.0 else 1.0)
                    val s = (sin(2 * PI * f * t) + 0.3 * sin(2 * PI * f * 2 * t)) * env
                    val cur = pcm[start + i].toInt()
                    pcm[start + i] = (cur + s * 9000.0 * volume).toInt().coerceIn(-32000, 32000).toShort()
                }
            }
            val track = try { newTrack(total * 2, AudioTrack.MODE_STATIC) } catch (_: Exception) { return@thread }
            try {
                track.write(pcm, 0, pcm.size)
                track.play()
                Thread.sleep((total * 1000L / sr) + 200L)
            } catch (_: Exception) {
            } finally {
                killTrack(track)
            }
        }
    }

    fun release() {
        stopAmbient()
        stopTick()
    }

    private fun killTrack(t: AudioTrack?) {
        if (t == null) return
        try { t.pause() } catch (_: Exception) {}
        try { t.flush() } catch (_: Exception) {}
        try { t.release() } catch (_: Exception) {}
    }
}

/** Per-sample generator. Every scene is a distinct recipe so each sound is truly different. */
private class AmbientGenerator(private val kind: Int, private val sr: Int) {
    private val rnd = Random()
    private var n = 0L

    // filter memories
    private var lpA = 0f; private var lpB = 0f; private var lpC = 0f
    private var brown = 0f
    private var env1 = 0f; private var env2 = 0f
    private var chirpT = -1f; private var chirpF = 0f
    private var voiceT = -1f; private var voiceF = 0f

    private fun noise() = rnd.nextFloat() * 2f - 1f
    private fun chance(perSecond: Float) = rnd.nextFloat() < perSecond / sr
    private fun sinT(freq: Double, t: Double) = sin(2 * PI * freq * t).toFloat()

    private fun wind(t: Double, depth: Float): Float {
        val w = noise()
        lpA += (0.015f + 0.02f * (0.5f + 0.5f * sinT(0.11, t))) * (w - lpA)
        lpB += 0.06f * (lpA - lpB)
        val gust = 0.45f + 0.55f * (0.5f + 0.5f * sinT(0.07, t)) * (0.6f + 0.4f * sinT(0.23, t + 1.7))
        return lpB * 9f * gust * depth
    }

    private fun crickets(t: Double, loud: Float): Float {
        val burst = if ((t * 1.7) % 1.0 < 0.5) 1f else 0f
        val gate = if ((t * 32.0) % 1.0 < 0.45) 1f else 0f
        return sinT(4300.0, t) * burst * gate * loud
    }

    private fun murmur(t: Double, density: Float): Float {
        val w = noise()
        lpA += 0.10f * (w - lpA)
        lpB += 0.35f * (lpA - lpB)
        val syl = (0.5f + 0.5f * sinT(3.9, t)) * (0.5f + 0.5f * sinT(1.37, t + 0.4)) * (0.5f + 0.5f * sinT(0.53, t + 2.0))
        return lpB * 5f * syl * density
    }

    private fun softImpulse(prob: Float, decay: Float, freq: Double, amp: Float, t: Double): Float {
        if (chance(prob)) { env1 = amp * (0.5f + 0.5f * rnd.nextFloat()) }
        val s = sinT(freq * (0.9 + 0.2 * rnd.nextDouble()), t) * env1
        env1 *= decay
        return s
    }

    fun next(): Float {
        val t = n.toDouble() / sr
        n++
        return when (kind) {
            1 -> clockTick(t)
            2 -> countdown(t)
            3 -> wind(t, 0.8f) + crickets(t, 0.10f)
            4 -> murmur(t, 0.7f) + softImpulse(0.25f, 0.9992f, 180.0, 0.25f, t) * 0.4f
            5 -> wilderness(t)
            6 -> stream(t)
            7 -> beach(t)
            8 -> rain(t)
            9 -> cafe(t)
            10 -> fire(t)
            11 -> library(t)
            12 -> wind(t, 1.6f)
            13 -> frogs(t)
            14 -> { brown = (brown + 0.02f * noise()) / 1.02f; brown * 7f }
            else -> 0f
        }
    }

    private fun clockTick(t: Double): Float {
        val phase = t % 1.0
        val local = if (phase < 0.5) phase else phase - 0.5
        val f = if (phase < 0.5) 1900.0 else 1250.0
        if (local > 0.06) return 0f
        return (sinT(f, local) * exp(-local * 90.0).toFloat() * 0.8f + noise() * exp(-local * 400.0).toFloat() * 0.4f)
    }

    private fun countdown(t: Double): Float {
        val phase = t % 1.0
        val beep = if (phase < 0.12) sinT(880.0, t) * (1.0 - phase / 0.12).toFloat() else 0f
        val low = if ((t % 10.0) > 9.0 && (phase in 0.5..0.62)) sinT(660.0, t) * 0.5f else 0f
        return (beep + low) * 0.5f
    }

    private fun wilderness(t: Double): Float {
        val base = wind(t, 0.55f)
        if (chirpT < 0f && chance(0.9f)) { chirpT = 0f; chirpF = 2200f + 1800f * rnd.nextFloat() }
        var bird = 0f
        if (chirpT >= 0f) {
            val dur = 0.14f
            val p = chirpT / dur
            val f = chirpF + 900f * p
            val e = sin(PI * p).toFloat()
            bird = sinT(f.toDouble(), chirpT.toDouble()) * e * 0.18f
            chirpT += 1f / sr
            if (chirpT > dur) chirpT = if (rnd.nextFloat() < 0.5f) 0f else -1f
        }
        return base + bird
    }

    private fun stream(t: Double): Float {
        val w = noise()
        lpA += 0.45f * (w - lpA)
        lpB += 0.05f * (w - lpB)
        val band = lpA - lpB
        val mod = 0.65f + 0.35f * sinT(6.5 + 2.0 * sin(2 * PI * 0.8 * t), t)
        return band * 0.9f * mod
    }

    private fun beach(t: Double): Float {
        val w = noise()
        lpA += 0.18f * (w - lpA)
        val wave = (0.5f + 0.5f * sinT(1.0 / 8.0, t)).let { it * it }
        val foam = (0.5f + 0.5f * sinT(1.0 / 8.0, t + 0.8)).let { it * it * it }
        lpC += 0.5f * (w - lpC)
        return lpA * 3.2f * wave + (w - lpC) * 1.3f * foam * 0.5f
    }

    private fun rain(t: Double): Float {
        val w = noise()
        lpA += 0.5f * (w - lpA)
        val hiss = (w - lpA) * 0.55f
        lpB += 0.03f * (w - lpB)
        val rumble = lpB * 2.2f
        val drop = softImpulse(35f, 0.985f, 2600.0, 0.35f, t) * 0.8f
        return hiss + rumble + drop
    }

    private fun cafe(t: Double): Float {
        val m = murmur(t, 1.0f)
        val clink = if (chance(0.7f)) { env2 = 0.5f; 0f } else 0f
        val c = sinT(3600.0 + 400.0 * sin(t * 3.0), t) * env2 * 0.6f
        env2 *= 0.9993f
        lpC += 0.01f * (noise() - lpC)
        return m + c + lpC * 3f + clink
    }

    private fun fire(t: Double): Float {
        lpA += 0.04f * (noise() - lpA)
        val rumble = lpA * 3.5f
        if (chance(14f)) env1 = 0.4f + 0.6f * rnd.nextFloat()
        val crackle = noise() * env1
        env1 *= 0.955f
        val pop = if (chance(1.5f)) { env2 = 0.9f; 0f } else 0f
        val p = noise() * env2
        env2 *= 0.9f
        return rumble * 0.8f + crackle * 0.7f + p * 0.6f + pop
    }

    private fun library(t: Double): Float {
        lpA += 0.02f * (noise() - lpA)
        val room = lpA * 2.2f
        if (chance(0.12f)) env1 = 0.6f
        lpB += 0.25f * (noise() - lpB)
        val page = (noise() - lpB) * env1 * 0.5f
        env1 *= 0.9997f
        val tick = softImpulse(0.15f, 0.999f, 90.0, 0.25f, t) * 0f
        return room + page + tick + sinT(50.0, t) * 0.02f
    }

    private fun frogs(t: Double): Float {
        val night = crickets(t, 0.05f) + wind(t, 0.3f)
        if (voiceT < 0f && chance(1.1f)) { voiceT = 0f; voiceF = 280f + 120f * rnd.nextFloat() }
        var frog = 0f
        if (voiceT >= 0f) {
            val dur = 0.28f
            val e = sin(PI * (voiceT / dur)).toFloat()
            val am = 0.5f + 0.5f * sinT(38.0, voiceT.toDouble())
            frog = sinT(voiceF.toDouble(), voiceT.toDouble()) * e * am * 0.35f
            voiceT += 1f / sr
            if (voiceT > dur) voiceT = if (rnd.nextFloat() < 0.6f) 0f else -1f
        }
        return night + frog
    }
}
