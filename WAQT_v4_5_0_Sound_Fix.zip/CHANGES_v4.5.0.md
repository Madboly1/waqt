# v4.5.0 — Sound engine + timer fixes
- NEW SoundEngine.kt: 14 distinct synthesized sounds (tick-tock, countdown, wind+crickets, classroom, wilderness, stream, beach, rain, cafe, fire, library, wind, night frogs, brown noise). Previously all of them were the same brown noise.
- FIX: tick-tock toggle only saved a setting and never played anything. It now ticks/tocks while a focus session runs (not during breaks) and stops on pause/finish.
- FIX: break mode could never start (isBreakSession was never set). Now a finished focus session starts a break automatically (every 4th session = longer break), a finished break returns to focus, plus a manual "start a break / back to focus" button.
- NEW: completion chime when a session ends.
- FIX: volume slider now controls the synthesized sounds.
- Not compiled here (no Android SDK) - build via GitHub Actions and test on device.
